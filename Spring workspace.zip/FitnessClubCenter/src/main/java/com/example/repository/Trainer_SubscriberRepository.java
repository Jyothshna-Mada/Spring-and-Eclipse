package com.example.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.entity.Trainer_Subscriber;

@Repository
public interface Trainer_SubscriberRepository extends JpaRepository<Trainer_Subscriber, Long>{

	List<Trainer_Subscriber> findByTrainerId(Long trainerId);
}
