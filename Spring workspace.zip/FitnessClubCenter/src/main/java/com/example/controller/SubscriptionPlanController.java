package com.example.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.entity.Subscription;
import com.example.service.SubscriptionService;

import io.swagger.v3.oas.annotations.parameters.RequestBody;

@RestController
@RequestMapping("/api/subscriptionplans")
public class SubscriptionPlanController {
	
	@Autowired
    private SubscriptionService subscriptionService;
 
    @PostMapping("/add")
    public ResponseEntity<Subscription> addSubscriptionPlan(@RequestBody Subscription subscription) {
        Subscription newPlan = subscriptionService.addSubscription(subscription);
        return ResponseEntity.ok(newPlan);
    }
 
    @GetMapping
    public ResponseEntity<List<Subscription>> getAllSubscriptionPlans() {
        List<Subscription> plans = subscriptionService.getAllSubscription();
        return ResponseEntity.ok(plans);
    }
 
    @GetMapping("/{id}")
    public ResponseEntity<Subscription> getSubscriptionPlanById(@PathVariable Long id) {
        Subscription plan = subscriptionService.getSubscriptionById(id);
        return ResponseEntity.ok(plan);
    }
 

 
    @DeleteMapping("/delete/{id}")
    public ResponseEntity<Void> deleteSubscriptionPlan(@PathVariable Long id) {
        subscriptionService.deleteSubscription(id);
        return ResponseEntity.noContent().build();
    }

}
