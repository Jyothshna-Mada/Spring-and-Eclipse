package com.example.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.entity.Trainer;
import com.example.repository.TrainerRepository;

@Service
public class TrainerService {

	@Autowired
	private TrainerRepository repository;
	
	public Trainer addTrainer(Trainer trainer) {
		return repository.save(trainer);
	}
	
	public List<Trainer> getAllTrainers(){
		return repository.findAll();
	}
	
	public Trainer getTrainerById(Long id) {
		return repository.findById(id).orElse(null);
	}
	
	public void deleteTrainer(Long id) {
		repository.deleteById(id);
	}
}
