package com.example.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.entity.Trainer_Subscriber;
import com.example.repository.Trainer_SubscriberRepository;

@Service
public class Trainer_SubscriberService {

	
	@Autowired
	private Trainer_SubscriberRepository repository;
	
	public Trainer_Subscriber allocateTrainer(Trainer_Subscriber map) {
		return repository.save(map);
	}
	
	public List<Trainer_Subscriber> getSubscribersByTrainerId(Long trainerId){
		return repository.findByTrainerId(trainerId);
	}
}
