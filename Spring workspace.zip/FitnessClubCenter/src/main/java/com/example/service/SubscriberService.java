package com.example.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.entity.Subscriber;
import com.example.repository.SubscriberRepository;

@Service
public class SubscriberService {

	@Autowired
	private SubscriberRepository repository;
	
	public Subscriber addSubscriber(Subscriber subscriber) {
		return repository.save(subscriber);
	}
	
	public List<Subscriber> getAllSubscribers(){
		return repository.findAll();
	}
	public Subscriber getSubscriberById(Long id) {
		return repository.findById(id).orElse(null);
	}
	
	public void deleteSubscriber(Long id) {
		repository.deleteById(id);
	}
}
