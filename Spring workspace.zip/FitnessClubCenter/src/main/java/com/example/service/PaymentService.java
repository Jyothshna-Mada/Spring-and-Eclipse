package com.example.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.entity.Payment;
import com.example.repository.PaymentRepository;

@Service
public class PaymentService {

	@Autowired
	private PaymentRepository repository;
	
	public Payment addPayment(Payment payment) {
		return repository.save(payment);
	}
	
	public List<Payment> getAllPayment(){
		return repository.findAll();
	}
	
	public Payment getPaymentById(Long id) {
		return repository.findById(id).orElse(null);
	}
	
	public List<Payment> getPaymentBySubscriberId(Long id){
		return  repository.findBySubscriberId(id);
	}
}
