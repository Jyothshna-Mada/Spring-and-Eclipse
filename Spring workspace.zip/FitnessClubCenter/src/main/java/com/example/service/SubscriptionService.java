package com.example.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.entity.Subscription;
import com.example.repository.SubscriptionRepository;

@Service
public class SubscriptionService {

	@Autowired
	private SubscriptionRepository repository;
	
	public Subscription addSubscription(Subscription subscription) {
		return repository.save(subscription);
	}
	
	public List<Subscription> getAllSubscription(){
		return repository.findAll();
	}
	
	public Subscription getSubscriptionById(Long id) {
		return repository.findById(id).orElse(null);
	}
	
	public Subscription updateSubscriber(Long id, Subscription updatedSubscription) {
		if(repository.existsById(id)) {
			updatedSubscription.setId(id);
			return repository.save(updatedSubscription);
		}
		return null;
	}
	
	public void deleteSubscription(Long id) {
		repository.deleteById(id);
	}
}
