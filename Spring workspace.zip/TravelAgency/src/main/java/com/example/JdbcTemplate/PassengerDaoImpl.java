package com.example.JdbcTemplate;


import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class PassengerDaoImpl implements PassengerDao{
	

	private final JdbcTemplate jdbcTemplate;

	
	public PassengerDaoImpl(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	

	@Override
	public void InsertPassenger(Passenger passenger) {
		 String sql = "INSERT INTO passenger_details (passenger_name,passenger_dob,passenger_phone,passenger_email) VALUES (?,?,?,?)";
	        jdbcTemplate.update(sql, passenger.getPassenger_name(),passenger.getPassenger_dob(),passenger.getPassenger_phone(),passenger.getPassenger_email());
		
	}

	@Override
	public List<Passenger> getAllPassengers() {
		String sql="select * from passenger_details";
		return jdbcTemplate.query(sql,new PassengerRowMapper());
	}

	@Override
	public void updatePassenger(Passenger passenger) {
		 String sql = "UPDATE passenger_details SET email = ? WHERE passenger_id = ?";
	        jdbcTemplate.update(sql, passenger.getPassenger_email(), passenger.getPassenger_id());
		
	}

	@Override
	public void deletePassenger(int id) {
		 String sql = "DELETE FROM passenger_details WHERE passenger_id = ?";
	        jdbcTemplate.update(sql, id);
		
	}

	
//	public Passenger getPassengerById(int id) {
//		 String sql = "SELECT * FROM passenger_details WHERE passenger_id = ?";
//	        return jdbcTemplate.queryForObject(sql, new PassengerRowMapper(), id);
//	}
	
}
