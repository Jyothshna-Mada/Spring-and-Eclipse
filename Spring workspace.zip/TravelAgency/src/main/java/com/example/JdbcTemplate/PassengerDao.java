package com.example.JdbcTemplate;

import java.util.List;

public interface PassengerDao {

	void InsertPassenger(Passenger passenger);
	List<Passenger> getAllPassengers();
	void updatePassenger(Passenger passenger);
	void deletePassenger(int id);

}
