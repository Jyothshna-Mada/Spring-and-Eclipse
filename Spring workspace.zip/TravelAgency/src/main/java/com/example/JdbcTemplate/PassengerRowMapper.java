package com.example.JdbcTemplate;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class PassengerRowMapper implements RowMapper<Passenger>{

	@Override
	public Passenger mapRow(ResultSet rs, int rowNum) throws SQLException {
		Passenger passenger = new Passenger();
		passenger.setPassenger_name(rs.getString("passenger_name"));
		passenger.setPassenger_dob(rs.getString("passenger_dob"));
		passenger.setPassenger_phone(rs.getLong("passenger_phone"));
		passenger.setPassenger_email(rs.getString("passenger_email"));
		return passenger;
	}
	
	

}
