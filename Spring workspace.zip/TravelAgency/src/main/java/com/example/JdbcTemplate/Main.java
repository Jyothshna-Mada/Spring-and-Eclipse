package com.example.JdbcTemplate;

import java.util.List;
import java.util.Scanner;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class Main {
	
	static Scanner scn = new Scanner(System.in);
	
	public static void main(String[] args) {
		
		boolean exit=false;
		
		AnnotationConfigApplicationContext ac = new AnnotationConfigApplicationContext(AopConfig.class);
	
		PassengerService service =ac.getBean(PassengerService.class);
		
		while(!exit) {
			System.out.println("-------Bus Booking System-------");
			System.out.println("press 1 for insert\npress 2 for update\npress 3 for retrive\npress 4 for delete\npress 5 to Quit");
			System.out.println("Make your choice");
			
			int choice =scn.nextInt();
			
			switch(choice) {
			case 1:{
				System.out.println("Enter name");
				String name =scn.nextLine();
				System.out.println("Enter Date of Birth");
				String dob=scn.nextLine();
				System.out.println("Enter Phone Number");
				Long phoneNumber=scn.nextLong();
				System.out.println("Enter email address");
				String email=scn.nextLine();
				
				Passenger passenger = new Passenger();
				passenger.setPassenger_name(name);
				passenger.setPassenger_dob(dob);
				passenger.setPassenger_phone(phoneNumber);
				passenger.setPassenger_email(email);
				
				service.save(passenger);
				break;
			}
			case 2:{
				System.out.println("Enter id to update");
				int id =scn.nextInt();
				System.out.println("Enter name");
				String name =scn.nextLine();
				System.out.println("Enter Date of Birth");
				String dob=scn.nextLine();
				System.out.println("Enter Phone Number");
				Long phoneNumber=scn.nextLong();
				System.out.println("Enter email address");
				String email=scn.nextLine();
				
				Passenger passenger = new Passenger();
				passenger.setPassenger_id(id);
				passenger.setPassenger_name(name);
				passenger.setPassenger_dob(dob);
				passenger.setPassenger_phone(phoneNumber);
				passenger.setPassenger_email(email);

				
				service.updatePassenger(null);
				break;
			}
			case 3:{
				List<Passenger> passengers = service.getAllPassengers();
				System.out.println("Users:");
				for(Passenger passenger : passengers) {
					System.out.println(passenger);
				}
				break;
			}
			case 4:{
				System.out.println("Enter Id to delete");
				int id=scn.nextInt();
				service.deletePassenger(id);
				break;
			}
			case 5:{
				exit=true;
				System.out.println("Thank you for using Bus Booking System...");
				break;
			}
			default : System.out.println("invalid choice");
			}
			if(choice!=5) {
				
			}
		}
	}
	
	public static boolean askToContinue() {
		System.out.println("Do you want to continue?(y/n): ");
		String response =scn.next();
		return response.equalsIgnoreCase("y");
	}

}
