package com.example.JdbcTemplate;
import java.util.List;

import org.springframework.stereotype.Service;

@Service
public class PassengerService {


	private final PassengerDao dao;

	public PassengerService(PassengerDao dao) {
		this.dao = dao;
	}
	
	public void save(Passenger passenger) {
		dao.InsertPassenger(passenger);
	}
	
	public List<Passenger> getAllPassengers() {
		return dao.getAllPassengers();
	}
	
	public void updatePassenger(Passenger passenger) {
		dao.updatePassenger(passenger);
	}
	
	public void deletePassenger(int id) {
		dao.deletePassenger(id);
	}
	
	
}
