package com.example.JdbcTemplate;

public class Passenger {
	
	private int passenger_id;
	private String passenger_name;
	private String passenger_dob;
	private Long passenger_phone;
	private String passenger_email;

	public int getPassenger_id() {
		return passenger_id;
	}
	
	public void setPassenger_id(int passenger_id) {
		this.passenger_id = passenger_id;
	}
	
	public String getPassenger_name() {
		return passenger_name;
	}
	
	public void setPassenger_name(String passenger_name) {
		this.passenger_name = passenger_name;
	}
	
	public String getPassenger_dob() {
		return passenger_dob;
	}
	
	public void setPassenger_dob(String passenger_dob) {
		this.passenger_dob = passenger_dob;
	}
	
	public Long getPassenger_phone() {
		return passenger_phone;
	}
	
	public void setPassenger_phone(Long passenger_phone) {
		this.passenger_phone = passenger_phone;
	}
	
	public String getPassenger_email() {
		return passenger_email;
	}
	
	public void setPassenger_email(String passenger_email) {
		this.passenger_email = passenger_email;
	}	

}
