package com.example.BusBooking;

public class PassengerDetails {
	
	private int Passenger_id;
	private String passenger_name;
	private String passenger_dob;
	private String passenger_email;
	private String passenger_phone;
	
	public int getPassenger_id() {
		return Passenger_id;
	}
	public void setPassenger_id(int passenger_id) {
		Passenger_id = passenger_id;
	}
	public String getPassenger_name() {
		return passenger_name;
	}
	public void setPassenger_name(String passenger_name) {
		this.passenger_name = passenger_name;
	}
	public String getPassenger_dob() {
		return passenger_dob;
	}
	public void setPassenger_dob(String passenger_dob) {
		this.passenger_dob = passenger_dob;
	}
	public String getPassenger_email() {
		return passenger_email;
	}
	public void setPassenger_email(String passenger_email) {
		this.passenger_email = passenger_email;
	}
	public String getPassenger_phone() {
		return passenger_phone;
	}
	public void setPassenger_phone(String passenger_phone) {
		this.passenger_phone = passenger_phone;
	}
	
	
	

}
