package com.example.BusBooking;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class PassengerController {
	
	@RequestMapping("/")
	public String homepage() {
		return "home";
	}
	
	@RequestMapping("/passengerform")
	public String showForm(Model model) {
		model.addAttribute("passenger",new PassengerDetails());
		return "PassengerForm";
	}
	
	@RequestMapping(value="/addPassenger",method=RequestMethod.POST)
	public String submitForm(@ModelAttribute("passenger") PassengerDetails passenger, Model model) {
		model.addAttribute("message", "Passenger Added Successfully!");
		return "home";
	}
	
	@RequestMapping("/listPassengers")
	public String listPassengers(Model model) {
		return "PassengerList";
	}

}
