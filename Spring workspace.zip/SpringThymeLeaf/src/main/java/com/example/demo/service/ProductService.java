package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Product;
import com.example.demo.repository.ProductRepository;

@Service
public class ProductService {

	@Autowired
	private ProductRepository repository;
	
	public List<Product> getAllProducts(){
		return repository.findAll();
	}
	
	public Optional<Product> getProductById(Long id){
		return repository.findById(id);
	}
	
	public Product saveProduct(Product product) {
		return repository.save(product);
	}
	
	public void deleteProduct(Long id) {
		repository.deleteById(id);
	}
	
	@Transactional
	public int updateProductPrice(Long id,double price) {
		return repository.updateProductPriceById(id, price);
	}
}
