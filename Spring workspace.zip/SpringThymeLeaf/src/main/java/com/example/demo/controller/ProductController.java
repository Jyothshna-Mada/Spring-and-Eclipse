package com.example.demo.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.example.demo.entity.Product;
import com.example.demo.service.ProductService;

@Controller
@RequestMapping("/products")
public class ProductController {
	
	@Autowired
	private ProductService service;
	
	@GetMapping
    public String viewHomePage(Model model) {
        List<Product> products = service.getAllProducts();
        model.addAttribute("listProducts", products);
        return "index";
    }


    @GetMapping("/showNewProductForm")
    public String showNewProductForm(Model model) {
        Product product = new Product();
        model.addAttribute("product", product);
        return "new_product";  
    }
	
	@PostMapping("/saveProduct")
    public String saveProduct(@ModelAttribute("product") Product product) {
        service.saveProduct(product);
        return "redirect:/products";  
    }

    @GetMapping("/showFormForUpdate/{id}")
    public String showFormForUpdate(@PathVariable(value = "id") long id, Model model) {
        Optional<Product> product = service.getProductById(id);
        if (product.isPresent()) {
            model.addAttribute("product", product.get());
            return "update_product"; 
        } else {
            return "redirect:/products";  
        }
    }

    @PostMapping("/updateProduct/{id}")
    public String updateProduct(@PathVariable(value = "id") long id, @ModelAttribute("product") Product product) {
        product.setId(id);
        service.saveProduct(product);
        return "redirect:/products";
    }

    @GetMapping("/deleteProduct/{id}")
    public String deleteProduct(@PathVariable(value = "id") long id) {
        service.deleteProduct(id);
        return "redirect:/products";  
    }

}
