package com.essentialprogramming.springbootopenapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServerTests {

    @Test
    void contextLoads() {
    }

}
