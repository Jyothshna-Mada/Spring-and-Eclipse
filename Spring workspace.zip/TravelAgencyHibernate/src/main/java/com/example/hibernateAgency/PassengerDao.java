package com.example.hibernateAgency;

import java.util.List;

public interface PassengerDao {

	void insertPassenger(Passenger passenger);
	void updatePassenger(Passenger passenger);
	void deletePassenger(Passenger passenger);
	Passenger get(int id);
	List<Passenger> loadAll();
}
