package com.example.hibernateAgency;

import java.util.List;

import org.springframework.stereotype.Service;

@Service
public class PassengerServiceImpl implements PassengerService{

	private PassengerDaoImpl dao;

	public void setDao(PassengerDaoImpl dao) {
		this.dao = dao;
	}
	
	public void insertPassenger(Passenger passenger) {
		dao.insertPassenger(passenger);
	}
	
	public void updatePassenger(Passenger passenger) {
		dao.updatePassenger(passenger);
	}
	
	public void deletePassenger(Passenger passenger) {
		dao.deletePassenger(passenger);
	}
	
	public List<Passenger> loadAll(){
		return dao.loadAll();
	}

	@Override
	public Passenger get(int id) {
		return dao.get(id);
	}
}
