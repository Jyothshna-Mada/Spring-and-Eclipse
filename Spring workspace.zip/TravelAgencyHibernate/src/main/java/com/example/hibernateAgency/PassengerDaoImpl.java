package com.example.hibernateAgency;

import java.util.List;

import org.springframework.orm.hibernate5.HibernateTemplate;

public class PassengerDaoImpl implements PassengerDao{

	private HibernateTemplate hibernateTemplate;

	public void setHibernateTemplate(HibernateTemplate hibernateTemplate) {
		this.hibernateTemplate = hibernateTemplate;
	}
	
	@Override
	public void insertPassenger(Passenger passenger) {
		
		hibernateTemplate.execute(session->{
			
			session.save(passenger);
			return null;
		});
		
	}
	
	@Override
	public void updatePassenger(Passenger passenger) {
hibernateTemplate.execute(session->{
			
			session.update(passenger);
			return null;
		});
		hibernateTemplate.update(passenger);
	}

	@Override
	public void deletePassenger(Passenger passenger) {
		
hibernateTemplate.execute(session->{
			
			session.delete(passenger);
			return null;
		});
	}
	
	
	@Override
	public List<Passenger> loadAll(){
		return hibernateTemplate.loadAll(Passenger.class);
	}

	@Override
	public Passenger get(int id) {
		return hibernateTemplate.get(Passenger.class, id);
	}
}
