package com.example.shopping;

public class Disc extends Product{
	
	private int capacity;
	
	public Disc(String productId, String productName, double productPrice,double discount, int capacity) {
		super(productId, productName, productPrice,discount);
		this.capacity = capacity;
	}
	
	public int getCapacity() {
		return capacity;
	}

	@Override
	public String toString() {
		return super.toString() +"capacity=" + capacity + "]";
	}
	
	
}
