package com.example.shopping;

import java.io.IOException;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {
	
	public static void main(String[] args) throws IOException {
		ApplicationContext ac=new ClassPathXmlApplicationContext("beans.xml");
		
		Battery b1 = (Battery) ac.getBean("battery");
		Disc d1 = (Disc) ac.getBean("disc");
		
//		System.out.println("Discount on battery: "+b1.getDiscount());
//		System.out.println("Discount on Disc: "+d1.getDiscount());

		
		ShoppingCart sc1 =(ShoppingCart) ac.getBean("shoppingcart");
//		sc1.addItem((Product) ac.getBean("battery"));
//		sc1.addItem((Product) ac.getBean("disc"));
		//System.out.println("Customer 1 Cart: "+sc1.getItems());
		
		
		
//		ShoppingCart sc2 =(ShoppingCart) ac.getBean("shoppingcart");
//		sc2.addItem((Product) ac.getBean("battery"));
//		sc2.addItem((Product) ac.getBean("disc"));
//		System.out.println("Customer 2 Cart: "+sc2.getItems());
		
		sc1.addItem(b1);
		sc1.addItem(d1);
		
//		Cashier cashier =(Cashier) ac.getBean("cashier");
//		cashier.checkout(sc1);
		System.out.println("Customer 1 Cart: "+sc1.getItems());
		
	}
}
