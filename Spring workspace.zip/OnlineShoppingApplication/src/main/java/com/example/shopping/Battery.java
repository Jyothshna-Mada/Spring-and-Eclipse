package com.example.shopping;

public class Battery extends Product{

	private boolean rechargeable;
	
	public Battery(String productId, String productName, double productPrice,double discount, boolean rechargeable) {
		super(productId, productName, productPrice,discount);
		this.rechargeable = rechargeable;
	}
	
	public boolean isRechargeable() {
		return rechargeable;
	}

	@Override
	public String toString() {
		return super.toString() +"rechargeable=" + rechargeable + "]";
	}
	
	
	
}
