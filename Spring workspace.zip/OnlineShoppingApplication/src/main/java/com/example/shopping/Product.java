package com.example.shopping;

public abstract class Product {
	
	private String productId;
	private String productName;
	private double productPrice;
	private double discount;
	
	
	public Product(String productId, String productName, double productPrice,double discount) {
		this.productId = productId;
		this.productName = productName;
		this.productPrice = productPrice;
		this.discount=discount;
	}


	public String getProductId() {
		return productId;
	}


	public String getProductName() {
		return productName;
	}


	public double getProductPrice() {
		return productPrice;
	}


	public double getDiscount() {
		return discount;
	}


	public void setProductId(String productId) {
		this.productId = productId;
	}


	public void setProductName(String productName) {
		this.productName = productName;
	}


	public void setProductPrice(double productPrice) {
		this.productPrice = productPrice;
	}


	public void setDiscount(double discount) {
		this.discount = discount;
	}


	@Override
	public String toString() {
		return "Product [productId=" + productId + ", productName=" + productName + ", productPrice=" + productPrice
				+ ", discount=" + discount+", ";
	}
	
	
	
}
