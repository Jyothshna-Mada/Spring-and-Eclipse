package com.example.shopping;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
@Aspect
public class LoggingAspect {
	
	private ShoppingCart shoppingCart;
	
	public ShoppingCart getShoppingCart() {
		return shoppingCart;
	}
	
	@Autowired
	public void setShoppingCart(ShoppingCart shoppingCart) {
		this.shoppingCart = shoppingCart;
	}





	@Before(value="execution(* com.example.ShoppingCart.getItems())")
	public void logBeforeGetItems() {
		System.out.println("Logging Before getting items from cart");
	}
	
	@After(value="execution(* com.example.ShoppingCart.getItems())")
	public void logAfterGetItems() {
		System.out.println("Logging Before getting items from cart");
	}
	
	@AfterReturning(value="execution(* com.example.ShoppingCart.getItems())")
	public void logAfterReturningGetItems() {
		System.out.println("Logging After Successfully getting items from cart ");
	}
	
	@Around(value="execution(* com.example.ShoppingCart.getItems())")
	public Product logAroundGetItems(ProceedingJoinPoint joinPoint) throws Throwable {
		System.out.println("Logging before executing getItems()");
		Product result;
		
		try {
			result=(Product) joinPoint.proceed();
			System.out.println("Logging after successfull execution of getItems()");
		}catch (Exception e) {
			System.out.println("Logging after exception in getItems()");
			throw e;
		}
		System.out.println("Logging after method execution completed for getitems()");
		return  result;
	}
	
	
	
	
	@Before(value="execution(* com.example.ShoppingCart.addItem())")
	public void logBeforeAddItem() {
		System.out.println("Logging before adding item to cart");
	}
	
	@After(value="execution(* com.example.ShoppingCart.addItem())")
	public void logAfterAddItem() {
		System.out.println("Logging after adding item to cart");
	}
	
	
	
	
	
	@Before(value="execution(* com.example.ShoppingCart.removeItem())")
	public void logBeforeRemoveItem() {
		System.out.println("Logging before removing item from cart");
	}
	
	@After(value="execution(* com.example.ShoppingCart.removeItem())")
	public void logAfterRemoveItem() {
		System.out.println("Logging after removing item from cart");
	}
	
	
	
	
	
	@Before(value="execution(* com.example.ShoppingCart.updateItem())")
	public void logBeforeUpdateItem() {
		System.out.println("Logging before updating an item in cart");
	}
	
	@After(value="execution(* com.example.ShoppingCart.updateItem())")
	public void logAfterUpdateItem() {
		System.out.println("Logging after updating an item in cart");
	}
	
	@AfterThrowing(value="within(* com.example.ShoppingCart.updateItem())")
	public void logAfterThrowingUpdateItem() {
		System.out.println("Logging after exception thrown while updating an item into cart");
	}

}
