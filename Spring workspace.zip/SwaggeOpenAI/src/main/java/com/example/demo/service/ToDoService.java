package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.NewToDo;
import com.example.demo.model.ToDo;
import com.example.demo.repository.ToDoRepository;

@Service
public class ToDoService {

    @Autowired
    private ToDoRepository toDoRepository;

    public List<ToDo> getAllToDos() {
        return toDoRepository.findAll();
    }

    public Optional<ToDo> getToDoById(Long id) {
        return toDoRepository.findById(id);
    }

    public ToDo createToDo(NewToDo newToDo) {
        ToDo toDo = new ToDo();
        toDo.setTitle(newToDo.getTitle());
        toDo.setCompleted(newToDo.getCompleted());
        return toDoRepository.save(toDo);
    }

    public ToDo updateToDo(Long id, NewToDo newToDo) {
        return toDoRepository.findById(id).map(toDo -> {
            toDo.setTitle(newToDo.getTitle());
            toDo.setCompleted(newToDo.getCompleted());
            return toDoRepository.save(toDo);
        }).orElse(null);
    }

    public void deleteToDoById(Long id) {
        toDoRepository.deleteById(id);
    }
}
