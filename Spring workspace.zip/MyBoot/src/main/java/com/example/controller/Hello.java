package com.example.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.Service.MyService;

@RestController
//controller + response Entity
public class Hello {
	
	@Autowired
	public MyService m1;
	
	@GetMapping("/h1")
	public String greet() {
		return "Hello World from Spring Boot";
	}
	
	@GetMapping("/h2")
	public String hello() {
		return m1.hello();
	}
	
}
