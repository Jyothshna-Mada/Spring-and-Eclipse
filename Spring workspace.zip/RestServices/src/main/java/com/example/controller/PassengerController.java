package com.example.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.Model.Passenger;

@RestController 
@RequestMapping("/passengers") 
public class PassengerController {

	
    @Autowired 
    private PassengerRepository passengerRepository; 
  
    @PostMapping 
    public Passenger addPassenger(@RequestBody Passenger passenger) { 
        return passengerRepository.save(passenger); 
    } 
  
    @GetMapping 
    public List<Passenger> getAllPassengers() { 
        return passengerRepository.findAll(); 
    } 
  
    @GetMapping("/{passengerId}") 
    public ResponseEntity<Passenger> getPassengerById(@PathVariable Integer passengerId) { 
        return passengerRepository.findById(passengerId) 
                .map(ResponseEntity::ok) 
                .orElse(ResponseEntity.notFound().build()); 
    } 
  
    @PutMapping("/{passengerId}") 
    public ResponseEntity<Passenger> updatePassenger(@PathVariable Integer passengerId, @RequestBody Passenger passengerDetails) { 
        return passengerRepository.findById(passengerId) 
                .map(passenger -> { 
                    passenger.setName(passengerDetails.getName()); 
                    passenger.setEmail(passengerDetails.getEmail()); 
                    return ResponseEntity.ok(passengerRepository.save(passenger)); 
                }) 
                .orElse(ResponseEntity.notFound().build()); 
    } 
  
    @DeleteMapping("/{passengerId}") 
    public ResponseEntity<Object> deletePassenger(@PathVariable Integer passengerId) { 
        return passengerRepository.findById(passengerId) 
                .map(passenger -> { 
                    passengerRepository.delete(passenger); 
                    return ResponseEntity.ok().build(); 
                }) 
                .orElse(ResponseEntity.notFound().build()); 
    } 
} 

