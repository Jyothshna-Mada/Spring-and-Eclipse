package com.example.controller;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.Model.Passenger;

public interface PassengerRepository extends JpaRepository<Passenger, Integer>{

}
