package com.example.actuator.custom;

import org.springframework.boot.actuate.health.Health;
import org.springframework.boot.actuate.health.HealthIndicator;

public class CustomHealthIndicator implements HealthIndicator{

	@Override
	public Health health() {
		 boolean serviceUp =checkServiceStatus();
		 if(serviceUp) {
			 return Health.up().withDetail("Service Status", "Service is Up").build();
		 }else {
			 return Health.down().withDetail("Service Status", "Service is Down").build();
		 }
	}
	
	private boolean checkServiceStatus() {
		return  true;
	}

}
