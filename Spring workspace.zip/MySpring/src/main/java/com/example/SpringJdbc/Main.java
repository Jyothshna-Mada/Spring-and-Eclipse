package com.example.SpringJdbc;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class Main {

	public static void main(String[] args) {
		ApplicationContext ac = new AnnotationConfigApplicationContext(AppConfig.class);
		
		UserDao userDao =ac.getBean(UserDao.class);
		
//		userDao.createUser("Ravi Ram");
//		userDao.createUser("Priya Sharma");
		
//		userDao.deleteUser(2);
		userDao.updateUser(1, "Ravi Ram Prakash");
		
		List<String> users = userDao.getUsers();
		System.out.println("Users:");
		for(String user : users) {
			System.out.println(user);
		}
	}
}
