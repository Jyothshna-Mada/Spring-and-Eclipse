package com.example.SpringJdbc;

import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class UserDaoImpl implements UserDao{
	
	private final JdbcTemplate jdbcTemplate;
	
	public UserDaoImpl(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	@Override
	public void createUser(String name) {
		String sql="Insert into students (name) values(?)";
		jdbcTemplate.update(sql,name);
		
	}

	@Override
	public List<String> getUsers() {
		String sql ="select name from students";
		return jdbcTemplate.queryForList(sql, String.class);
	}

	@Override
	public void updateUser(int id, String name) {
	String sql ="update students set name=? where id=?";
		jdbcTemplate.update(sql,name,id);
	}

	@Override
	public void deleteUser(int id) {
	String sql ="Delete from students where id=?";
		jdbcTemplate.update(sql,id);
	}
	

}
