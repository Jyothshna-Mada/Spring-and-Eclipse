package com.example.scope;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class Driver {

	public static void main(String[] args) {
		
		AnnotationConfigApplicationContext ac = new AnnotationConfigApplicationContext(AppConfig.class);
		
		Employee e1 = ac.getBean(Employee.class);
		e1.setCity("Coimbatore");
		e1.display();
		
		Employee e2 = ac.getBean(Employee.class);
		e2.setCity("Hyderabad");
		e2.display();
	}
}
