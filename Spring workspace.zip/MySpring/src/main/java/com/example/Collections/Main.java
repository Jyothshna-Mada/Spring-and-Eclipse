package com.example.Collections;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {

	public static void main(String[] args) {
		ApplicationContext ac = new ClassPathXmlApplicationContext("collectionbean.xml");
		
		MessageProcessor mp = (MessageProcessor) ac.getBean("messageprocessor");
		
		mp.processMessage("Hello,Dependency Injector through XML");

	}

}
