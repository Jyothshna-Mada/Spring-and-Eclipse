package com.example.Collections;

public interface MessageService {
	
	void sendMessage(String message);

}
