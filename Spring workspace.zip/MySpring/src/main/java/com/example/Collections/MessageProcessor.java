package com.example.Collections;

import java.util.List;

public class MessageProcessor {
	private List<MessageService> messageServices;
	

	
	public void setMessageServices(List<MessageService> messageServices) {
		this.messageServices = messageServices;
	}
	
	public void processMessage(String message) {
		for(MessageService service: messageServices) {
			service.sendMessage(message);
		}
	}

}
