package com.example.lifecycle;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class Main {

	public static void main(String[] args) {
		
		AnnotationConfigApplicationContext ac = new AnnotationConfigApplicationContext(AppConfigs.class);
		
		Country c1 = ac.getBean(Country.class);
		//System.out.println("Country: "+c1.getCountryName());
//		c1.init();
//		c1.destroy();
		//ac.registerShutdownHook();

	}

}
