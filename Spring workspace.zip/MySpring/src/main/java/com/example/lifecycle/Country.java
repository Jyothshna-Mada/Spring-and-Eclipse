package com.example.lifecycle;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.springframework.stereotype.Component;

@Component
public class Country {

	private String countryName;

	public String getCountryName() {
		return countryName;
	}

	public void setCountryName(String countryName) {
		this.countryName = countryName;
	}
	
	@PostConstruct
	public void init() {
		System.out.println("In Init block of country");
	}
	
	@PreDestroy
	public void destroy() {
		System.out.println("In destroy block of country");
	}
}
