package com.example.lifecycle;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan("com.example.lifecycle")
public class AppConfigs {

	@Bean
	public Country country() {
		Country country = new Country();
		country.setCountryName("India");
		return country;
	}
}
