package com.example.AOP;

import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class Driver {

	public static void main(String[] args) {
		ApplicationContext context = new AnnotationConfigApplicationContext(AopConfig.class);
		EasyBank bank =context.getBean(EasyBank.class);
		
		Scanner scn = new Scanner(System.in);
		
		int pin=0;
		int amount=0;
		int choice=0;
		
		boolean exit=false;
		while(!exit) {
			System.out.println("Select Option");
			System.out.println("1.Deposit\n2.Withdraw\n3.Change Pin\n4.Show Balance\n5.Exit");
			choice =scn.nextInt();
			
			try {
				switch(choice) {
				case 1:{
					System.out.println("Enter Amount to diposit");
					amount=scn.nextInt();
					System.out.println("Enter pin");
					pin=scn.nextInt();
					bank.setTempPin(pin);
					bank.doDeposit(amount);
					
					break;
				}
				case 2:{
					System.out.println("Enter amount to withdraw");
					amount=scn.nextInt();
					System.out.println("Enter pin");
					pin=scn.nextInt();
					bank.setTempPin(pin);
					bank.doWithdraw(amount);
					
					break;
				}
				case 3:{
					System.out.println("Enter your current pin");
					int oldpin=scn.nextInt();
					System.out.println("Enter 4 digit new pin");
					int newpin=scn.nextInt();
					bank.doChangePin(oldpin, newpin);
					
					break;
				}
				case 4:{
					System.out.println("Enter pin");
					pin=scn.nextInt();
					bank.setTempPin(pin);
					bank.showBalance();
					
					break;
				}
				case 5:{
					System.out.println("Thanks for using our services");
					exit=true;
					break;
				}
				default : System.out.println("Invalid choice");
				}
			}catch (Exception ignore) {
			}
		}

		
	}

}
