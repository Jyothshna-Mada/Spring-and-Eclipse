package com.example.AOP;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
@Aspect
public class LoginAspect {
	
	private EasyBank easybank;
	
	public EasyBank getEasybank() {
		return easybank;
	}

	@Autowired
	public void setEasybank(EasyBank easybank) {
		this.easybank = easybank;
	}

	@Around(value = "execution(public void com.example.AOP.EasyBank.doWithdraw(..))")//point cut Expression
	public void validateWithdraw(ProceedingJoinPoint joinPoint) throws Throwable{
		if(easybank.getTempPin()!=easybank.getPinCode()) {
			throw new Exception();
		}
		else {
			joinPoint.proceed();
			System.out.println("Your remaining Balance is "+easybank.getBalance());
		}
	}
	
	@Before(value = "execution(public void com.example.AOP.EasyBank.showBalance(..)),"
			+ "execution(public void com.example.AOP.EasyBank.doDeposit(..)),"
			+ "execution(public void com.example.AOP.EasyBank.doChangePin(..))")
	public void validateBalance() throws Exception{
		if(easybank.getTempPin()!=easybank.getPinCode()) {
			throw new RuntimeException();
		}
	}
	
	@AfterReturning(value="execution(public void com.example.AOP.EasyBank.doChangePin(..))")
	public void afterPinChange() {
		System.out.println("you have Successfully Changed your Pin");
	}
	
	@AfterThrowing(value="within(com.example.AOP.EasyBank)")
	public void afterWrongPin() {
		System.out.println("Invalid Pin");
	}

}
