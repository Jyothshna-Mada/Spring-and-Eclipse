package com.example.NamedParameters;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class UserDaoImpl implements UserDao{
	
	private final NamedParameterJdbcTemplate namedParameterJdbcTemplate;

	
	public UserDaoImpl(NamedParameterJdbcTemplate namedParameterJdbcTemplate) {
		this.namedParameterJdbcTemplate = namedParameterJdbcTemplate;
	}


	@Override
	public void createUser(String name) {
		String sql="insert into students (name) values(:name)";
		Map<String, Object> params =new HashMap<>();
		params.put("name", name);
		namedParameterJdbcTemplate.update(sql, params);
		
	}


	@Override
	public List<String> getUsers() {
		String sql ="select name from students";
		return namedParameterJdbcTemplate.queryForList(sql, new HashMap<>() , String.class);
	}


	@Override
	public void updateUser(int id, String name) {
		String sql="update students set name=:name where id=:id";
		Map<String, Object> params =new HashMap<>();
		params.put("name", name);
		params.put("id", id);
		namedParameterJdbcTemplate.update(sql, params);
		
	}


	@Override
	public void deleteUser(int id) {
		String sql ="Delete from students where id=:id";
		Map<String, Object> params =new HashMap<>();
		params.put("id", id);
		namedParameterJdbcTemplate.update(sql, params);
	}
	
	

}
