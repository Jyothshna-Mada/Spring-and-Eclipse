package com.example.setter;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {

	public static void main(String[] args) {
		ApplicationContext ac = new ClassPathXmlApplicationContext("applicationContext.xml");
		
		Address a1 = (Address) ac.getBean("a1");
		Address a2 = (Address) ac.getBean("a2");
		
		Employee e1 = (Employee) ac.getBean("obj");
		
		Employee e2 = (Employee) ac.getBean("obj2");
		
//		System.out.println("Address details");
//		System.out.println("---------------------");
//		System.out.println(a1.getAddressLine1());
//		System.out.println(a1.getCity());
//		System.out.println(a1.getState());
//		System.out.println(a1.getCountry());
//		
//		System.out.println("Address details");
//		System.out.println("---------------------");
//		System.out.println(a2.getAddressLine1());
//		System.out.println(a2.getCity());
//		System.out.println(a2.getState());
//		System.out.println(a2.getCountry());
		
		System.out.println("Employee Details");
		System.out.println("---------------------");
		e1.display();
		System.out.println("Employee Details");
		System.out.println("---------------------");
		e2.display();
	}
}
