package com.example.Autowired;

import java.util.Calendar;
import java.util.Date;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan({"com.example.Autowired"})
public class ApplicationConfig {
	
	@Bean
	public Employee employee() {
		Employee e1 = new Employee();
		
		e1.setEmpId(1234);
		e1.setName("Anikha");
		//e1.setPassobj(passport());
		return e1;
	}
	
	@Bean
	public Passport passport() {
		Passport passport = new Passport();
		
		Date today=new Date();
		
		Calendar cal= Calendar.getInstance();
		cal.setTime(today);
		cal.add(Calendar.DATE, 90);
		
		Date expiry=cal.getTime();
		
		passport.setPassNum(9876);
		
		passport.setDateOfIssue(today);
		passport.setDateOfExpiry(expiry);
		
		return passport;
	}
	
	
}
