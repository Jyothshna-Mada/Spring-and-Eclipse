package com.example.Autowired;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class Employee {
	
	private int empId;
	private String name;
	
	@Autowired
	private Passport passobj;

	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Passport getPassobj() {
		return passobj;
	}

	public void setPassobj(Passport passobj) {
		this.passobj = passobj;
	}

}
