package com.example.Autowired;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class Driver {

	public static void main(String[] args) {
		ApplicationContext ac=new AnnotationConfigApplicationContext(ApplicationConfig.class);
		
		Employee e1 = (Employee) ac.getBean(Employee.class);
		
		System.out.println("Emp Id: "+e1.getEmpId());
		System.out.println("Emp Name: "+e1.getName());
		System.out.println(e1.getPassobj().toString());
		
		
	}
}
