package com.example.Constructor;

public class MemberShip {
	private int memebershipId;
	private int visitPerYear;
	private String membershipType;
	private Customer customer;
	
	public MemberShip(int memebershipId, int visitPerYear, String membershipType, Customer customer) {
		super();
		this.memebershipId = memebershipId;
		this.visitPerYear = visitPerYear;
		this.membershipType = membershipType;
		this.customer = customer;
	}

	public int getMemebershipId() {
		return memebershipId;
	}

	public void setMemebershipId(int memebershipId) {
		this.memebershipId = memebershipId;
	}

	public int getVisitPerYear() {
		return visitPerYear;
	}

	public void setVisitPerYear(int visitPerYear) {
		this.visitPerYear = visitPerYear;
	}

	public String getMembershipType() {
		return membershipType;
	}

	public void setMembershipType(String membershipType) {
		this.membershipType = membershipType;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	@Override
	public String toString() {
		return "MemberShip [memebershipId=" + memebershipId + ", visitPerYear=" + visitPerYear + ", membershipType="
				+ membershipType + ", customer=" + customer + "]";
	}
	
}
