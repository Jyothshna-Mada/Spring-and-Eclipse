package com.example.Constructor;

public class Customer {
	private int custId;
	private String customerName;
	private String emailId;
	private long contactNo;
	
	public int getCustId() {
		return custId;
	}
	public String getCustomerName() {
		return customerName;
	}
	public String getEmailId() {
		return emailId;
	}
	public long getContactNo() {
		return contactNo;
	}
	
	public void setCustId(int custId) {
		this.custId = custId;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public void setContactNo(long contactNo) {
		this.contactNo = contactNo;
	}

	@Override
	public String toString() {
		return "Customer [custId=" + custId + ", customeNamer=" + customerName + ", emailId=" + emailId + ", contactNo="
				+ contactNo + "]";
	}
	
	
}
