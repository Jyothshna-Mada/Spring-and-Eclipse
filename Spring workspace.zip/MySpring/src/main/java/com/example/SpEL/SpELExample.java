package com.example.SpEL;

import org.springframework.expression.ExpressionParser;
import org.springframework.expression.spel.standard.SpelExpressionParser;
import org.springframework.expression.spel.support.StandardEvaluationContext;

public class SpELExample {

	public static void main(String[] args) {
		Person person = new  Person("Aruna", 23);
		
		ExpressionParser parser = new SpelExpressionParser();
		StandardEvaluationContext context = new StandardEvaluationContext();
		
		context.setRootObject(person);
		
		//accessing properties
		String name=parser.parseExpression("name").getValue(context,String.class);
		int age = parser.parseExpression("age").getValue(context,Integer.class);
		
		System.out.println("Name: "+name);
		System.out.println("Age: "+age);
		
		//call method
		String greet =parser.parseExpression("greet() ").getValue(context,String.class);
		System.out.println(greet);
		
		//using conditional Expression
		boolean isAdult =parser.parseExpression("age>18").getValue(context,Boolean.class);
		System.out.println("Is Adult: "+isAdult);
		
		parser.parseExpression("name").setValue(context, "Ajay");
		String Modifiedname=parser.parseExpression("name").getValue(context,String.class);
		 System.out.println("Modified Name: "+Modifiedname);
		
	}
}
