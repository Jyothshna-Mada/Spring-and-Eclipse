package com.example.SpEL;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class Driver {

	public static void main(String[] args) {
		try(AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext(Config.class)){
			ExampleBean bean = context.getBean(ExampleBean.class);
			
			System.out.println("Example Bean Details: ");
			
			System.out.println("Message: "+bean.getMessage());
			System.out.println("Computed Value: "+bean.getComputedValue());
			System.out.println("Expression Result: "+bean.getExpressionResult());
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
}
