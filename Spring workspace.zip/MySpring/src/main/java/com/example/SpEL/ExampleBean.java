package com.example.SpEL;

import org.springframework.stereotype.Component;

@Component
public class ExampleBean {
	
	private String message;
	private String computedValue;
	private double expressionResult;
	
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getComputedValue() {
		return computedValue;
	}
	public void setComputedValue(String computedValue) {
		this.computedValue = computedValue;
	}
	public double getExpressionResult() {
		return expressionResult;
	}
	public void setExpressionResult(double expressionResult) {
		this.expressionResult = expressionResult;
	}
	
	@Override
	public String toString() {
		return "ExampleBean [message=" + message + ", computedValue=" + computedValue + ", expressionResult="
				+ expressionResult + "]";
	}
	
}
