package com.example.SpEL;

import java.util.Arrays;
import java.util.Map;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.expression.ExpressionParser;
import org.springframework.expression.spel.standard.SpelExpressionParser;
import org.springframework.expression.spel.support.StandardEvaluationContext;

@Configuration
@ComponentScan("com.example.SpEL")
public class Config {

	@Bean
	public ExampleBean exampleBean() {
		ExampleBean bean = new ExampleBean();
		bean.setMessage("Hello, World");
		
		ExpressionParser ep = new SpelExpressionParser();
		StandardEvaluationContext context = new StandardEvaluationContext();
		
		context.setVariable("num1", 10);
		context.setVariable("num2", 5);
		context.setVariable("str1", "Hello");
		context.setVariable("str2", "SpEL");
		
		String literalValue = ep.parseExpression("'This is a literal value'").getValue(String.class);
		System.out.println("Literal Expression: "+literalValue);
		
		boolean isTrue =ep.parseExpression("true").getValue(Boolean.class);
		
		boolean isEqual =ep.parseExpression("#num1 == #num2").getValue(Boolean.class);
		System.out.println("Boolean Expression (true): "+isTrue);
		System.out.println("Relational Expression (num1==num2): "+isEqual);
		
		boolean matches =ep.parseExpression("'hello123'.matches('[a-z]+\\d+')").getValue(Boolean.class);
		System.out.println("Regular EXpression Match: "+matches);
		
		
		String className = ep.parseExpression("T(java.lang.Math).PI").getValue(String.class);
        System.out.println("Class Expression (Math.PI): " + className);
        
        context.setVariable("list", Arrays.asList("A", "B", "C"));
        String listElement = ep.parseExpression("#list[1]").getValue(context, String.class);
        context.setVariable("map", Map.of("key1", "value1", "key2", "value2"));
        String mapValue = ep.parseExpression("#map['key1']").getValue(context, String.class);
        System.out.println("List Element (list[1]): " + listElement);
        System.out.println("Map Value (map['key1']): " + mapValue);
        
        String concatResult = ep.parseExpression("#str1.concat(' ').concat(#str2)").getValue(context, String.class);
        System.out.println("Method Invocation (concatResult): " + concatResult);
        
        boolean isGreater = ep.parseExpression("#num1 > #num2").getValue(Boolean.class);
        System.out.println("Relational Expression (#num1 > #num2): " + isGreater);
        
        Integer assignedValue = ep.parseExpression("#num1 + #num2").getValue(context, Integer.class);
        context.setVariable("assignedValue", assignedValue);
        System.out.println("Assigned Value: " + assignedValue);

        String templatedValue = ep.parseExpression("Hello #{#str1}").getValue(context, String.class);
        System.out.println("Templated Expression: " + templatedValue);
        
        bean.setComputedValue(concatResult + " | Literal: " + literalValue);
        bean.setExpressionResult(assignedValue);

		return bean;
	}
}
