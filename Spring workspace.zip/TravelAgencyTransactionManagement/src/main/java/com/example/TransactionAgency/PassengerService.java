package com.example.TransactionAgency;

import java.util.List;

public class PassengerService {

	private PassengerDao dao;

	public void setDao(PassengerDao dao) {
		this.dao = dao;
	}
	
	public void savePassenger(Passenger passenger) {
		dao.insertPassenger(passenger);
	}
	
	public void updatePassenger(Passenger passenger) {
		dao.updatePassenger(passenger);
	}
	
	public void deletePassenger(int id) {
		dao.deletePassenger(id);
	}
	
	public Passenger getPassenger(int id) {
		return dao.get(id);
	}
	
	public List<Passenger> getAllPassengers(){
		return dao.loadAll();
	}
}
