package com.example.TransactionAgency;

import java.util.List;

import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.transaction.annotation.Transactional;

public class PassengerDao {
	private HibernateTemplate hibernateTemplate;

	public HibernateTemplate getHibernateTemplate() {
		return hibernateTemplate;
	}

	public void setHibernateTemplate(HibernateTemplate hibernateTemplate) {
		this.hibernateTemplate = hibernateTemplate;
	}
	
	@Transactional
	public void insertPassenger(Passenger passenger) {
		hibernateTemplate.save(passenger);
	}
	
	@Transactional
	public void updatePassenger(Passenger passenger) {
		hibernateTemplate.update(passenger);
	}
	
	@Transactional
	public void deletePassenger(int id) {
		hibernateTemplate.delete(id);
	}
	
	public Passenger get(int id) {
		return hibernateTemplate.get(Passenger.class, id);
	}
	
	public List<Passenger> loadAll(){
		return hibernateTemplate.loadAll(Passenger.class);
	}
}
