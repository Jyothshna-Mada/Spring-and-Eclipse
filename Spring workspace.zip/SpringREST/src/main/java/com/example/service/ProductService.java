package com.example.service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.entity.Product;
import com.example.repository.ProductRepository;

@Service
public class ProductService {
	
	@Autowired
	private ProductRepository repository;
	
	public Product saveProduct(Product product) {
		return repository.save(product);
	}
	
	public List<Product> getAllProducts(){
		return repository.findAll();
	}
	
	public Optional<Product> getProductById(Long Id){
		return repository.findById(Id);
	}
	

	public void deleteProductById(Long id) {
		repository.deleteById(id);
	}

	public List<Product> getProductsByName(String name) {
		return repository.findByName(name);
	}
	
	@Transactional
	public int updateProductPrice(String name , double price) {
		return repository.updateProductPriceByName(name, price);
	}
	
	
	
}
