package com.example.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.example.entity.Product;

@Repository
public interface ProductRepository extends JpaRepository<Product, Long>{

	
	@Query("SELECT p FROM Product p WHERE p.name=:name")
	List<Product> findByName(@Param("name") String name);
	
	@Modifying
	@Query("Update Product p set p.price= :price where p.name= :name")
	int updateProductPriceByName(@Param("name") String name, @Param("price") double price);
}
