package com.example.BookStore.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.example.BookStore.Entity.Book;
import com.example.BookStore.Service.BookStoreService;

@Controller
@RequestMapping("/books")
public class BookStoreController {

	@Autowired
	private BookStoreService service;
	
//	@PostMapping("/save")
//	public ResponseEntity<Book> addBook(@RequestBody Book book) {
//		Book savedBook=service.save(book);
//		return ResponseEntity.status(HttpStatus.CREATED).body(savedBook);
//	}
//	
//	@PutMapping("/{id}")
//	public ResponseEntity<Book> updateProduct(@PathVariable Integer id, @RequestBody Book Book){
//		Optional<Book> existingProduct = service.getBookById(id);
//		
//		if(existingProduct.isPresent()) {
//			Book.setId(id);
//			Book updateBook = service.save(Book);
//			return ResponseEntity.ok(updateBook);
//		}else
//			return ResponseEntity.notFound().build();
//	}
//	
//	@GetMapping
//	public ResponseEntity<List<Book>> getAllBooks(){
//		List<Book> books=service.findAllBooks();
//		if(books.isEmpty()) {
//			return ResponseEntity.noContent().build();
//		}else
//		return ResponseEntity.ok(books);
//	}
//	
//	@DeleteMapping("/{id}")
//	public ResponseEntity<Void> deleteProductById(@PathVariable Integer id) {
//		service.deleteBookById(id);
//		return ResponseEntity.noContent().build();
//	}
//	
//	@GetMapping("/{id}")
//	public ResponseEntity<Book> getBookById(@PathVariable Integer id) {
//		
//		Book book=service.findAllBookById(id);
//		return ResponseEntity.ok(book);
//	}
//	
//	@GetMapping("/book_title/{title}")
//	public ResponseEntity<List<Book>> getBooksByTitle(@PathVariable String title){
//		
//		List<Book> book=service.findBookByTitle(title);
//		
//		if(book!=null) {
//			return ResponseEntity.ok(book);
//		}else
//		return ResponseEntity.notFound().build();
//	}
//	
//	@GetMapping("/book_publisher/{publisher}")
//	public ResponseEntity<List<Book>> getBooksByPublisher(@PathVariable String publisher){
//	List<Book> books= service.findBookByPublisher(publisher);
//		return ResponseEntity.ok(books);
//	}
//	
//	@GetMapping("/year")
//	public ResponseEntity<List<Book>> getBookByYear(@RequestParam("year") Integer year){
//		List<Book> books= service.findByYear(year);
//			return ResponseEntity.ok(books);
//	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	@GetMapping
	public String getAllBooks(Model model) {
		List<Book> books=service.findAllBooks();
		model.addAttribute("books",books);
		return "books";
	}
	
	@GetMapping("/newBook")
	public String showNewBookForm(Model model) {
		model.addAttribute("book", new Book());
		return "book-form";
	}
	
	@PostMapping("/save")
	public String saveBook(@ModelAttribute("book") Book book) {
		service.save(book);
		return "redirect:/books";
	}
	
	@GetMapping("/edit/{id}")
	public String showEditBookForm(@PathVariable("id") Integer id, Model model) {
		Book book= service.findAllBookById(id);
		model.addAttribute("book",book);
		return "book-form";
	}
	
	@GetMapping("/delete/{id}")
	public String deleteBook(@PathVariable("id") Integer id) {
		service.deleteBookById(id);
		return "redirect:/books";
	}
	
}
