package com.example.BookStore.Entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Book {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;
	private String book_title;
	private String book_publisher;
	private String book_isbn;
	private int book_number_of_pages;
	private Integer year;
	
	public Integer getId() {
		return id;
	}
	
	public void setId(Integer id) {
		this.id = id;
	}
	
	public String getBook_title() {
		return book_title;
	}
	
	public void setBook_title(String book_title) {
		this.book_title = book_title;
	}
	
	public String getBook_publisher() {
		return book_publisher;
	}
	
	public void setBook_publisher(String book_publisher) {
		this.book_publisher = book_publisher;
	}
	
	public String getBook_isbn() {
		return book_isbn;
	}
	
	public void setBook_isbn(String book_isbn) {
		this.book_isbn = book_isbn;
	}
	
	public int getBook_number_of_pages() {
		return book_number_of_pages;
	}
	
	public void setBook_number_of_pages(int book_number_of_pages) {
		this.book_number_of_pages = book_number_of_pages;
	}
	
	public Integer getYear() {
		return year;
	}
	
	public void setYear(Integer year) {
		this.year = year;
	}
		
}
