package com.example.BookStore.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.example.BookStore.Entity.Book;

@Repository
public interface BookStoreRepository extends JpaRepository<Book, Integer>{

	@Query("select b from Book b where b.year= :year")
	List<Book> findByYear(Integer year);

	Book getBookById(Integer id);
	
	@Query("select b from Book b where b.book_title= :title")
	List<Book> findBytitle(@Param("title") String title);
	
	@Query("select b from Book b where b.book_publisher= :publisher")
	List<Book> findByPublisher(@Param("publisher") String publisher);

}
