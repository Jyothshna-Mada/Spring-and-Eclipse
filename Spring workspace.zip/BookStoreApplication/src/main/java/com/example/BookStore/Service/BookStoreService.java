package com.example.BookStore.Service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.BookStore.Entity.Book;
import com.example.BookStore.Repository.BookStoreRepository;

@Service
public class BookStoreService {

	@Autowired
	private BookStoreRepository repository;
	
	public Book save(Book book) {
		return repository.save(book);
	}
	
	public Optional<Book> getBookById(Integer Id){
		return repository.findById(Id);
	}
	
	public void deleteBookById(Integer id) {
		 repository.deleteById(id);
	}
	
	public Book findAllBookById(Integer id) {
		return repository.getBookById(id);
	}
	
	public List<Book> findAllBooks(){
		return repository.findAll();
	}
	
	public List<Book> findBookByTitle(String title){
		return repository.findBytitle(title);
	}
	
	public List<Book> findBookByPublisher(String publisher) {
		return repository.findByPublisher(publisher);
	}
	
	public List<Book> findByYear(Integer year) {
		return repository.findByYear(year);
	}
}
