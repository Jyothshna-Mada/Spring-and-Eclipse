package miniProject_2;

import java.util.ArrayList;
import java.util.List;

public class ShoppingCart {

	private List<Medicine> items =new ArrayList<>();
	
	 public void addItem(Medicine medicine) { 
		 items.add(medicine); 
		 } 
	 
	public void removeItem(Medicine medicine) { 
		 items.remove(medicine); 
		 } 
		 
	public List<Medicine> getItems() { 
		 return items; 
		 } 

		 
	public double calculateTotal() { 
			 double total = 0.0; 
			 for (Medicine medicine : items) { 
			 total += medicine.getPrice(); 
			 } 
			 return total; 
			 } 
		 
	public void clear() { 
			 items.clear(); 
			 } 
			 
} 


