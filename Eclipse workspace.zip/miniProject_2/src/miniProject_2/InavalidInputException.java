package miniProject_2;

public class InavalidInputException extends Exception{

	public InavalidInputException(String message) {
		super(message);
	}
	
}
