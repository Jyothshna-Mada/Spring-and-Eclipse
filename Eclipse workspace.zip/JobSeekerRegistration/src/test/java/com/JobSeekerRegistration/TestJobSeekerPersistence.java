package com.JobSeekerRegistration;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import org.junit.Test;

import com.jobs.register.JobSeekersdetails;

public class TestJobSeekerPersistence {

	JobSeekersdetails job;
	
	@Test
	public void testJobSeeker() {
	job = new JobSeekersdetails("Smitha",25,"B-Tech",3,"Testing",70000);
	JobSeekersdetails retreive = getdetailsFromDB("Smitha");
	
	assertNotNull(retreive); 
	assertEquals("Smitha", retreive.getName()); 
	assertEquals(25, retreive.getAge()); 
	assertEquals("B-Tech", retreive.getQualification()); 
	assertEquals(3, retreive.getExperience()); 
	assertEquals("Testing", retreive.getDomainOfExpertise()); 
	assertEquals(70000, retreive.getSalaryExpected(), 0.01); 
	}
	
	private JobSeekersdetails getdetailsFromDB(String name) {
		if(name!=null && name.equals(job.getName())) {
			return job;
		}
		return null;
	}
}
