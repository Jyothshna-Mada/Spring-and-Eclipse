package com.jobs.register;

public class JobSeekersdetails {
	private String name; 
	private int age; 
	private String qualification; 
	private int experience; 
	private String domainOfExpertise; 
	private double salaryExpected;
	
	public JobSeekersdetails() {
		
	}

	public JobSeekersdetails(String name, int age, String qualification, int experience, String domainOfExpertise,
			double salaryExpected) {
		this.name = name;
		this.age = age;
		this.qualification = qualification;
		this.experience = experience;
		this.domainOfExpertise = domainOfExpertise;
		this.salaryExpected = salaryExpected;
	}

	public String getName() {
		return name;
	}

	public int getAge() {
		return age;
	}

	public String getQualification() {
		return qualification;
	}

	public int getExperience() {
		return experience;
	}

	public String getDomainOfExpertise() {
		return domainOfExpertise;
	}

	public double getSalaryExpected() {
		return salaryExpected;
	}

	@Override
	public String toString() {
		return "JobSeekersdetails [name=" + name + ", age=" + age + ", qualification=" + qualification + ", experience="
				+ experience + ", domainOfExpertise=" + domainOfExpertise + ", salaryExpected=" + salaryExpected + "]";
	}
	
	
	

	

}
