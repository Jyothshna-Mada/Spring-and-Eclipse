package com.example.mvc;

public class RegistrationBusinessException extends Exception{
	private static final long serialVersionUID = 1L;

	public RegistrationBusinessException() {
		super();
	}
	
	public RegistrationBusinessException(String message) {
		super(message);
	}
	
	

}
