package com.example.dbutil;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class HibernateUtil {
	SessionFactory factory;
	Session session;
	public Session getSession() {
		Configuration cfg = new Configuration().configure("hibernate.cfg.xml");
		 factory = cfg.buildSessionFactory();
		 session = factory.openSession();
		return session;
	}
	
	public void closeconnection() {
		session.close();
		factory.close();
	}
	
	

}
