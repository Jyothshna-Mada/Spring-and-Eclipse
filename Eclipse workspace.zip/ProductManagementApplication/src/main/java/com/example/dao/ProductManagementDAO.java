package com.example.dao;

import java.util.List;
import java.util.Scanner;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.example.dbutil.HibernateUtil;
import com.example.domain.Product;

public class ProductManagementDAO {
	
	HibernateUtil h=new HibernateUtil();
	
	public void viewProduct() {
		List<Product> products = h.getSession().createQuery("from Product", Product.class).list();
		  System.out.println("All Product:");
          for (Product pro : products) {
              System.out.println(pro);
          }
          
          h.closeconnection();

	}
	
	public void addProduct(Scanner scn) {
		System.out.println("\n \n");
		System.out.println("-----------------");
		System.out.println("Enter Product ID:");
		System.out.println("------------------");
		String id=scn.nextLine();
		System.out.println("-----------------");
		System.out.println("Enter Product Name:");
		System.out.println("------------------");
		String name=scn.nextLine();
		scn.nextLine();
		System.out.println("-----------------");
		System.out.println("Enter Product Price:");
		System.out.println("------------------");
		String price=scn.nextLine();
		
		Product p1 = new Product(); 
		  p1.setId(id);
			  p1.setName(name);
			  p1.setPrice(price);
			 Session session=h.getSession();
			 session.save(p1); 
			 Transaction insert = session.beginTransaction();
			  insert.commit(); 
			  System.out.println("Record Inserted");
			  
			  h.closeconnection();

		
	}
	
	public void updateProduct(Scanner scn) {
		System.out.println("\n \n");
		System.out.println("-----------------");
		System.out.println("Enter Product ID:");
		System.out.println("------------------");
		String id=scn.nextLine();
		System.out.println("-----------------");
		System.out.println("Enter New Product Name:");
		System.out.println("------------------");
		String name=scn.nextLine();
		System.out.println("-----------------");
		System.out.println("Enter New Product Price:");
		System.out.println("------------------");
		String price=scn.nextLine();
		
		 Session session=h.getSession();
		  Transaction update = session.beginTransaction(); 
		  Product  p1=session.get(Product.class, id); 
		  p1.setName(name);
		  p1.setPrice(price);
		  session.update(p1); 
		  update.commit(); 
		  System.out.println("Updated");
		  
		  h.closeconnection();
		 
	}
	
	public void DeleteProduct(Scanner scn) {
		System.out.println("\n \n");
		System.out.println("-----------------");
		System.out.println("Enter Product ID:");
		System.out.println("------------------");
		String id=scn.nextLine();
		
		 Session session=h.getSession();
		 Transaction delete = session.beginTransaction(); 
		  Product p1 = session.get(Product.class, id); 
		  session.delete(p1); 
		  delete.commit();
		  System.out.println("Deleted");
		  
		  h.closeconnection();
	}
	
	public Product SearchProduct(Scanner scn) {
		System.out.println("\n \n");
		System.out.println("-----------------");
		System.out.println("Enter Product ID:");
		System.out.println("------------------");
		String id=scn.nextLine();
		
		 Session session=h.getSession();
		 session.beginTransaction();
		 Product product=session.get(Product.class, id);
		 
		 h.closeconnection();
		 return product;
       }
	
	}


