package com.example.utils;

public class Main {

	public static void main(String[] args) {
		Utils.printMessage();

	}

}
