package com.example.utils;

public class Utils {
	public static void printMessage() {
		System.out.println("Hello from utils");
	}
}
