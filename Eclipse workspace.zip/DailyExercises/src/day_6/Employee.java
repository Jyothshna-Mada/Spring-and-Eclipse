package day_6;

public class Employee extends User{
	private Integer employeeId;
	
	
 
	public Employee(String name, long[] phoneNo, Integer licenceNo, Integer voterId,Integer employeeId) {
		super(name, phoneNo, licenceNo, voterId);
		this.employeeId=employeeId;
	}
 
	public Employee(String name, long[] phoneNo, Integer licenceNo, String panCardNo,Integer employeeId) {
		super(name, phoneNo, licenceNo, panCardNo);
		this.employeeId=employeeId;
	}
 
	public Employee(String name, long[] phoneNo, String passportNo,Integer employeeId) {
		super(name, phoneNo, passportNo);
		this.employeeId=employeeId;
	}
 
	
 
	public Integer getEmployeeId() {
		return employeeId;
	}
 
	public void setEmployeeId(Integer employeeId) {
		this.employeeId = employeeId;
	}
 
	@Override
	public void display() {
	System.out.println("==========Details of the Employee==========");
		System.out.println("Hurray!! you availed a discount of 10%");
		System.out.println("Registered Id  : "+Register.generateRegisterId(10));
		System.out.println("Name : "+name);
		System.out.println("Phone No's : [ "+phoneNo[0]+" , "+phoneNo[1]+" ]");
		System.out.println("Emp Id : "+employeeId);
		if (passportNo!=null) {
			System.out.println("Passport No : "+passportNo);
		}
			if(licenceNo!=null) {
			System.out.println("licence No : "+licenceNo);
			}
			if (voterId!=null) {
				System.out.println("Voter Id : "+voterId);
			}
			
			if (panCardNo!=null) {
				System.out.println("Pan No : "+panCardNo);
			}
		}
	}

