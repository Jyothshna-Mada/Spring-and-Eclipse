package day_6;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class Options {
	static LocalDate localDate; 
	static LocalTime localTime;
	static final Appointment appointment = new Appointment(); 
	static final DateTimeFormatter format = DateTimeFormatter.ofPattern("dd/MM/yyyy");  

	Scanner scn = new Scanner(System.in);
	
	public void scheduleAppointment() {
		System.out.println("Enter Date (dd/MM/yyyy)");
		String date=scn.next();
		localDate = LocalDate.parse(date,format);
		System.out.println("Enter Time (hh:mm)");
		String time=scn.next();
		
		String hour = Integer.parseInt(time.charAt(0)+"")+""+Integer.parseInt(time.charAt(1)+"");
		String minute = Integer.parseInt(time.charAt(3) + "") + "" + Integer.parseInt(time.charAt(4) + ""); 
		
		localTime = LocalTime.of(Integer.parseInt(hour), Integer.parseInt(minute)); 
		time=localTime+":00";
		
		
		System.out.println("Available ZOnes are: "+"\n"+"A: America/Anchorage"+"\n"+"B: Europe/Paris"+"\n"+"C: Asia/Tokyo"+"\n"+"D: America/Phoenix");
		System.out.println("==========================================");
		System.out.println("Select the zone");
		System.out.println("==========================================");
		String zone=scn.next();
		
		appointment.setDate(date);
		appointment.setTime(time);
		appointment.setZone(zone);
		System.out.println("Successfuly Booked");
	}
	
	
	public String printAppointmentDetails() {
		return appointment.getDate()+" "+appointment.getTime()+" "+appointment.getZone();
	}
	
	public void resheduleAnAppointment() {
		System.out.println("Current Appoitment Date is : ");
		System.out.println(printAppointmentDetails());
		System.out.println("Kindly Enter Number of days to be postponed");
		int days=scn.nextInt();
		
		LocalDate updatedDate = localDate.plusDays(days);     
		String postponedDate = updatedDate.format(format);  

		System.out.println("Enter the new time in HH:MM");
		String time = scn.next();
		
		String hour = Integer.parseInt(time.charAt(0) + "") + "" + Integer.parseInt(time.charAt(1) + ""); 
		String minute = Integer.parseInt(time.charAt(3) + "") + "" + Integer.parseInt(time.charAt(4) + ""); 

		localTime = LocalTime.of(Integer.parseInt(hour), Integer.parseInt(minute)); 
		
		appointment.setDate(postponedDate); 
		appointment.setTime(time); 

		System.out.print("Your Appointment has been resheduled to: ");
		
		System.out.println(appointment.getDate() + " " + appointment.getTime()); 
		
	}
	
	public void getRemainder() {
		String appointmentDate = appointment.getDate(); 
		LocalDate reminderDate = LocalDate.parse(appointmentDate, format); 
		reminderDate = reminderDate.plusDays(-1); 
		String reminder = reminderDate.format(format); 
		System.out.println(reminder+" "+appointment.getTime()); 

	}
	
	public void cancelAppointment() {
			System.out.println("Your Appointment is Cancelled");
		}
	
	
	public void exit() {
		System.out.println("Exiting...");
	}

}
