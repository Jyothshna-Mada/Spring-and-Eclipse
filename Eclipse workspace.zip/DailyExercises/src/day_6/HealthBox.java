package day_6;

import java.util.Scanner;

public class HealthBox {
	static final Scanner scn = new Scanner(System.in);
	
	public static void main(String[] args) {
	
		int n;
		Options o = new Options();
		
		do {
			System.out.println("1.Schedule an Appointment."+"\n"+
					   "2.Print Appointment Details."+"\n"+
					   "3.Reschedule an Appointment."+"\n"+
					   "4.Get Remainder"+"\n"+
					   "5.Cancel the Appointments."+"\n"+
					   "6.Exit."
						);
	System.out.println("=====================================");
	System.out.println("Enter an Option");
	System.out.println("=====================================");
	
	n = scn.nextInt();
	
	switch (n) {
	case 1: {
	o.scheduleAppointment();
	}break;
	case 2: {
		System.out.println(o.printAppointmentDetails());
	}break;
	case 3: {
		o.resheduleAnAppointment();
	}break;
	case 4: {
		o.getRemainder();
	}break;
	case 5: {
		o.cancelAppointment();
	}break;
	case 6: {
		o.exit();
	}break;
	
	default: 
		System.out.println("Please Enter valid Option");

}
		} while (n!=6);

}
}
