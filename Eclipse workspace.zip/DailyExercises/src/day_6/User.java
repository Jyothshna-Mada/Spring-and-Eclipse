package day_6;

public abstract class User {
	protected String name;
	protected long[] phoneNo=new long[2];
	protected String passportNo;
	protected Integer licenceNo;
	protected String panCardNo;
	protected Integer voterId;
	
	public User(String name, long[] phoneNo, String passportNo) {
		this.name = name;
		this.phoneNo = phoneNo;
		this.passportNo = passportNo;
	}
 
	public User(String name, long[] phoneNo, Integer licenceNo, String panCardNo) {
		this.name = name;
		this.phoneNo = phoneNo;
		this.licenceNo = licenceNo;
		this.panCardNo = panCardNo;
	}
 
	public User(String name, long[] phoneNo, Integer licenceNo, Integer voterId) {
		this.name = name;
		this.phoneNo = phoneNo;
		this.licenceNo = licenceNo;
		this.voterId = voterId;
	}
 
	public String getName() {
		return name;
	}
 
	public void setName(String name) {
		this.name = name;
	}
 
	public long[] getPhoneNo() {
		return phoneNo;
	}
 
	public void setPhoneNo(long[] phoneNo) {
		this.phoneNo = phoneNo;
	}
 
	public String getPassportNo() {
		return passportNo;
	}
 
	public void setPassportNo(String passportNo) {
		this.passportNo = passportNo;
	}
 
	public Integer getLicenceNo() {
		return licenceNo;
	}
 
	public void setLicenceNo(Integer licenceNo) {
		this.licenceNo = licenceNo;
	}
 
	public String getPanCardNo() {
		return panCardNo;
	}
 
	public void setPanCardNo(String panCardNo) {
		this.panCardNo = panCardNo;
	}
 
	public Integer getVoterId() {
		return voterId;
	}
 
	public void setVoterId(Integer voterId) {
		this.voterId = voterId;
	}
	
	
	public abstract void display();
}


