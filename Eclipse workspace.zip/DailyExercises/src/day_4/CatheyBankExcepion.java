package day_4;

public class CatheyBankExcepion extends Exception{
	
	public CatheyBankExcepion(String message) {
		super(message);
	}

}
