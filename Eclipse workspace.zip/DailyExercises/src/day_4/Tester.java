package day_4;

import java.util.Scanner;

public class Tester {

	public static void main(String[] args) {
		Scanner scn = new Scanner(System.in); 
		System.out.println("Enter Player Name: "); 
		String Name=scn.next(); 
		System.out.println("Enter Critic1: "); 
		float Critic1 = scn.nextFloat(); 
		System.out.println("Enter Critic2: "); 
		float Critic2 = scn.nextFloat(); 
		System.out.println("Enter Critic3: "); 
		float Critic3 = scn.nextFloat(); 


		CricketRating c = new CricketRating("John", 9.3f, 9.67f, 8.7f); 
		c.calculateAverageRating(Critic1, Critic2, Critic3); 
		try {
			String d= c.calculateCoins(); 
			c.display(); 
			System.out.println("Coins Earned : "+d); 

		} catch (Exception e) {
			System.out.println("Not Eligible"); 
		}

	}

}
