package day_4;

import java.util.Scanner;

public class BankUser {

	public static void main(String[] args) {
		Scanner scn = new Scanner(System.in); 
		System.out.println("Enter Acc Num: "); 
		int AccNum=scn.nextInt(); 
		System.out.println("Enter Customer Name: "); 
		String name = scn.next(); 
		System.out.println("Enter Account Type: "); 
		String AccType=scn.next(); 
		System.out.println("Enter Initial Balance: "); 
		float money = scn.nextFloat(); 


		BankAccount a= new BankAccount(AccNum, name, AccType, money); 
		
		try { 
			a.deposite(money); 
		} catch (Exception e) { 
			System.out.println("Negative Amount"); 
		} 
		
		try { 
			System.out.println("Your Balance is "+a.getBalance()); 
		} catch (Exception e) {
			System.out.println("Low Balance");
		}

	}

}
