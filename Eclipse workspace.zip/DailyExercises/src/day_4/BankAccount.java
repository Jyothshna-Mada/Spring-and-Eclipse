package day_4;

public class BankAccount {
	int accNo;
	String custName;
	String accType;
	float balance;
	public BankAccount(int accNo, String custName, String accType, float balance) {
		this.accNo = accNo;
		this.custName = custName;
		this.accType = accType;
		this.balance = balance;
	}
	
	public void deposite(float amt) throws NegativeAmountException { 
		if (amt<0) { 
			NegativeAmountException e = new NegativeAmountException(); 
			throw e; 
		}
		else {
			balance+=amt;
			System.out.println("Money Credited");
		}
			
		}
	

	
	public float getBalance() throws LowBalanceException {
		
			if (accType.equalsIgnoreCase("Current")) { 
			if (balance<5000) { 
			LowBalanceException a= new LowBalanceException(); 
			throw a; 
			}
		} 
if (accType.equalsIgnoreCase("Savings")) { 
		if (balance<1000) { 
			LowBalanceException a = new LowBalanceException(); 
			throw a; 
		}
	}

		return balance;
	}
	
}
