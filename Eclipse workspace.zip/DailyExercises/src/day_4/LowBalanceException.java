package day_4;

public class LowBalanceException extends Exception{

}
