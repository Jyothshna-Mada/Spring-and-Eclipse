package day_4;

public class NegativeAmountException extends Exception {

}
