package day_4;

public class NotEligibleException extends Exception {

}
