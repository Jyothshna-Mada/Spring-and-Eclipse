package day_3;

import java.util.Random;

public class TestMedicine {

	public static void main(String[] args) {
	MedicalInfo[] medicines = new MedicalInfo[10];
	Random r1 = new Random();
	
	for(int i=0;i<medicines.length;i++) {
		int num=r1.nextInt(3)+1;
		switch(num) {
		case 1:
			medicines[i]=new Tablet();
			break;
			
		case 2:
			medicines[i]=new Syrup();
			break;
		
		case 3:
			medicines[i]=new Ointment();
			break;
			}
		}
	for(MedicalInfo medicine: medicines) {
			medicine.displayLabel();
			System.out.println();
		}
	}

}
