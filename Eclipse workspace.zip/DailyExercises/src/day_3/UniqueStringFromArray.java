package day_3;

public class UniqueStringFromArray {

	public static void main(String[] args) {
		String a[] = {"Article","for","Apple","for","Grapes"};
		String b[] = {"Article","Apple","Grape"};
		int n1=a.length;
		int n2=b.length;

		for(int i=0;i<n1;i++) {
			for(int j=0;j<n2;j++) {
				if(a[i].equals(b[j])) {
					System.out.println(a[i]);
					b[j]=null;
					break;
				}
			}
		}

	}

}
