package day_3;

public class ExtractFirstLetter {

	public static void main(String[] args) {
		String s1="Practice Java Program";
		String s2="";
		boolean status=true;
		
		for(int i=0;i<s1.length();i++) {
		if(s1.charAt(i)==' ') {
			status=true;
			}
		else if(s1.charAt(i)!=' '&& status==true) {
			s2+=(s1.charAt(i));
			status=false;
		}
		}
		System.out.println(s2);
	}
}


