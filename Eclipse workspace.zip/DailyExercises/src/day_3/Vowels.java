package day_3;

import java.util.Scanner;

public class Vowels {

	public static void main(String[] args) {
	Scanner scn = new Scanner(System.in);
	System.out.println("Enter String");
	String s1 = scn.nextLine().toLowerCase();
	System.out.println("Enter number to count vowels");
	int num=scn.nextInt();
	
	String vowel=countVowel(s1,num);
	if(vowel.equals("Mismatch"))
		System.out.println("Mismatch in vowel count");
	else
		System.out.println("Number of last vowels "+vowel);

	}
	
	public static String countVowel(String s,int num) {
		int count=0;
		StringBuilder sb=new StringBuilder();
		
		for(int i=s.length()-1;i>=0;i--) {
			char ch=s.charAt(i);
			if(isvowel(ch)) {
				sb.insert(0, ch);
				count++;
				if(count==num) {
					break;
				}
			}
		}
		if(count<num) {
			return "Mismatch";
		}
		return sb.toString();
		
	}
	
	public static boolean isvowel(char s) {
		s=Character.toLowerCase(s);
		return s=='a'||s=='e'||s=='i'||s=='o'||s=='u';
		
	}

}
