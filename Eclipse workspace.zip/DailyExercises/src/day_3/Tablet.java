package day_3;

public class Tablet implements MedicalInfo{

	@Override
	public void displayLabel() {
		System.out.println("Company Name: axioen");
		System.out.println("Company Address: Amal building near raguda road,mumbai,india");
		System.out.println("Store in a cool Dry place");
		
	}

}
