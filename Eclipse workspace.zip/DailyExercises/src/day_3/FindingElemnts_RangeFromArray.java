package day_3;

import java.util.Scanner;

public class FindingElemnts_RangeFromArray {

	public static void main(String[] args) {
		
		Scanner scn = new Scanner(System.in);
		System.out.println("Enter two numbers which ranges from 1 to 40");
		
		int n1=scn.nextInt();
		int n2=scn.nextInt();
	
	if(n1<1 ||n1>40||n2<1||n2>40) {
		System.out.println("Both numbers should be in the range 1 to 40");
		return;
	}
	
	int [] numbers = {7,25,5,19,30};
	boolean num1found=false;
	boolean num2found=false;
	
	for(int i=0;i<numbers.length;i++) {
		if(n1==numbers[i]) {
			num1found=true;
		}
		if(n2==numbers[i]) {
			num2found=true;
		}
	}
	if(num1found && num2found)
		System.out.println("Its Bingo");
	else
		System.out.println("Not Found");
	
	}
}
