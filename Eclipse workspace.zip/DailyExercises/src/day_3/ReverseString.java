package day_3;

public class ReverseString {

	public static void main(String[] args) {
		String s1="abc";
		System.out.println(rev(s1));
	}
	public static String  rev(String s1) {
		if(s1.length()==0)
			return s1;
		int len=s1.length();
		return s1.charAt(len-1)+rev(s1.substring(0,len-1));
		
	}

}
