package day_3;

public interface MedicalInfo {
	void displayLabel();

}
