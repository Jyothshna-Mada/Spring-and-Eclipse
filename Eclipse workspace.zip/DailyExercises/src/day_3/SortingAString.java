package day_3;

import java.util.Arrays;

public class SortingAString {

	public static void main(String[] args) {
		String s1="javaprogram";
		char[] s2=s1.toCharArray();
		Arrays.sort(s2);
		for(char c:s2) {
			System.out.print(c);
		}

	}

}
