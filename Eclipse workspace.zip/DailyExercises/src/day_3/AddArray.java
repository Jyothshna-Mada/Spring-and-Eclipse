package day_3;

public class AddArray {

	public static void main(String[] args) {
	int A[]= {3,2,4,5,6,4,5,7,3,2,3,4,7,1,2,0,0,0};
	
	int sum=0;
		for(int i=0;i<=14;i++) {
			sum+=A[i];
		}
		
		A[15]=sum;
		
		double avg=0;
		for(int num:A) {
			avg+=num;
		}
		avg=avg/A.length;
		A[16]=(int)avg;
		
		int small=A[0];
		for(int i=0;i<A.length;i++)
		{
			if(A[i]<small) {
				small=A[i];
			}
		}
		A[17]=small;
		
		for(int num:A) {
			System.out.print(num+" ");
		}
	}

}
