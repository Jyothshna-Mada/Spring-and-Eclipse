package day_3;

public class EvenLengthOfString {

	public static void main(String[] args) {
		String s1="This is a java language";
		String[] arr=s1.split(" ");
		String s2="";
		
		for(int i=0;i<arr.length;i++) {
			s2+=Even(arr[i]);
			if(i<arr.length-1)
				s2+=" ";
		}
		System.out.println(s2);
	}
	static String Even(String s) {
		int len=s.length();
		if(len%2==0)
			return s;
		else
			s="";
		return new String(s);
	}

}
