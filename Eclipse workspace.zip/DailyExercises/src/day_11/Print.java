package day_11;

public class Print {
	public static synchronized void p(String s) {
		for (int i = 1; i < 11; i++) {
			System.out.println(s+" "+i);
			try {
				Thread.sleep(500);
			} catch (InterruptedException e) {
				
			}
		}
	}

}
