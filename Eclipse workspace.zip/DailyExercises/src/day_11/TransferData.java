package day_11;

public class TransferData {
	private int number=-2;
	private boolean isNumberAvailable=false;
	private boolean isEndOfFile=false;
	
	public synchronized void setNumber(int number) throws InterruptedException {
		while(isNumberAvailable) {
			wait();
		}
		this.number=number;
		isNumberAvailable=true;
		notifyAll();
	}
	public synchronized int getNumber() throws InterruptedException {
		while(!isNumberAvailable && !isEndOfFile) {
			wait();
		}
		isNumberAvailable=false;
		notifyAll();
		return number;
	}
	
	public synchronized void setEndOfFile() {
		isEndOfFile=true;
		notifyAll();
	}
	
	public synchronized boolean isEndOfFile() {
		return isEndOfFile;
	}

}
