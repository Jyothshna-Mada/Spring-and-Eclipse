package day_11;

public class Main {

	public static void main(String[] args) {
		Storage s = new Storage();
		
		Counter c = new Counter(s);
		Printer p1 = new Printer(s);
 
		c.start();
		p1.start();

	}

}
