package day_11;

public class PrintNumbers {

	public static void main(String[] args) {
		Print p1 = new Print();
		Print p2 = new Print();
		Print p3 = new Print();
 
		new Driver(p1,"Thread_1").start();
		new Driver(p2,"Thread_2").start();
		new Driver(p3,"Thread_3").start();
		
 
	}

}
