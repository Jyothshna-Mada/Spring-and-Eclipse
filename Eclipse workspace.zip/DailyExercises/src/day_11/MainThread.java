package day_11;

import java.util.Scanner;

public class MainThread {

	public static void main(String[] args) {
		Scanner scn = new Scanner(System.in);
		System.out.println("Enter file Name");
		String filename =scn.nextLine();
		TransferData td = new TransferData();
		ReadFile file = new ReadFile(filename, td);
		CalculateFact fact = new CalculateFact(td);
		file.start();
		fact.start();
		
		try {
			file.join();
			fact.join();
		}catch (InterruptedException e) {
			e.printStackTrace();
		}
		

	}

}
