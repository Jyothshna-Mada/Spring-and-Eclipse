package day_8;

import java.util.Stack;

public class MinElementStack {

	public static void main(String[] args) {
		Stack<Integer> stack = new Stack<Integer>();
		
		stack.push(16);
		stack.push(15);
		stack.push(29);
		stack.push(19);
		stack.push(18);
		
		int min=stack.peek();
		
		for(Integer s:stack) {
			if(s<min) {
				min=s;
			}
		}
		
		System.out.println(min);

	}

}
