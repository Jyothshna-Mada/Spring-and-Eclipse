package day_8;

public class CircularMain {

	public static void main(String[] args) {
	CircularQueue c = new CircularQueue(10);
	c.enqueue(14);
	c.enqueue(13);
	c.enqueue(22);
	c.enqueue(-8);
	
	c.dequeue();
	
	while(c.size()>0) {
		System.out.print(c.dequeue()+" ");
	}
	}

}
