package day_8;

public class StackLinkedListMain {

	public static void main(String[] args) {
		StackUsingLinkedList s1 = new StackUsingLinkedList();
		
		s1.push(null);
		s1.push(10.0);
		s1.push(20.0);
		s1.push(30.0);
		s1.push(40.0);
		
		System.out.print("The elements of the stack are: ");
		s1.printStack();
		
		s1.pop();
		s1.pop();
		System.out.print("After popping twice: ");
		s1.printStack();
	}

}
