package day_8;

public class StackArrayMain {

	public static void main(String[] args) {
		StackUsingArray s = new StackUsingArray(10);
		s.push("Hello");
		s.push("world");
		s.push("java");
		s.push("programming");
		
		System.out.print("After pushing "+s.size()+" Elements: ");
		s.printStack();
		
		s.pop();
		System.out.print("After a pop: ");
		s.printStack();

		
	}

}
