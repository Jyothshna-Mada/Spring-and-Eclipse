package day_8;

import java.util.LinkedList;
import java.util.Queue;

public class CheckQueueEmpty {

	public static void main(String[] args) {
		Queue<String> item = new LinkedList<String>();
		
		item.add("Yellow");
		item.add("Green");
		item.add("Pink");
		item.add("Black");
		item.add("Blue");
		item.add("White");
		
		if(!item.isEmpty())
			System.out.println("Not Empty");
		else
			System.out.println("Empty");
	}

}
