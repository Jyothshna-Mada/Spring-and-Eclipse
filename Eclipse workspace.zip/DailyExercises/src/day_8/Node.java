package day_8;

public class Node {
	Object element;
	Node next;
	
	Node(Object element){
		this.element=element;
		this.next=null;
	}

}
