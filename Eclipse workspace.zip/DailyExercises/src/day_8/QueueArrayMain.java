package day_8;

public class QueueArrayMain {

	public static void main(String[] args) {
		QueueUsingArray q = new QueueUsingArray(5);
		q.add(10);
		q.add(20);
		q.add(30);
		q.add(40);
		q.pop();
		while(q.size()>0) {
			System.out.println(q.pop());
		}
		
	}

}
