package day_8;

public class StackUsingLinkedList {

	static int size=0;
	Node top;
	
	public StackUsingLinkedList(){
		this.top=null;
	}
	public void push(Object element) {
		Node node = new Node(element);
		node.next=top;
		top=node;
		size++;
	}
	
	public boolean isEmpty() {
		return top==null;
	}
	
	public int size() {
		return size;
	}
	
	public Object pop() {
		if(isEmpty()) {
			System.out.println("Stack under flow");
			return null;
		}
		Object ele=top.element;
		top=top.next;
		size--;
		return ele;
	}
	
	
	public void printStack() {
		if(isEmpty()) {
			System.out.println("Stack is Empty");
			return;
		}
		Node curr=top;
		while(curr!=null) {
			System.out.print(curr.element+" ");
			curr=curr.next;
		}
		System.out.println();
	}
}
