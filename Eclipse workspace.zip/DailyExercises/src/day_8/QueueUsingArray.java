package day_8;

public class QueueUsingArray {

	private int[] queue;
	private int capacity;
	private int front;
	private int rear;
	private int count;
	
	public QueueUsingArray(int size) {
		queue = new int[size];
		capacity=size;
		front=0;
		rear=-1;
		count=0;
	}
	
	public int size() {
		return count;
	}
	
	public boolean isEmpty() {
        return count== 0;
    }
	
	 public boolean isFull() {
	        return count == capacity;
	    } 
	 
	 public void add(int element) {
		 if(isFull()) {
				System.out.println("Overflow");
				return;
			}
		 rear=(rear+1)%capacity;
		 queue[rear]=element;
		 count++;
	 }
	 
	 public int pop() {
		 if(isEmpty()) {
				System.out.println("Underflow");
				return -1;
			}
		 int ele = queue[front];
		 front = (front+1)%capacity;
		 count--;
		 return ele;
	 }
	 

	 public int peek() {
	        if (isEmpty()) {
	            System.out.println("Underflow\nProgram Terminated");
	            System.exit(-1);
	        }
	        return queue[front];
	    }

}
