package day_2;

import java.util.Scanner;

public class FindingGrade {

	public static void main(String[] args) {
		Scanner scn = new Scanner(System.in);
		System.out.println("Enter n value");
		int n = scn.nextInt();
		
		if(n>=0 && n<=100) {
			if(n>=60) {
				System.out.println("A Grade");
			}
			else if(n>=45) {
				System.out.println("B Grade");
			}
			else if(n>=35) {
				System.out.println("C Grade");
			}
			else System.out.println("Fail");
		}
		else
			System.out.println("Enter number between 1-100");

	}

}
