package day_2;

import java.util.Scanner;

public class Armstrong {

	public static void main(String[] args) {
		Scanner scn = new Scanner(System.in);
		System.out.println("Enter Start number: ");
		int start = scn.nextInt();
		System.out.println("Enter end number: ");
		int end = scn.nextInt();
		
		for(int i=start;i<=end;i++) {
			int num=i;
			int num1=i;
			int count=0;
			int sum=0;
			while(num>0) {
				count++;
				num=num/10;
			}
			while(num1>0) {
				int rem=num1%10;
				int result=1;
				for(int j=1;j<=count;j++) {
					result=result*rem;
				}
				sum=sum+result;
				num1=num1/10;
			}
			if(sum==i)
				System.out.println(i);
		}
	}

}
