package day_2;

import java.util.Scanner;

public class CharCheck {

	public static void main(String[] args) {
		Scanner scn = new Scanner(System.in);
		System.out.println("Enter a character");
		char ch = scn.next().charAt(0);
		if(ch=='A'||ch=='E'||ch=='I'||ch=='O'||ch=='U'||ch=='a'||ch=='e'||ch=='i'||ch=='o'||ch=='u') {
			System.out.println("Entered Character is Vowel");
		}
		else
			System.out.println("Entered Charecter is Consonant");
		
	}

}
