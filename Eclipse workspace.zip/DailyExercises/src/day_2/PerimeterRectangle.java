package day_2;

import java.util.Scanner;

public class PerimeterRectangle {

	public static void main(String[] args) {
		Scanner scn = new Scanner(System.in);
		System.out.println("Enter two value");
		int length= scn.nextInt();
		int breadth= scn.nextInt();
		double perimeter=(length+breadth)*2;
		System.out.println("The perimeter of th erectangle is: "+perimeter);

	}

}
