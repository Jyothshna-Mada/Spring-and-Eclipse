package day_2;

import java.util.Scanner;

public class Lcm {

	public static void main(String[] args) {
		Scanner scn = new Scanner(System.in);
		System.out.println("Enter two value");
		int n1= scn.nextInt();
		int n2= scn.nextInt();
		int lcm = n1>n2?n1:n2;
		
		while(true) {
			if(lcm%n1==0 && lcm%n2==0) {
				System.out.println(n1+" and "+n2+" lcm is "+lcm);
				break;
			}
			lcm++;
			
		}
	}

}
