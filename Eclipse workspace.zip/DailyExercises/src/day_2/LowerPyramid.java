package day_2;

import java.util.Scanner;

public class LowerPyramid {

	public static void main(String[] args) {
		Scanner scn = new Scanner(System.in);
		System.out.println("Enter a number");
		int num = scn.nextInt();
		int stars=num*2-1;
		int spaces=0;
		for(int i=1;i<=num;i++) {
			for(int i1=1;i1<=spaces;i1++) {
				System.out.print(" "+" ");
			}
			for(int j=1;j<=stars;j++) {
				System.out.print("*"+" ");
			}
			spaces++;
			stars=stars-2;
			System.out.println(" ");
		}

	}

}
