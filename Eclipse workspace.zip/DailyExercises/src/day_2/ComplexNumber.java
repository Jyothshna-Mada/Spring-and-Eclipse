package day_2;

public class ComplexNumber {
	int real;
	int imaginary;
	
	

	public ComplexNumber(int real, int imaginary) {
		this.real = real;
		this.imaginary = imaginary;
	}

	public void show() {
		System.out.println(this.real+" +i"+ this.imaginary);
	}
	
	public static ComplexNumber add(ComplexNumber n1,ComplexNumber n2) {
		ComplexNumber res= new ComplexNumber(0, 0);
		res.real=n1.real+n2.real;
		
		res.imaginary=n1.imaginary+n2.imaginary;
		return res;
		
	}


	public static void main(String[] args) {
		ComplexNumber c1 = new ComplexNumber(4, 5);
		ComplexNumber c2 = new ComplexNumber(10, 5);
		
		ComplexNumber res=add(c1,c2);
		res.show();
	}

}
