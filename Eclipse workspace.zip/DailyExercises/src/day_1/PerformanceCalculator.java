package day_1;

public class PerformanceCalculator {

	public static void main(String[] args) {
		Employee e1 = new Employee();
		e1.setName("Raghav");
		e1.setPoint(75);
		Employee e2 = new Employee();
		e2.setName("Sowmya");
		e2.setPoint(89);
		Employee e3 = new Employee();
		e3.setName("Alokha");
		e3.setPoint(58);
		Employee e4 = new Employee();
		e4.setName("Amol");
		e4.setPoint(94);
		Employee e5 = new Employee();
		e5.setName("Bhavana");
		e5.setPoint(34);
		
		System.out.println("Total number of Employees: 5 and Their Ratings are");
		PerformanceRating.calculatePerformance(e1);
		PerformanceRating.calculatePerformance(e2);
		PerformanceRating.calculatePerformance(e3);
		PerformanceRating.calculatePerformance(e4);
		PerformanceRating.calculatePerformance(e5);

	}

}
