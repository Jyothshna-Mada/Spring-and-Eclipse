package day_1;

public class MotorCycle extends Vehicle{
	private String engineCapacity;

	public String getEngineCapacity() {
		return engineCapacity;
	}

	public void setEngineCapacity(String engineCapacity) {
		this.engineCapacity = engineCapacity;
	}
	
	public MotorCycle() {
		
	}
	public MotorCycle(String manufacturer, String model, int year, String engineCapacity) {
		super(manufacturer, model, year);
		this.engineCapacity = engineCapacity;
	}

	@Override
	public void displayDetails() {
		System.out.println("MotorCycle Manufacturer: "+getManufacturer());
		System.out.println("MotorCycle Model: "+getModel());
		System.out.println("MotorCycle Year: "+getYear());
		System.out.println("MotorCycle Engine Capacity: "+getEngineCapacity());
	}
	
	public void startEngine() {
		System.out.println("Engine Started");
	}
	public void stopEngine() {
		System.out.println("Engine Stoped");
	}

}
