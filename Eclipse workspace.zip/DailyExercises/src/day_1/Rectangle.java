package day_1;

public class Rectangle {
	private float length=1.0f;
	private float breadth=1.0f;
	private double area;
	private double perimeter;
	
	public double getLength() {
		return length;
	}
	public void setLength(float length) {
			this.length = length;
	}
	public double getBreadth() {
		return breadth;
	}
	public void setBreadth(float breadth) {
			this.breadth = breadth;
	}
	public double getArea() {
		return area;
	}
	public void setArea(double area) {
		this.area = area;
	}

	public double getPerimeter() {
		return perimeter;
	}
	public void setPerimeter(double perimeter) {
		this.perimeter = perimeter;
	}
	
	Rectangle(){
		
	}
	Rectangle(float length,float breadth){
		this.length=length;
		this.breadth=breadth;
	}
	public  boolean check()
	{
		if(length>0.0 && length<20.0) {
			if(breadth>0.0 && breadth<20.0) {
				return true;
			}
		}
		return false;
		
	}
	public void calcArea() {
		if(check()) {
			area = length*breadth;
		}
		else 
			System.out.println("Enter values which are more than zero and less than 20");
	}
	
	public void calcPerimeter() {
		if(check()) {
			perimeter=(length+breadth)*2;
		}
		else
			System.out.println("Enter values which are more than zero and less than 20");	
	}
	
	public void display() {
		System.out.println("The length of the rectangle is : "+length);
		System.out.println("The breadth of the rectangle is : "+breadth);
		System.out.println("Area of the rectangle is :"+area);
		System.out.println("Perimeter of the rectangle is :"+perimeter);
	}

}
