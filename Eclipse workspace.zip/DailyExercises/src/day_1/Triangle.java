package day_1;

public class Triangle extends Shape{
	double breadth;
	double height;
	double area;
	
	
	
	public Triangle(double breadth, double height) {
		super();
		this.breadth = breadth;
		this.height = height;
	}

	@Override
	public void calculateArea() {
		area = 0.5 *(breadth*height);
		System.out.println("The area of Triangle is: "+area);
	}

}
