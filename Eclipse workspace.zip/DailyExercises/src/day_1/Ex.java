package day_1;

public class Ex {

	public static void main(String[] args) {
		int y=0;
		int z=0;
		
		for(int i=0;i<3;i++) {
			z++;
			++y;
			z+=--z+y++;
		}
		
		if(z<y) {
			System.out.println(z);
		}
		else {
			System.out.println(z-1);
		}
	}

}
