package day_1;

public class Rectangle1 extends Shape{
	double length;
	double breadth;
	double area;
	
	
	public Rectangle1(double length, double breadth) {
		super();
		this.length = length;
		this.breadth = breadth;
	}


	@Override
	public void calculateArea() {
		area=length*breadth;
		System.out.println("The area of Rectangle is: "+area);
		
	}

}
