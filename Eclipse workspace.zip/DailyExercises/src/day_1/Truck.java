package day_1;

public class Truck extends Vehicle{
	private int cargoCapacity;

	public int getCargoCapacity() {
		return cargoCapacity;
	}

	public void setCargoCapacity(int cargoCapacity) {
		this.cargoCapacity = cargoCapacity;
	}
	
	public Truck() {
		
	}

	public Truck(String manufacturer, String model, int year, int cargoCapacity) {
		super(manufacturer, model, year);
		this.cargoCapacity = cargoCapacity;
	}

	@Override
	public void displayDetails() {
		System.out.println("Truck Manufacturer: "+getManufacturer());
		System.out.println("Truck Model: "+getModel());
		System.out.println("Truck Year: "+getYear());
		System.out.println("Truck Cargo Capacity: "+getCargoCapacity());
	}
	
	public void loadCargo() {
		System.out.println("Cargo loaded successfully");
	}
	
	public void unloadCargo() {
		System.out.println("cargo unloaded successfully");
	}

}
