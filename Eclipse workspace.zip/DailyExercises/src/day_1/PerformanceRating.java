package day_1;

public class PerformanceRating {
	 int outStanding=5;
	 int good=4;
	 int average=3;
	 int poor=2;
	 static int count=0;
	 
	static void calculatePerformance(Employee e) {
		count++;
		int grade=range(e.getPoint());
		System.out.println(e.getName()+" has performed with a Rating "+grade);
		System.out.println("=========================================");
		
	}
	public static int range(int point) {
		if(point>=80 && point<=100)
			return 5;
		if(point>=60 && point<=79)
			return 4;
		if(point>=50 && point<=59)
			return 3;
		return 2;
	}
}
