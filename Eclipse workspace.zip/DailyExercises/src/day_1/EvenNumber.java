package day_1;
import java.util.Scanner;

public class EvenNumber {

	public static void main(String[] args) {
	Scanner scn= new Scanner(System.in);
		System.out.println("Enter n value");
		int n=scn.nextInt();
		System.out.println("Even numbers lesser than or equal to "+n+" is: ");
		for(int i=1;i<=n;i++) {
			if(i%2==0 && i==n)
			{
				System.out.println(i);
				return;
			}
			if(i%2==0)
			{
				System.out.print(i+" , ");
			}
		}
	}

}
