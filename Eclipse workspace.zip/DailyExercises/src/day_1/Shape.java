package day_1;

public abstract class Shape {
	public abstract void calculateArea();

}
