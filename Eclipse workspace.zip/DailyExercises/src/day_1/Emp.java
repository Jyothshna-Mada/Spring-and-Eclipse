package day_1;

public class Emp {
	
	int employeeNumber;
	String employeeName;
	Date joiningDate;
	
	

	public Emp(int employeeNumber, String employeeName, Date joiningDate) {
		this.employeeNumber = employeeNumber;
		this.employeeName = employeeName;
		this.joiningDate = joiningDate;
	}
	
	public void display() {
		System.out.println("Employee Number is: "+this.employeeNumber);
		System.out.println("Employee Name is: "+this.employeeName);
		System.out.println("Joining date of an employee: "+this.joiningDate.toString()+"\n");
	}



	public static void main(String[] args) {
		Date d1=new Date(12,7,2014);
		Date d2=new Date(30,1,2003);
		Date d3=new Date(23,9,2019);
		Date d4=new Date(29,11,2019);
		Date d5=new Date(6,4,2019);
		
		Emp e1 = new Emp(209,"Ramu",d1);
		Emp e2 = new Emp(216,"Rekha",d2);
		Emp e3 = new Emp(245,"Amulya",d3);
		Emp e4 = new Emp(356,"lavanya",d4);
		Emp e5 = new Emp(783,"bhuvan",d5);
		
		e1.display();
		e2.display();
		e3.display();
		e4.display();
		e5.display();
		
	}

}
