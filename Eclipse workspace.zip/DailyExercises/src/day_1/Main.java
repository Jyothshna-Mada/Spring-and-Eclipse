package day_1;

public class Main {

	public static void main(String[] args) {
		Car c1 = new Car();
		MotorCycle m1 = new MotorCycle();
		Truck t1 = new Truck();
		
		c1.setManufacturer("TATA");
		c1.setModel("tata3.0");
		c1.setYear(2001);
		c1.setSeatingCapacity(5);
		c1.displayDetails();
		c1.accelerate();
		c1.brake();
		System.out.println("***********************************");
		
		m1.setManufacturer("Enfield");
		m1.setModel("royal32");
		m1.setYear(2015);
		m1.setEngineCapacity("123cc");
		m1.displayDetails();
		m1.startEngine();
		m1.stopEngine();
		System.out.println("***********************************");
		
		t1.setManufacturer("Hercules");
		t1.setModel("hercu53.0");
		t1.setYear(2020);
		t1.setCargoCapacity(19000);
		t1.displayDetails();
		t1.loadCargo();
		t1.unloadCargo();

	}

}
