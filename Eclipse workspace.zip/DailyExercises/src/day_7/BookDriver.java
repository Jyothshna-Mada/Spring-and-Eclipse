package day_7;

import java.time.LocalDate;
import java.util.Comparator;
import java.util.SortedSet;
import java.util.TreeSet;

public class BookDriver {

	public static void main(String[] args) {
SortedSet<Book> s = new TreeSet<Book>();
		
		LocalDate d = LocalDate.of(2020, 2, 2);
		LocalDate d1 = LocalDate.of(1997, 5, 19);
		LocalDate d2 = LocalDate.of(1984, 11, 23);
		LocalDate d3= LocalDate.of(1984, 11, 19);
		LocalDate d4 = LocalDate.of(1984, 3, 6);
		
		s.add(new Book(1001, "Python Progamming", 715.0, d,"Martin C.Brown" ));
		s.add(new Book(1002, "Modern Mainframe", 295.0, d1 , "Sharad"));
		s.add(new Book(1003, "Java Progamming", 523.0, d2, "Gilard Bracha"));
		s.add(new Book(1004, "Read C++", 295.0, d3 , "Henry Harvin"));
		s.add(new Book(1005, ".net Platform", 3497.0, d4 , "Mark J.Price"));
 
		System.out.println("Books soretd by author name in ascending");
		
		for (Book book : s) {
			System.out.println(book);
		}
		System.out.println("=======================================================================================================");
		
		TreeSet<Book> sortByDateDesc = new TreeSet<Book>(new Comparator<Book>() {
			public int compare(Book o1,Book o2) {
				return o2.getDop().compareTo(o1.getDop());
			}
		});
		
		System.out.println("Books sorted by date of publication in descending");
		sortByDateDesc.addAll(s);
		for(Book b:sortByDateDesc) {
			System.out.println(b);
		}
		
		System.out.println("=======================================================================================================");
		
		TreeSet<Book> sortByTitleAsc = new TreeSet<Book>(new Comparator<Book>() {
			public int compare(Book o1,Book o2) {
				return o1.getTitle().compareTo(o2.getTitle());
			}
		});
		
		System.out.println("Books sorted by Title  in ascending");
		sortByTitleAsc.addAll(s);
		for(Book b:sortByTitleAsc) {
			System.out.println(b);
		}
		
		System.out.println("=======================================================================================================");
		
		TreeSet<Book> sortByBookIdDescAndDopAsc = new TreeSet<Book>(new Comparator<Book>() {
			public int compare(Book o1,Book o2) {
				int result = Integer.compare(o2.getBookId(), o1.getBookId());
				if(result==0) {
					return o1.getDop().compareTo(o2.getDop());
				}
				return result;
			}
		});
		
		System.out.println("Books sorted by Book Id  in descending and Date of publication in ascending ");
		sortByBookIdDescAndDopAsc.addAll(s);
		for(Book b:sortByBookIdDescAndDopAsc) {
			System.out.println(b);
		}

	}

}
