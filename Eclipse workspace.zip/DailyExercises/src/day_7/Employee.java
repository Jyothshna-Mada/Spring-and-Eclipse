package day_7;

public class Employee {
	int employeeNo;
	String employeeName;
	String address;
	
	public Employee(int employeeNo, String employeeName, String address) {
		this.employeeNo = employeeNo;
		this.employeeName = employeeName;
		this.address = address;
	}

	@Override
	public String toString() {
		return "Employee [employeeNo=" + employeeNo + ", employeeName=" + employeeName + ", address=" + address + "]";
	}
	
	
	
	

}
