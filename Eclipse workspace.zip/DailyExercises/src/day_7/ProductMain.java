package day_7;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Scanner;
import java.util.Set;

public class ProductMain {
	
	public static void main(String[] args) {
		
		Set<Product> p = new HashSet<>();
		
		p.add( new Product("P001", "Maruti800"));
		p.add( new Product("P002", "MarutiZen"));
		p.add( new Product("P003", "MarutiDezire"));
		p.add( new Product("P004", "MarutiAlto"));
		
		Scanner scn = new Scanner(System.in);
		System.out.println("1.Search Product"+"\n"+"2.Remove product ");
		System.out.println("Enter your choice");
		int option = scn.nextInt();
		
		switch(option) {
		case 1:
			System.out.println("Enter a product to search: ");
			String product1 = scn.next();
			for(Product p1:p) {
				if(p1.getProductName().equals(product1)) {
					System.out.println("The product "+product1+" is available");
				}
			}
			break;
		case 2:
			System.out.println("Enter product id to remove");
			String id = scn.next();
			Iterator<Product> product=p.iterator();
			while(product.hasNext()) {
				Product pro =product.next();
				if(id.equals(pro.getProductId())) {
					product.remove();
				}
			}
			System.out.println("The Product with id: "+id+" is removed");
			break;
		}
		
	}

}
