package day_7;

import java.time.LocalDate;
import java.util.Objects;

public class Book implements Comparable<Book>{
	private Integer bookId;
	private String title;
	private double price;
	private LocalDate dop;
	private String authour;
	
	public Book(int bookId, String title, double price, LocalDate dop, String authour) {
		
		this.bookId = bookId;
		this.title = title;
		this.price = price;
		this.dop = dop;
		this.authour = authour;
	}
	
	public int getBookId() {
		return bookId;
	}
	public String getTitle() {
		return title;
	}
	public double getPrice() {
		return price;
	}
	public LocalDate getDop() {
		return dop;
	}
	public String getAuthour() {
		return authour;
	}
 
	public String toString() {
		return "Book [bookId=" + bookId + ", title=" + title + ", price=" + price + ", dop=" + dop + ", authour="
				+ authour + "]";
	}
 
	public int hashCode() {
		return Objects.hash(bookId,title,price,dop,authour);
	}
 
	@Override
	public int compareTo(Book other) {
		return this.authour.compareTo(other.authour);
	}

}
