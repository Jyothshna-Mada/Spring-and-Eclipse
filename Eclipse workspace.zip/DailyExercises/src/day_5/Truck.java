package day_5;

public class Truck implements Vehicle{

	@Override
	public void start() {
		System.out.println("Truck is started");
		
	}

	@Override
	public void accelerate() {
		System.out.println("Truck Accelerated");
		
	}

	@Override
	public void brake() {
		System.out.println("Truck is stopped using brake");
		
	}

}
