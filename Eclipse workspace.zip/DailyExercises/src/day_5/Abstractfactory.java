package day_5;

public abstract class Abstractfactory {
	
	abstract Shape getShape(String shapeType);

}
