package day_5;

public class MotorCycle implements Vehicle{

	@Override
	public void start() {
		System.out.println("Motor Cycle is started");
		
	}

	@Override
	public void accelerate() {
		System.out.println("Motor Cycle Accelerated");
		
	}

	@Override
	public void brake() {
		System.out.println("Motor Cycle is stopped using brake");
		
	}

}
