package day_5;

public class Customer {

	public static void main(String[] args) {
		BillingService b1 = BillingService.getInstance();
		
		b1.processPayment("Ac123",200.0);
		b1.generateInvoice("Ac123",656.99);
	}

}
