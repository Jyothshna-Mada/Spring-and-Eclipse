package day_5;

public class VehicleFactory {
	
	public Vehicle createVehicle(String type) {
		if(type==null) {
		return null;
		}
		if(type.equalsIgnoreCase("Car")) {
			return new Car();
		}else if(type.equalsIgnoreCase("MotorCycle")) {
			return new MotorCycle();
		}else if(type.equalsIgnoreCase("truck")) {
			return new Truck();
		}
		return null;
		
	}

}
