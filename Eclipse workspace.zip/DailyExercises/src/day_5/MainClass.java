package day_5;

public class MainClass {

	public static void main(String[] args) {
		
		EmployeeClass e1 = new EmployeeClass("Vijay", "Kumar", "12-07-1997", 636261,
				"24-03-2019", 30000);
		
		EmployeeClass e2 = new EmployeeClass("Aravid", "Swamy", "9-11-1993", 636278,
				"15-05-2015", 70000);
		
		
		System.out.println(e1.toString());
		System.out.println("*************************");
		
		System.out.println(e2.toString());
		EmployeeClass e3 = new EmployeeClass("Venkat", "Kumar", "12-07-1997", 636261,"24-03-2019" , 30000);
		
		System.out.println("**************************");
		
		System.out.println(e3.toString());
	}

}
