package day_10;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class CombineNotes {

	public static void main(String[] args) throws IOException {
		String [] files= {"c://mp//Student//DavidEnglish.txt",
							"c://mp//Student//DavidScience.txt",
								"c://mp//Student//DavidComputer.txt"};
		
		try(BufferedWriter w = new BufferedWriter(new FileWriter("c://mp//Student//DavidNotes.txt"))){
			for (String file : files) {
				try(BufferedReader r = new BufferedReader(new FileReader(file))) {
					String Line;
					while((Line=r.readLine())!=null) {
						w.write(Line);
						w.newLine();
					}
				}catch (FileNotFoundException e) {
					System.err.println("File not found "+file);
					e.printStackTrace();
				}
				catch (IOException e) {
					System.out.println("Can't read files "+file);
				}
			}
		}catch (IOException e) {
			System.out.println("Can not write into files ");
		}
		System.out.println("combined");

	}

}
