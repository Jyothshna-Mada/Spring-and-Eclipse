package day_10;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.Scanner;

public class StudentSerialize {

	public static void main(String[] args) throws FileNotFoundException {
		Scanner scn = new Scanner(System.in);
		
		try {
			System.out.println("Enter roll Number");
			int num=scn.nextInt();
			
			
			System.out.println("Enter Name: ");
			String name = scn.next();
		
			if(name.isBlank())
				throw new IllegalArgumentException("Name can not be blank");
			
			System.out.println("Enter Age: ");
			int age = scn.nextInt();
			
			System.out.println("Enter Address: ");
			String address = scn.next();
			
			if(address.isEmpty())
				throw new IllegalArgumentException("Address can not be blank");
			
			Student s1 = new Student(num, name, age, address);
			System.out.println("Do you want to save the data");
			String consent = scn.next().toLowerCase();
			
			if(consent.equals("yes")) {
				saveStudent(s1);
				System.out.println("Data saved successfully");
			}else 
				System.out.println("Data not saved");
			
			
		}catch (NumberFormatException e) {
			System.out.println("Roll number and Age should be Numeric");
		}catch (IllegalArgumentException e) {
			System.err.println(e.getMessage());
		}catch (IOException e) {
			System.out.println("Some error occured can not save data");
		}finally {
			scn.close();
		}

	}
	public static void saveStudent(Student s) throws IOException {
FileOutputStream fos =new FileOutputStream("c://user//student//details.txt",true);
		
		try(ObjectOutputStream of = new ObjectOutputStream(fos)){
			of.writeObject(s);	
		}
	}

}
