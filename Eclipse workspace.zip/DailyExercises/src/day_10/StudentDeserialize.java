package day_10;

import java.io.FileInputStream;
import java.io.ObjectInputStream;

public class StudentDeserialize {

	public static void main(String[] args) {
		String path="c://user//student//details.txt";
		try {
			FileInputStream fis = new FileInputStream(path);
			ObjectInputStream in = new ObjectInputStream(fis);
			Student s = (Student)in.readObject();
			System.out.println(s.toString());
		}catch(Exception e) {
			System.out.println("Can not extract student data");
		}

	}

}

