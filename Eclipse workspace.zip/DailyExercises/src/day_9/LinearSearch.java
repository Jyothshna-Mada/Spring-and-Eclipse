package day_9;

public class LinearSearch {

	public static void main(String[] args) {
		int a[] = new int[5];
		a[0]=2;
		a[1]=3;
		a[2]=4;
		a[3]=10;
		a[4]=40;
		
		int result=search(a,90);
		
		if(result!=-1) 
			System.out.println("Element is Present");
		else 
			System.out.println("Element is not present");
		

	}
	
	public static int search(int []a,int key) {
		for(int i=0;i<a.length;i++) {
			if(a[i]==key) 
				return i;
		}
		return -1;
	}

}
