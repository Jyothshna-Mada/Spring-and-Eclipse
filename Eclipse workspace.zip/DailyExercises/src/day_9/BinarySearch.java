package day_9;

public class BinarySearch {

	public static void main(String[] args) {
		String [] fruits= {"apple","banana","grape","orange","pear","strawberry"};
		String key="strawberry";
		
	int result=	binarySearch(fruits, key, 0, fruits.length-1);
		if(result!=-1) 
			System.out.println("Element "+key+" found at index "+result);
		else
			System.out.println("Element "+key+" not Found");
	}
	
	public static int binarySearch(String[]a,String key,int start,int end) {
		if(start>end) return -1;
		int mid = (start+end)/2;
		int result = key.compareTo(a[mid]);
		
		if(result==0) 
			return mid;
		else if(result>0)
			return binarySearch(a,key,mid+1,end);
		else 
			return binarySearch(a, key, start, mid-1);
		
		
	}

}
