package day_9;

public class SelectionSort {

	public static void main(String[] args) {
		String [] fruits = {"banana","apple","orange","grape","kiwi"};
	
		sort(fruits);
		printArray(fruits);
		
		
	}
	public static void printArray(String [] a) {
		for(String s:a) {
			System.out.print(s+" ");
		}
		System.out.println();
	}
	
	public static void sort(String [] fruit) {
		
		for(int i=0;i<fruit.length-1;i++) {
			int index=i;
			for(int j=i+1;j<fruit.length;j++) {
				if(fruit[j].compareTo(fruit[index])<0) {
					index=j;
				}	
			}
			
				String temp=fruit[index];
				fruit[index]=fruit[i];
				fruit[i]=temp;
		}
	}

}
