package friends;

public class RegistrationBO {
	
	public void registerUser(User user) throws BusinessException {
		
		if(user.getFirstName().isEmpty()||user.getLastName().isEmpty()) {
			throw new BusinessException("FirstName and LastName cannot be empty");
		}
		RegisterDao dao=new RegisterDao();
		dao.insertUser(user);
	}
}
