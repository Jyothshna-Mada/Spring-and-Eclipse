package friends;

import java.io.IOException;
//import javax.servlet.ServletException;
//import javax.servlet.annotation.WebServlet;
//import javax.servlet.http.HttpServlet;
//import javax.servlet.http.HttpServletRequest;
//import javax.servlet.http.HttpServletResponse;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/RegistrationOfFriends")
public class RegistrationServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String firstname=request.getParameter("FirstName");
		String lastname=request.getParameter("LastName");
		String country=request.getParameter("Country");
		String[] languages =request.getParameterValues("language");
		String gender=request.getParameter("gender");
		if(firstname==null||lastname==null||country==null||languages==null||gender==null) {
			response.sendRedirect("error.jsp");
		}else {
			User user=new User();
			user.setFirstName(firstname);
			user.setLastName(lastname);
			user.setCountry(country);
			user.setLanguage(languages);
			user.setGender(gender);
			RegistrationBO bo=new RegistrationBO();
			try {
				bo.registerUser(user);
				response.sendRedirect("success.jsp");
			}catch (BusinessException e) {
			request.setAttribute("errorMessage", e.getMessage());
			request.getRequestDispatcher("error.jsp").forward(request, response);
			}
		}
	}

}
