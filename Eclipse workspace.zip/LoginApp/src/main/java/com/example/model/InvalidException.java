package com.example.model;

public class InvalidException extends Exception{
	public InvalidException() {
		super();
	}
	public InvalidException(String message) {
		super(message);
	}
}
