package com.example.model;

public class LoginBo {
	public boolean isValidUser(User user) throws InvalidUserException,InvalidException {
		Logindao dao = new Logindao();	
		 if (user.getUsername().length() < 4|| user.getUsername().length() >15) 
	            throw new InvalidException("UserName should be 4-15 character length");
	         else 
	        	return dao.LoginValidate(user); 	
	}
}
