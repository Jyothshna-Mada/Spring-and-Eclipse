package com.example.model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


public class Logindao {

	public boolean LoginValidate(User user) throws InvalidException {
		String url="jdbc:mysql://locolhost:3306/logindb";
		String username="root";
		String password="Admin@123";
		boolean status=false;
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection(url,username,password);
			String query="Select * from user where username=? and password=?";
			PreparedStatement ps = con.prepareStatement(query);
			ps.setString(1, user.getUsername());
			ps.setString(2, user.getPassword());
			
			ResultSet rs= ps.executeQuery();
			status = rs.next();
		}catch (SQLException |ClassNotFoundException e) {
			throw new InvalidException("Error in SQL");
		}
		return status;
	}
}
