package com.example.model;

import java.io.IOException;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

//import javax.servlet.RequestDispatcher;
//import javax.servlet.ServletException;
//import javax.servlet.annotation.WebServlet;
//import javax.servlet.http.HttpServlet;
//import javax.servlet.http.HttpServletRequest;
//import javax.servlet.http.HttpServletResponse;

@WebServlet("/login")
public class Login extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			User user = new User();
			String username=request.getParameter("username");
			String password=request.getParameter("password");
			user.setUsername(username);
			user.setPassword(password);
			
			try {
				if(username==null||username.trim().isEmpty()) {
					throw new InvalidUserException("UserName should not be null");
				}
				
				if(password==null||password.length()<4 && password.length()>8) {
					throw new InvalidUserException("Password should be 4-8 character length");
				}
			} catch (Exception e) {
				throw new InvalidUserException(e.getMessage());
			}

			LoginBo loginBO= new LoginBo();
			
			if(loginBO.isValidUser(user))
			{
				RequestDispatcher dispatcher = request.getRequestDispatcher("welcome.jsp");
				dispatcher.forward(request, response);
			}
			
		}catch (InvalidException e) {
			
				request.setAttribute("message", e.getMessage());
			
			RequestDispatcher dispatcher = request.getRequestDispatcher("login.jsp");
			dispatcher.forward(request, response);
		}catch (InvalidUserException e) {
			e.printStackTrace();
			request.setAttribute("errMessage", "Invalid");
			RequestDispatcher dispatcher = request.getRequestDispatcher("error.jsp");
			dispatcher.forward(request, response);
		}
		
		
	}

}
