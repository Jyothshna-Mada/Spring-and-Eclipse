package com.example.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.example.dbutil.DBUtil;
import com.example.domain.Product;

public class ProductManagementDAO {
	
	
	public  void addProduct(Product product) {

		try {
			Connection con =DBUtil.getConnection();
			PreparedStatement ps = con.prepareStatement("Insert into product values(?,?,?)");
			ps.setInt(1, product.getProduct_id());
			ps.setString(2, product.getProduct_name());
			ps.setString(3, product.getProduct_price());
			ps.executeUpdate();
		}catch (SQLException |IOException e) {
			e.printStackTrace();
			return;
		}
		System.out.println("Product added Successfully");
	}
	
	public  List<Product> viewProduct() {
		List<Product> product=new ArrayList<>();
		try {
			Connection con =DBUtil.getConnection();
			PreparedStatement ps = con.prepareStatement("select * from product");
			ResultSet rs= ps.executeQuery();
		
			while(rs.next()) {
			product.add(new Product(	rs.getInt(1),
				rs.getString(2),
				rs.getString(3)));
		}
		}catch (SQLException | IOException e) {
			e.printStackTrace();
		}
		return product;
		
	}
	
	public  void updateProduct(Product product) {
		
		try {
			Connection con =DBUtil.getConnection();
			PreparedStatement ps = con.prepareStatement("update product set product_name=? , product_price=? where product_id=?");
			ps.setString(1, product.getProduct_name());
			ps.setString(2, product.getProduct_price());
			ps.setInt(3, product.getProduct_id());
			
			ps.executeUpdate();
		}catch (SQLException |IOException e) {
			System.out.println("Error in sql Syntax");
			return;
		}
		System.out.println("Product updated Successfully");
	}
	
	public  void deleteProduct(int id) {
		
		try {
			Connection con =DBUtil.getConnection();
			PreparedStatement ps = con.prepareStatement("delete from product where product_id=?");
			
			ps.setInt(1, id);
			
			ps.executeUpdate();
		}catch (SQLException |IOException e) {
			e.printStackTrace();
			return;
		}
		System.out.println("Product deleted Successfully");
	}
	
	public  Product searchProduct(int id) {
		
		try {
			Connection con =DBUtil.getConnection();
			PreparedStatement ps = con.prepareStatement("select * from product where product_id=?");
			
			ps.setInt(1, id);
			ResultSet rs=ps.executeQuery();
			
			if(rs.next()) {
			return new Product(	rs.getInt(1),
				rs.getString(2),
				rs.getString(3));
			}
			
		}catch (SQLException |IOException e) {
			e.printStackTrace();
		}
		return null;
		
	}

}
