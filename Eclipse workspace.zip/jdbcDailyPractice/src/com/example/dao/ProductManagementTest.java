package com.example.dao;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.example.dbutil.DBUtil;
import com.example.domain.Product;

public class ProductManagementTest {
	private static Connection con;
	private static ProductManagementDAO productDao;
	private Product testProduct;
	
	@BeforeClass
	public static void init() {
		try {
			 con =DBUtil.getConnection();
		} catch (SQLException |IOException e) {
			System.out.println("Exception Occured");
		}
	}
	
	@Before
	public void beforeEachTest() {
		 productDao = new ProductManagementDAO();
		 testProduct=new Product(1001, "test", "99.99");
	}
	
	@Test
	public void addProductsTest() {
		productDao.addProduct(testProduct);
		Product p=productDao.searchProduct(testProduct.getProduct_id());
		assertNotNull(p);
	}
	@Test
	public void getAllProductsTest() {
		Product anotherProduct =new Product(1003, "Another", "20.78");
		
		productDao.addProduct(anotherProduct);
		List<Product> pro = productDao.viewProduct();
		assertTrue(pro.size()>=2);
		productDao.deleteProduct(anotherProduct.getProduct_id());
	}
	
	@Test
	public void deleteProductTest() {
		productDao.addProduct(testProduct);
		productDao.deleteProduct(testProduct.getProduct_id());
		Product deletepro=productDao.searchProduct(testProduct.getProduct_id());
		assertNull(deletepro);
	}
	
	@Test
	public void updateProductTest() throws SQLException{
		productDao.addProduct(testProduct);
		testProduct.setProduct_name("Update Product");
		testProduct.setProduct_price("23.457");
		productDao.updateProduct(testProduct);
		Product p=productDao.searchProduct(testProduct.getProduct_id());
		assertEquals("Update Product", p.getProduct_name());
		assertEquals("23.457", p.getProduct_price());
	}
	
	@AfterClass
	public static void destroy() {
		try {
			con.close();
		} catch (SQLException e) {
			System.out.println("Exception Occured while closing connections");
		}
	}

}
