package com.example.inheritence.single;

import org.hibernate.Session;
import org.hibernate.Transaction;

public class Main {
	public static void main(String[] args) {
		
		  Session session = HibernateUtil.getSessionFactory().openSession();
	        Transaction transaction = null;
	        
	        try {
	            transaction = session.beginTransaction();
	            FullTimeEmployee fullTimeEmployee = new FullTimeEmployee(1L, "Krishna", 50000.00);
	            session.save(fullTimeEmployee);
	            
	            PartTimeEmployee partTimeEmployee = new PartTimeEmployee(2L, "Radha", 20.00);
	            session.save(partTimeEmployee);
	            
	            transaction.commit();
	        } catch (Exception e) {
	            if (transaction != null) {
	                transaction.rollback();
	            }
	            e.printStackTrace();
	        } finally {
	            session.close();
	        }
	}
}
