package com.example.inheritence.single;

import org.hibernate.Session;

public class Fetch {
	
	public static void main(String[] args) {
		Session session = HibernateUtil.getSessionFactory().openSession();
		
		try {
			FullTimeEmployee employee=session.get(FullTimeEmployee.class, 1L);
			if(employee!=null) {
				System.out.println("FullTimeEmployee: "+employee.getName()+" , Salary: "+employee.getSalary());
			}
			PartTimeEmployee ptEmployee=session.get(PartTimeEmployee.class, 2L);
			if(ptEmployee!=null) {
				System.out.println("PartTimeEmployee: "+ptEmployee.getName()+" ,Hourly Rate: "+ptEmployee.getHourlyRate());
			}
		}finally {
			session.close();
		}
	}

}
