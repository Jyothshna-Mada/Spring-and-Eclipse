package com.example.inheritence.joined;

import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name="Part_TimeEmployee")
public class PartTimeEmployee1 extends Employee3{

	private double hourlyRate;

	public PartTimeEmployee1(long id, String name, double hourlyRate) {
		super(id,name);
		this.hourlyRate = hourlyRate;
	}

	public PartTimeEmployee1() {
		super();
	}

	public double getHourlyRate() {
		return hourlyRate;
	}

	public void setHourlyRate(double hourlyRate) {
		this.hourlyRate = hourlyRate;
	}
}
