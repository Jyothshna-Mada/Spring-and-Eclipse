package com.example.inheritence.table_per_class;

import org.hibernate.Session;
import org.hibernate.Transaction;

public class Main {
	public static void main(String[] args) {
		Session session= HibernateUtil.getSessionFactory().openSession();
		Transaction transaction=null;
		try {
			transaction=session.beginTransaction();
			
			FullTimeEmployee emp=new FullTimeEmployee(1L, "Vijay", 50000.00);
			session.save(emp);
			
			PartTimeEmployee employ=new PartTimeEmployee(2L,"Ajay",20.00);
			session.save(employ);
			
			transaction.commit();
		}catch (Exception e) {
			if(transaction!=null) {
				transaction.rollback();
			}
			e.printStackTrace();
		}finally {
			session.close();
		}
	}
}
