package com.example.orm.manytomany;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class Granularity {

	public static void main(String[] args) {
		Configuration cfg=new Configuration().configure("hibernate.cfg.xml");
		SessionFactory factory =cfg.buildSessionFactory();
		Session session = factory.openSession();
		
		Transaction transaction = null;
		
		try {
			transaction=session.beginTransaction();
			
			User user = new User();
			user.setId(5);
			user.setUsername("Vimala");
			user.setEmail("vimala@gmail.com");
			session.save(user);
			
			 OrderItemId orderItemId = new OrderItemId();
	            orderItemId.setOrderId(104);
	            orderItemId.setProductId(205);
	            
	            Order orderItem = new Order();
	            orderItem.setId(orderItemId);
	            orderItem.setQuantity(5);
	            
	            session.save(orderItem);
	            
	            transaction.commit();
	            
	            System.out.println("Entities saved Successfully");
	            
		}catch(Exception e) {
			if(transaction!=null) {
				transaction.rollback();
			}
			e.printStackTrace();
		}finally {
			session.close();
			factory.close();
		}
	}

}
