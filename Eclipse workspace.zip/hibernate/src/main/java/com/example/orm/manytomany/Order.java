package com.example.orm.manytomany;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;

@Entity
public class Order {
	@EmbeddedId
	private OrderItemId id;
	
	private Integer quantity;

	public OrderItemId getId() {
		return id;
	}

	public void setId(OrderItemId id) {
		this.id = id;
	}

	public Integer getQuantity() {
		return quantity;
	}

	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}
	
	
}
