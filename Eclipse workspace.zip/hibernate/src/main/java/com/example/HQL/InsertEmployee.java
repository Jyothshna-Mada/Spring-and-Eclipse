package com.example.HQL;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class InsertEmployee {
	public static void main(String[] args) {
		SessionFactory factory=new Configuration().configure().addAnnotatedClass(Employeehql.class).buildSessionFactory();
		Session session = factory.openSession();
		
		Transaction transaction=session.beginTransaction();
		
		Employeehql emp1=new Employeehql();
		emp1.setName("Ram");
		emp1.setSalary(29000);
		
		Employeehql emp2=new Employeehql();
		emp2.setName("Radha");
		emp2.setSalary(55000);
		
		Employeehql emp3=new Employeehql();
		emp3.setName("Anikha");
		emp3.setSalary(45000);
		
		session.save(emp1);
		session.save(emp2);
		session.save(emp3);
		
		transaction.commit();
		
		session.close();
		factory.close();
	}

}
