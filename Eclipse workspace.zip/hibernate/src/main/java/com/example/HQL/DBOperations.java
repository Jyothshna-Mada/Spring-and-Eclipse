package com.example.HQL;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Projections;
import org.hibernate.Criteria;
import org.hibernate.query.Query;

public class DBOperations {

	public static void main(String[] args) {
		  DBOperations db=new DBOperations();
	       // db.insertItems();
	       //db.updateItem();
	        //db.deleteItem();
	        //db.fetchItems();
	      // db.fetchItemByCriteria();
	       db.fetchItemByNamedQuery();
	}
	
	public void insertItems() {
		Configuration cfg=new Configuration().configure("hibernate.cfg.xml");
		SessionFactory sf=cfg.buildSessionFactory();
		Session session =sf.openSession();
		Transaction transaction =session.beginTransaction();
		
		Item i1 = new Item();
		i1.setItemName("Car");
		i1.setPrice(120000.0);
		session.save(i1);
		transaction.commit();
		session.close();
	}
	
	public void fetchItems() {
		Configuration cfg=new Configuration().configure("hibernate.cfg.xml");
		SessionFactory sf=cfg.buildSessionFactory();
		Session session =sf.openSession();
		
		
		Query<Item> q=session.createNamedQuery("fetchitems");
        List<Item> items=q.list();
        System.out.println("----"+items.toString()+"\n");
        session.close();
	}
	
	public void updateItem() {
		Configuration cfg=new Configuration().configure("hibernate.cfg.xml");
		SessionFactory sf=cfg.buildSessionFactory();
		Session session =sf.openSession();
		Transaction transaction =session.beginTransaction();
		
		 Query<Item> q=session.createQuery("update Item set itemName=:name where id=:id");
	        q.setParameter("name", "Cycle");
	        q.setParameter("id", 1);
	        q.executeUpdate();
	        transaction.commit();
	        session.clear();
	}
	public void deleteItem() {
		Configuration cfg=new Configuration().configure("hibernate.cfg.xml");
		SessionFactory sf=cfg.buildSessionFactory();
		Session session =sf.openSession();
		Transaction transaction =session.beginTransaction();
		
		 Query<Item> q=session.createQuery("delete from Item  where id=:id");        
	        q.setParameter("id", 3);
	       q.executeUpdate();
	        transaction.commit();
	        session.clear();
	}
	
	public void fetchItemByCriteria() {
		Configuration cfg=new Configuration().configure("hibernate.cfg.xml");
		SessionFactory sf=cfg.buildSessionFactory();
		Session session =sf.openSession();
		
		
		Criteria c=session.createCriteria(Item.class);
	     
	        c.setProjection(Projections.property("itemName"));
	        List<Item> items=c.list();
	        System.out.println("----"+items.toString());
	        session.close();
	}
	
	public void fetchItemByNamedQuery() {
		Configuration cfg=new Configuration().configure("hibernate.cfg.xml");
		SessionFactory sf=cfg.buildSessionFactory();
		Session session =sf.openSession();
		
		
		Query<Item> q=session.getNamedQuery("fetchitemsbyid");
        q.setParameter("id", 2);
        List<Item> items=q.list();
        System.out.println("----"+items.toString());
        session.close();
	}
}
