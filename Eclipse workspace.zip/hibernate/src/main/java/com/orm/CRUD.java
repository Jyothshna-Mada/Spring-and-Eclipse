package com.orm;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;


public class CRUD {

	public static void main(String[] args) {

		Configuration cfg = new Configuration().configure("hibernate.cfg.xml");
		SessionFactory factory = cfg.buildSessionFactory();
		Session session = factory.openSession();

		// insert

		Transaction insert = session.beginTransaction();

		
		  Employee e1 = new Employee(); 
		  e1.setId(140);
			  e1.setFirstname("Hachi");
			  e1.setLastname("G");
			  
			 session.save(e1); 
			  insert.commit(); 
			  System.out.println("Record Inserted");
			 
		 
		
		  //Employees e2 = session.get(Employees.class, 131);
		  //System.out.println("Retreived " + e2);
		  
			
			
//			  Transaction update = session.beginTransaction(); 
//			  Employee  e3=session.get(Employee.class, 0); e3.setFirstname("Rani");
//			  session.update(e3); 
//			  update.commit(); 
//			  System.out.println("Updated");
//			 
		 

		
			
			
//			  Transaction delete = session.beginTransaction(); 
//			  Employee e2 = session.get(Employee.class, 0); 
//			  session.delete(e2); 
//			  delete.commit();
//			  System.out.println("Deleted");
			 
			 
			  List<Employee> employee = session.createQuery("from Employee", Employee.class).list();
			  System.out.println("All Employees:");
	            for (Employee emp : employee) {
	                System.out.println(emp);
	            }
	            
//	   		 session.beginTransaction();
//	   		 Employee product=session.get(Employee.class, e1.getId());
//		System.out.println(product);
		
		session.close();
		factory.close();

	}

}