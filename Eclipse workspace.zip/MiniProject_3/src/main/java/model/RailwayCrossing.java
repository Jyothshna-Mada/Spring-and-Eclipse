package model;

public class RailwayCrossing {
	private String Name;
	private String Address;
	private String Landmark;
	private String TrainSchedules;
	private String Incharge;
	private String Status;
	
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public String getAddress() {
		return Address;
	}
	public void setAddress(String address) {
		Address = address;
	}
	public String getLandmark() {
		return Landmark;
	}
	public void setLandmark(String landmark) {
		Landmark = landmark;
	}
	public String getTrainSchedules() {
		return TrainSchedules;
	}
	public void setTrainSchedules(String trainSchedules) {
		TrainSchedules = trainSchedules;
	}
	public String getIncharge() {
		return Incharge;
	}
	public void setIncharge(String incharge) {
		Incharge = incharge;
	}
	public String getStatus() {
		return Status;
	}
	public void setStatus(String status) {
		Status = status;
	}
	

}
