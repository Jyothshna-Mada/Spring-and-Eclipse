package abstractFactoryPattern;

public interface Shapefactory {
	Circle createCircle();
	Square createSquare();
	

}
