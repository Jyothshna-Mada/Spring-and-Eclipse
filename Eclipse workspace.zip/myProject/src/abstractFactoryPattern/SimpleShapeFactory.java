package abstractFactoryPattern;

public class SimpleShapeFactory implements Shapefactory{

	@Override
	public Circle createCircle() {
		return new SimpleCircle();
	}

	@Override
	public Square createSquare() {
		return new SimpleSquare();
	}

}
