package abstractFactoryPattern;

public interface Square {
	void draw();
}
