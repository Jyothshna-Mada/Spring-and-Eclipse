package date_time;

import java.time.Duration;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
public class DateEx {

	public static void main(String[] args) {
		LocalDate today = LocalDate.now();
		System.out.println("TOday's Date: "+today);
		
		LocalDate birthDate = LocalDate.of(2001, 5, 14);
		System.out.println("My Birth Date: "+birthDate);
		
		LocalTime time = LocalTime.now();
		System.out.println("Time: "+time);
		
		LocalTime custTime = LocalTime.of(13, 0, 0);
		System.out.println(custTime);
		
		LocalDateTime dateTime=LocalDateTime.now();
		System.out.println(dateTime);
		
		LocalDateTime preDateTime = LocalDateTime.of(birthDate, custTime);
		System.out.println(preDateTime);
		
		LocalDateTime addDay = dateTime.plusDays(5);
		System.out.println(addDay);
		
		ZonedDateTime zoneddateTime = ZonedDateTime.now();
		ZonedDateTime ParisTime = ZonedDateTime.now(ZoneId.of("Europe/London"));
		
		System.out.println("CUrrent zone: "+zoneddateTime);
		System.out.println("Paris zone: "+ParisTime);
		
		Instant i = Instant.now();
		System.out.println(i);
		
		Duration duration = Duration.ofHours(5);
		System.out.println("duration: "+duration);
		
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		LocalDate parsedDate=LocalDate.parse("23/07/2024", formatter);
		
		String formattedDate=today.format(formatter);
		
		System.out.println("parsed date: "+parsedDate);
		
		System.out.println("Formatted Date: "+formattedDate);

	}

}
