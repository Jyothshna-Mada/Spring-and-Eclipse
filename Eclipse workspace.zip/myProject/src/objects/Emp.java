package objects;

import java.util.Objects;

public class Emp {
	
	private int age;
	
	public Emp(int age) {
		this.age=age;
	}

	@Override
	public int hashCode() {
		return Objects.hash(age);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Emp other = (Emp) obj;
		return age == other.age;
	}



	public static void main(String[] args) {
		
		Emp e1 = new Emp(23);
		Emp e2 = new Emp(23);
		Emp e3 = new Emp(24);
		
		System.out.println("e1.hashcode() ----->>> "+ e1.hashCode());
		System.out.println("e2.hashcode() ----->>> "+ e2.hashCode());
		System.out.println("e3.hashcode() ----->>> "+ e3.hashCode());
		
		System.out.println("e1.equals() ----->>> "+e1.equals(e2));
		System.out.println("e1.equals() ----->>> "+e2.equals(e3));
		System.out.println("e1.hashcode() ----e2.hashcode() "+(e1.hashCode()== e2.hashCode()));
	}

}
