package objects;

public class Main {

	public static void main(String[] args) {
		ColoredBox<Integer> b = new ColoredBox<>();
		b.setItem(42);
		b.setColor("Blue");
		System.out.println("Item in box: "+b.getItem());
		System.out.println("Color of item: "+b.getColor());
		
		ColoredBox<String> str = new ColoredBox<>();
		str.setItem("Generic");
		str.setColor("Green");
		
		System.out.println("Item in str: "+str.getItem());
		System.out.println("Color of an item: "+str.getColor());

	}

}
