package designPattern;

public class FactoryPDemo {

	public static void main(String[] args) {
		ShapeFactory s1 = new ShapeFactory();
		
		Shape shape1=s1.getShape("CIRCLE");
		shape1.draw();
		
		Shape shape2=s1.getShape("Square");
		shape2.draw();
		
		Shape shape3=s1.getShape("RECtangle");
		shape3.draw();

	}

}
