package designPattern;

public interface Shape {
	void draw();

}
