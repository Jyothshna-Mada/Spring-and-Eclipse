package jdbc;

import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;


public class DbUtil {

	private static Properties loadProperties() throws IOException {
		Properties prop = new Properties();
		try(FileInputStream input = new FileInputStream("dbConfig.properties")){
			prop.load(input);
		}
		return prop;
	}
	
	public static Connection getConnection() throws IOException, SQLException {
		Properties prop = loadProperties();
		String driverClass= prop.getProperty("jdbc.driverClassName");
		String url =prop.getProperty("jdbc.url");
		String username=prop.getProperty("jdbc.username");
		String password = prop.getProperty("jdbc.password");
		try {
			Class.forName(driverClass);
		} catch (ClassNotFoundException e) {
			throw new SQLException("JDBC driver not found",e);
		}
		return DriverManager.getConnection(url,username,password);
	}
}
