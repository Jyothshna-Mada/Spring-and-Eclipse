package jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class PreparedStatementEx {
	private static Connection con = null;

	public static void main(String[] args) {
	Scanner scn = new Scanner(System.in);
	int choice;
	try {
		Class.forName("com.mysql.cj.jdbc.Driver");
		con = DriverManager.getConnection("jdbc:mysql://localhost:3306/jdbc","root","Admin@123");
		DriverManager.getConnection("jdbc:mysql://localhost:3306/jdbc","root","Admin@123");
		do {
			System.out.println("Select an operation:");
			System.out.println("1. Insert employee");
			System.out.println("2. Update employee");
			System.out.println("3. Delete employee");
			System.out.println("4. view employee");
			System.out.println("5. Exit");
			choice = scn.nextInt();
			scn.nextLine();
			switch (choice) {
			case 1: {
				insertEmployee(scn);
				break;
			}
			case 2:{
				updateEmployee(scn);
				break;
			}
			case 3:{
				deleteEmployee(scn);
				break;
			}
			case 4:{
				viewEmployee();
				break;
			}
			case 5:{
				System.out.println("Exiting...");
				break;
			}
			default:
				System.out.println("Invalid Choice");
			}
		} while (choice!=5);
	} catch (ClassNotFoundException |SQLException e) {
		e.printStackTrace();
	}finally {
		try {
			if(con!=null)
				con.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
			scn.close();
	}
	
	public static void insertEmployee(Scanner scn) throws SQLException {
		String query="insert into employee values(?,?,?)";
		PreparedStatement ps = con.prepareStatement(query);
		System.out.println("Enter employee ID:");
		int id = scn.nextInt();
		scn.nextLine();
		System.out.println("Enter first name");
		String fname=scn.nextLine();
		System.out.println("Enter last name");
		String lname=scn.nextLine();
		
		ps.setInt(1, id);
		ps.setString(2, fname);
		ps.setString(3, lname);
		
		int result = ps.executeUpdate();
		System.out.println(result + "Record inserted");
	}
	
	public static void updateEmployee(Scanner scn) throws SQLException  {
		String query = "update employee set fname=? where id =?";
		PreparedStatement ps = con.prepareStatement(query);
		System.out.println("Enter id to update");
		int id = scn.nextInt();
		scn.nextLine();
		System.out.println("Enter new first name:");
		String fname=scn.nextLine();
		
		ps.setString(1, fname);
		ps.setInt(2, id);
		int result = ps.executeUpdate();
		System.out.println(result+" Record updated");
		
	}
	
	public static void deleteEmployee(Scanner scn) throws SQLException {
		String query="delete from employee where id=?";
		PreparedStatement ps = con.prepareStatement(query);
		System.out.println("Enter id to delete");
		int id = scn.nextInt();
		
		ps.setInt(1, id);
		int result = ps.executeUpdate();
		System.out.println(result+" record deleted");
	}
	
	public static void viewEmployee() throws SQLException {
		String query="select * from employee";
		PreparedStatement ps = con.prepareStatement(query);
		ResultSet rs= ps.executeQuery();
		
		while(rs.next()) {
			System.out.println("Employee id: "+rs.getInt(1));
			System.out.println("Employee fname: "+rs.getString(2));
			System.out.println("Employee lname: "+rs.getString(3));
			System.out.println("======================================");
		}
	}

}
