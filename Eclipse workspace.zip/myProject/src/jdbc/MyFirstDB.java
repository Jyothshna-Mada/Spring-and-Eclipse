package jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;



public class MyFirstDB {

	public static void main(String[] args) {
		Connection con =null;
		Statement st =null;
		ResultSet rs=null;
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/jdbc","root","Admin@123");
			st=con.createStatement();
			rs=st.executeQuery("select* from employee");
			while(rs.next()) {
				System.out.println("id: "+rs.getInt("id"));
				System.out.println("fname: "+rs.getString(2));
				System.out.println("lname: "+rs.getString(3));
				
				System.out.println("======================================");
			}
		} catch (Exception e) {
			System.out.println("Execption occured");
		} finally {
			try {
				rs.close();
				st.close();
				con.close();
			}catch (SQLException e) {
				System.out.println("Exception occured in sql query");
			}
		}

	}

}
