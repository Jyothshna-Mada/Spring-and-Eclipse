package jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class CrudOperation {
	public static Connection con = null;
	
	public static Connection connectDb() throws ClassNotFoundException, SQLException {
		Class.forName("com.mysql.cj.jdbc.Driver");
		 return con = DriverManager.getConnection("jdbc:mysql://localhost:3306/jdbc","root","Admin@123");
	}
	
	public void insertEmployee() throws SQLException {
		Statement st = con.createStatement();
		String s = "insert into employee values(1006,'Damini','Mohan')";
		int i = st.executeUpdate(s);
		if(i>0)
			System.out.println("Employee inserted Successfully");
	}
	
	public void updateEmployee() throws SQLException {
		Statement st =con.createStatement();
		String s = "update employee set fname='Anamika' where id=1002";
		int i=st.executeUpdate(s);
		if(i>0)
			System.out.println("Employee Updated Successfully");
	}
	
	public void deleteEmployee() throws SQLException {
		Statement st =con.createStatement();
		String s = "delete from employee where id=1005";
		int i = st.executeUpdate(s);
		if(i>0)
			System.out.println("Employee deleted successfully");
	}
	
	public void viewEmployees() throws SQLException {
		Statement st=con.createStatement();
		ResultSet rs=st.executeQuery("select* from employee");
		while(rs.next()) {
			System.out.println("id: "+rs.getInt(1));
			System.out.println("fname: "+rs.getString(2));
			System.out.println("lname: "+rs.getString(3));
			
			System.out.println("======================================");
		}
	}

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		CrudOperation c = new CrudOperation();
		Scanner scn = new Scanner(System.in);
		int choice;
		try {
			con=c.connectDb();
			do {
				System.out.println("Select an operation:");
				System.out.println("1. Insert employee");
				System.out.println("2. Update employee");
				System.out.println("3. Delete employee");
				System.out.println("4. view employee");
				System.out.println("5. Exit");
				choice = scn.nextInt();
				switch (choice) {
				case 1: {
					c.insertEmployee();
					break;
				}
				case 2:{
					c.updateEmployee();
					break;
				}
				case 3:{
					c.deleteEmployee();
					break;
				}
				case 4:{
					c.viewEmployees();
					break;
				}
				case 5:{
					return;
				}
				default:
					System.out.println("Invalid choice");
				}
			}while(choice!=5);
		}catch(ClassNotFoundException e) {
			e.printStackTrace();
		}finally {
			try {
				if(con!=null)
					con.close();
			} catch (SQLException e) {
			e.printStackTrace();
			}
		}
			scn.close();
	}
}
