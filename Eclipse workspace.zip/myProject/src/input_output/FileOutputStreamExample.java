package input_output;

import java.io.FileOutputStream;
import java.io.IOException;

public class FileOutputStreamExample {

	public static void main(String[] args) {
	try(FileOutputStream fos = new FileOutputStream("c://mp//output.txt")){
		String content = "Hello";
		fos.write(content.getBytes());
		System.out.println("Success");
	}catch (IOException e) {
		e.printStackTrace();
	}
	}

}
