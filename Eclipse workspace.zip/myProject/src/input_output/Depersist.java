package input_output;

import java.io.FileInputStream;
import java.io.ObjectInputStream;

public class Depersist {

	public static void main(String[] args) {
	try {
		FileInputStream fis = new FileInputStream("c://mp//persist.txt");
		ObjectInputStream in = new ObjectInputStream(fis);
		Student s = (Student)in.readObject();
		System.out.println(s.toString());
		in.close();
	}catch(Exception e) {
		System.out.println(e);
	}

	}

}
