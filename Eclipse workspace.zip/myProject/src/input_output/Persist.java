package input_output;

import java.io.FileOutputStream;
import java.io.ObjectOutputStream;

public class Persist {

	public static void main(String[] args) {
	try {
		Student s1 =new Student(24, "Ramesh");
		FileOutputStream fout = new FileOutputStream("c://mp//persist.txt");
		ObjectOutputStream out = new ObjectOutputStream(fout);
		out.writeObject(s1);
		out.flush();
		out.close();
		System.out.println("Success");
	}catch(Exception e) {
		System.out.println(e);
	}

	}

}
