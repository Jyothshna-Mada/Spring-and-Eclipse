package lambda;

public class Anonymous {

	public static void main(String[] args) {
	Readable e1 = new Readable() {
		
		@Override
		public void getName() {
			System.out.println("Aakash");
			
		}
	};

	e1.getName();
	}

}
