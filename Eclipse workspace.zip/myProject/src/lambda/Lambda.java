package lambda;

public class Lambda {

	public static void main(String[] args) {
		Readable r2 =  ()->
		System.out.println("Vikas");
		r2.getName();

	}

}
