package lambda;

interface sayable{
	String say(String name);
}

public class LambdaE1 {

	public static void main(String[] args) {
		sayable s1= name->
		"Hello, "+name;
		
		System.out.println(s1.say("Joshu"));

	}

}
