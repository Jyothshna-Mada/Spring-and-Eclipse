package myProject;

public class MethodEx {

	public float product(float x,float y) {
		return x*y;
	}
	
	public static void main(String[] args) {
		MethodEx m1 = new MethodEx();
		float z= m1.product(20.5f,50.0f);
		float a = m1.product(30.0f, 10.5f);
		System.out.println("The sum of two numbers is: "+z);
		System.out.println("The sum of two numbers is: "+a);
	}

}
