package myProject;

import java.util.Scanner;
import java.lang.Object;

public class IFEX {

	public static void main(String[] args) {
//		int empId =126;
//		int retirementAge = 58;
//		int empAge=34;
		Scanner scn= new Scanner(System.in);
		System.out.println("Enter employee id");
		int empId=scn.nextInt();
		
		System.out.println("Enter employee RetirementAge");
		int retirementAge=scn.nextInt();
		
		System.out.println("Enter employee Age");
		int empAge=scn.nextInt();
		
		if((empAge<retirementAge)&&(empId==126)) {
			System.out.println("calculate Salary");
		}
		else
			System.out.println("calculate Pension");
	}

}
