package myProject;

public class Stringss {

	public static void main(String[] args) {
		String s="willow";
		String s1="ow";
		System.out.println(s=="willow");
		System.out.println(s=="will"+"ow");
		System.out.println(s=="will"+s1);
		
//		int num1=0102;
//		int num2=-10;
//		int s=num1%num2;
//		System.out.println(s);
	}

}
