package myProject;

public class StringBuild {

	public static void main(String[] args) {
		StringBuilder sb = new StringBuilder("");

		sb.append(" Programming");
		sb.insert(4, " Language");
		System.out.println(sb);

	}

}
