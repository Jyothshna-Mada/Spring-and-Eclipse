package myProject;

public class StudentMain {
	public static void main(String[]args) {
		Student s1 = new Student();
		int i=s1.registrationId=1290;
		System.out.println(i);
		
		s1.displayRegistration();
	}
}
	

