package myProject;

class Caar{
	public void Driver() {
		System.out.println("cool");
	}
}
class Audi extends Caar{
	public void getMilage() {
		System.out.println("7 kmpl");
	}
}
class Toyoto extends Caar{
	public void getMilage() {
		System.out.println("Good");
	}
}
public class ShowRoom2 {

	public static void main(String[] args) {
		Audi a1 = new Audi();
		Toyoto t1 = new Toyoto();
		a1.getMilage();
		a1.Driver();
		
		t1.Driver();
		
		t1.getMilage();

	}

}
