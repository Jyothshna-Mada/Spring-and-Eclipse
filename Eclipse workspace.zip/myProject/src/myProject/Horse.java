package myProject;
 class Animal{
	 public  void run() {
		 System.out.println("Animal is running");
	 }
 }
 
 
public class Horse extends Animal{
	@Override
	 public  void run() {
		super.run();
		 System.out.println("Horse is running");
	 }
	public static void main(String[] args) {
		Animal a1= new Animal();
		Horse h1 = new Horse();
		a1.run();
		h1.run();
		
		//upcasting
		
		Animal a2= new Horse();
		a2.run();
		
		//down Casting
		
//		Horse h2 = (Horse)new Animal();
//		h2.run();
	}

}
