package multiThreading;

public class ThreadExMain {

	public static void main(String[] args) throws InterruptedException {
		ThreadEx t1 = new ThreadEx("first");
		ThreadEx t2 = new ThreadEx("Second");
		
		System.out.println("Thread Name: "+t1.getName());
		System.out.println("Thread Priority: "+t1.getPriority());
		t1.setPriority(2);
		System.out.println("New Thread Priority: "+t1.getPriority());
		t1.setName("t1Thread");
		System.out.println("New Thread Name: "+t1.getName());
		
		t1.start();
		t2.start();
		for(int i=0;i<5;i++) {
			System.out.println("Printing num from "+Thread.currentThread().getName()+" :: "+i);
			Thread.sleep(1000);
		}

	}

}
