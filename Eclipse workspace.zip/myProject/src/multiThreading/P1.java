package multiThreading;

public class P1 {

	public static void main(String[] args) {
		Thread t =Thread.currentThread();
		System.out.println(t);

	}

}
