package multiThreading;
import java.lang.Thread;

public class ThreadEx extends Thread{
	public ThreadEx(String name) {
		this.setName(name);
	}
	public void run() {
		for(int i=0;i<5;i++) {
			System.out.println("Printing num from "+Thread.currentThread().getName()+" :: "+i);
			try {
				Thread.sleep(100);
			}catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}

}
