package collections;

import java.util.ArrayList;
import java.util.Iterator;

public class UserDefined {

	public static void main(String[] args) {
		Student s1 = new Student("Surya", 21, 90);
		Student s2 = new Student("vikas", 21, 95);
		Student s3 = new Student("sirisha", 21, 96);
		
		ArrayList<Student> s4 = new ArrayList<Student>();
		s4.add(s1);
		s4.add(s2);
		s4.add(s3);
		
		Iterator<Student> s5 = s4.iterator();
		while(s5.hasNext()) {
			Student a=s5.next();
			
			System.out.println(a.name);
			System.out.println(a.age);
			System.out.println(a.score);
		}
	}

}
