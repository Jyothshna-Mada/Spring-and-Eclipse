package collections;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

public class LinkedListEx {

	public static void main(String[] args) {
		LinkedList<String> l1 = new LinkedList<String>();
		
		l1.add("orange");
		l1.add("apple");
		l1.add("grapes");
		l1.add("orange");
		
		l1.addFirst("PineApple");
		l1.addLast("Banana");
		
		l1.add(2, "Watermelon");
		
		l1.removeFirst();
		l1.removeLast();
		l1.remove(2);
		
		l1.add("grapes");
		l1.add("Stawberry");
		l1.add("orange");
		l1.add("Banana");
		l1.add("apple");
		
		l1.removeFirstOccurrence("orange");
		l1.removeLastOccurrence("grapes");
		
		l1.push("Jelly");//adds at first
		l1.pop();//removes the first element---->FIFO
		
		
		Iterator<String> i1=l1.iterator();
		while(i1.hasNext()) {
			System.out.println(i1.next());
		}
		
		System.out.println("Size of linked List: "+l1.size());
		System.out.println("peek: "+l1.peek());
		System.out.println("peek first: "+l1.peekFirst());
		System.out.println("peeklast: "+l1.peekLast());
		
	}
}
