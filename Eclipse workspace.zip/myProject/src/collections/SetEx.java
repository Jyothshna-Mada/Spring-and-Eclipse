package collections;

import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Set;

public class SetEx {

	public static void main(String[] args) {
		Set<String> s1 = new LinkedHashSet<>();
		s1.add("Orange");
		s1.add("Apple");
		s1.add("Banana");
		s1.add(null);
		s1.add(null);
		s1.add("Orange");
		
		Iterator<String> iterator = s1.iterator();
		while(iterator.hasNext()) {
			System.out.print(iterator.next()+" ");
		}
		
		

	}

}
