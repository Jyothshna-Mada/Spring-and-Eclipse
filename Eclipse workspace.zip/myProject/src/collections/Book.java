package collections;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Book implements Comparable<Book>{
	private String title;
	private int year;
	
	public Book(String title, int year) {
		this.title = title;
		this.year = year;
	}
	

	@Override
	public int compareTo(Book otherBook) {
		return this.year-otherBook.year;
	}
	
	
	
	@Override
	public String toString() {
		return title+" ( "+year + " )";
	}


	public static void main(String[] args) {
		Book book1 = new Book("The Catcher in the Rye", 1951);
		Book book2 = new Book("To kill a mockingBird", 1960);
		Book book3 = new Book("python", 2021);
		Book book4 = new Book("Brave new World", 1932);
		
		
		List<Book> books = new ArrayList<Book>();
		
		books.add(book1);
		books.add(book2);
		books.add(book3);
		books.add(book4);
		
		Collections.sort(books);
		
		
		for(Book book :books) {
			System.out.println(book);
		}
		
	}
	

}
