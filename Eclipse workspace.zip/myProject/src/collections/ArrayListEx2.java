package collections;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Vector;


public class ArrayListEx2 {

	public static void main(String[] args) {
		List<String> fruits = new Vector<String>();
		
		fruits.add("Apple");
		fruits.add("Mango");
		fruits.add("Orange");
		fruits.add("Banana");
		fruits.add(null);
		fruits.add("Kiwi");
		fruits.add("Kiwi");
		
		fruits.add(1, "Lemon");
		System.out.println(fruits);
		
		//Collections.reverse(fruits);
		//System.out.println("After reverse "+fruits);
		
		
//		List<String> machine = new ArrayList<String>();
//		machine.add("WM");
//		machine.add("TV");
//		fruits.addAll(machine);
//		
//		fruits.retainAll(machine);
//		
//		System.out.println(machine);
		
		
		
//		Iterator<String> i= fruits.iterator();
//		while (i.hasNext()) {
//			System.out.println(i.next());
//		}
		
		System.out.println("First Item: "+fruits.get(0));
			System.out.println("size of a list: "+fruits.size());
			System.out.println("Last Item: "+fruits.get(fruits.size()-1));
			
			fruits.remove(5);
			fruits.remove("Kiwi");
			
			for(String item:fruits) {
				System.out.print(item+" ");
			}
			System.out.println(" ");
			System.out.println("//Using Iterator//");
			
			Iterator<String> iterator = fruits.iterator();
			while (iterator.hasNext()) {
				System.out.println(iterator.next());
			}
			
			
			List g=fruits.subList(1, 5);
			
			System.out.println("Sub list: "+g);
			
			System.out.println(fruits);
			
			System.out.println(fruits.isEmpty());
		
	}

}
