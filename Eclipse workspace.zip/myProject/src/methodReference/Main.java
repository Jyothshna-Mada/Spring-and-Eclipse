package methodReference;

import java.util.function.Function;

interface MyFuncEx{
	void execute();
}

public class Main {

	public static void main(String[] args) {
		Function<String, Integer> stringToInteger=Integer::parseInt;
		Integer result = stringToInteger.apply("123");
		System.out.println(result);
		
		

	}

}
