package com.example.String;

public class StringBufferTest {

	public static void main(String[] args) {
		StringBuffer sb = new StringBuffer("Hello");
		
		sb.append(", World");
		System.out.println("Appended : "+sb.toString());
		
		sb.insert(5, "java");
		System.out.println("inserted: "+sb.toString());
		
		System.out.println("length: "+sb.length());
		
		sb.setCharAt(5, ' ');
		System.out.println(sb);
		
		sb.deleteCharAt(3);
		System.out.println(sb);
		
		System.out.println(sb.capacity());
		
		sb.reverse();
		System.out.println("reverse: "+sb.toString());

	}

}
