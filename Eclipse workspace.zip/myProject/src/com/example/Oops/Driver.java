package com.example.Oops;

public class Driver {

	public static void main(String[] args) {
		Iname i1 = new Myname();
		Iname i2 = new Myname2();
		Iaddress i3=new Myname();
		i1.getName();
		i2.getName();
		System.out.println(Iname.pi);
		i3.myAddress();
		
		Myname m1 = new Myname();
		m1.Testing();
	}

}
