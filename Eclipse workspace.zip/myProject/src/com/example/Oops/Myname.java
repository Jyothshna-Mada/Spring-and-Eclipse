package com.example.Oops;

public class Myname extends Test implements Iname,Iaddress{

	@Override
	public void getName() {
		System.out.println("My name is Jyothshna");
		
	}

	@Override
	public void myAddress() {
		System.out.println("New Delhi");
		
	}

	

}

class Test{
	public void Testing() {
		System.out.println("Testing");
	}
}
	class Myname2 implements Icity{

		@Override
		public void getName() {
			System.out.println("Hari");
			
		}

		@Override
		public void myAddress() {
			
			
		}

		@Override
		public void myCity() {
		
			
		}
		
	}
	

