package com.example.Oops;

public class D implements Bc,Cd{

	@Override
	public void display() {
		Bc.super.display();
		Cd.super.display();
		
	}
	public static void main(String[] args) {
		D obj = new D();
		obj.display();

	}

}
