package com.example.Oops;

public interface Iname {
	//all variable are by default static final
	double pi=3.14;
	//all methods are by default abstract
	public void getName();
}
interface Iaddress{
	public void myAddress();
}

interface Icity extends Iname,Iaddress{
	public void myCity();
}