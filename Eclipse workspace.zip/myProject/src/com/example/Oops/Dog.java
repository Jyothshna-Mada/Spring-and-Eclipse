package com.example.Oops;

public class Dog extends Animal{

	@Override
	public void makeNoise() {
		System.out.println("woof-woof");
		
	}
	

}
