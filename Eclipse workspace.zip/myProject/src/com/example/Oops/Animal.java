package com.example.Oops;

public abstract class Animal {

	public abstract void makeNoise();
	
	public static void main(String[]args) {
		Animal a1 = new Dog();
		Animal a2 = new Cat();
		a1.makeNoise();
		a2.makeNoise();
	}
}
