package com.example.Exception;

public class MultipleCatchBlock {

	public static void main(String[] args) {
	try {
		int a[] = new int[5];
		a[5]=30/2;
	}catch(ArithmeticException e) {
		System.out.println("ArithmaticExecption occurs");
	}catch(ArrayIndexOutOfBoundsException e) {
		System.out.println("Array out of bound execption occur");
	}

	}

}
