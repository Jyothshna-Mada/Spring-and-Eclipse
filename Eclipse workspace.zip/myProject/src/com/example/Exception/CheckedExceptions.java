package com.example.Exception;

import java.io.FileWriter;
import java.io.IOException;

public class CheckedExceptions {

	public static void main(String[] args) throws IOException {
		FileWriter fw = new FileWriter("c://mp//welcome.txt");
		fw.write("Welcome to checked Exception");
		fw.close();
		System.out.println("success");
		//fileNotFoundException--Checked EXception
	}

}
