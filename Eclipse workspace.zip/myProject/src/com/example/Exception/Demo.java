package com.example.Exception;

public class Demo {
	
	int divisor;
	int dividend;
	
}
