package com.example.Exception;

public class TryCatchFinally {
	public  void divide(int a,int b) {
		int quotient=0;
		try {
			quotient=a/b;
			
		}catch(ArithmeticException e) {
			System.out.println("Exception occured "+e.getMessage());
		}
		finally {
			System.out.println("The quotient is "+quotient);
		}
	}

	public static void main(String[] args) {
		TryCatchFinally t= new TryCatchFinally();
		t.divide(12, 0);
	}

}
