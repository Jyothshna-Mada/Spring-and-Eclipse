package com.example.Exception;

public class UserRegistration {
public void registerprofile(String userName, int age, String Country) {
	
}
}
