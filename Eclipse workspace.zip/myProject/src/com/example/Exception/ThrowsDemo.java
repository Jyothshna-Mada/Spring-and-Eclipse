package com.example.Exception;

public class ThrowsDemo {

	public static void main(String[] args) {
		int result=0;

	}

}
