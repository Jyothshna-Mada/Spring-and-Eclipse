package com.example.Exception;

public class ExecptionEx {

	public static void main(String[] args) {
		try {
		int x =10;
		int y=0;
		int z = x/y;
		System.out.println(z);
		}
		catch(ArithmeticException e) {
			System.out.println("Divide by zero");
			System.exit(00);
		}
		finally {
			System.out.println("Copyright by example");
		}
		
		System.out.println("Rest of the program");
	}

}
