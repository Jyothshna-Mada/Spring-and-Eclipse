package com.example.Array;

import java.util.Arrays;

public class ArrayUtilityClass {

	public static void main(String[] args) {
		int [] numbers = {5,2,8,1,3};
		Arrays.sort(numbers);
		System.out.println("SortedArray: "+Arrays.toString(numbers));
		
		int index = Arrays.binarySearch(numbers, 3);
		System.out.println("Element 3 found at index: "+index);
	}

}
