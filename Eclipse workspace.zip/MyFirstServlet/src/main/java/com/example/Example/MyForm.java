package com.example.Example;

import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/FormExample")
public class MyForm extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String name= request.getParameter("Name");
		String age = request.getParameter("Age");
		String email=request.getParameter("Email");
		
		//response.setContentType("text/html");
		
		//response.getWriter().println("<html><body>");
		response.getWriter().println(" <h1>Form received</h1>");
		response.getWriter().println("<h1>Welcome "+name+"</h1>");
		response.getWriter().println("<h1>age: "+age+"</h1>");
		response.getWriter().println(" <h1> Email: "+email+"/h1>");
		//response.getWriter().println("</body></html>");
	
	}

}
