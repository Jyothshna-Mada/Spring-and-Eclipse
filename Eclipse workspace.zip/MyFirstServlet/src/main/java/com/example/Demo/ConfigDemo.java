package com.example.Demo;

import java.io.IOException;
import java.io.PrintWriter;

import jakarta.servlet.ServletConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;




public class ConfigDemo extends HttpServlet {

	private String adminEmail;
	
	
	public void init(ServletConfig config) throws ServletException {
		adminEmail=config.getInitParameter("adminEmail");
	}
       

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		
		response.setContentType("text/html");
		out.println("<html><head>");
		out.println("<title>Config Demo</title>");
		out.println("</head><body>");
		out.println("<h1> The Admin Email is "+adminEmail+" </h1>");
		out.println("</body></html>");
		
		
	}

}
