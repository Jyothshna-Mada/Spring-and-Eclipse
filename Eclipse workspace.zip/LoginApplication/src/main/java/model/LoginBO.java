package model;

public class LoginBO {
	public boolean isValidUser(User user) throws BusinessException {
		LoginDao dao = new LoginDao();	
		 if (user.getUsername().length() < 4|| user.getUsername().length() >15) 
	            throw new BusinessException("UserName should be 4-15 character length");
	         else 
	        	return dao.LoginValidate(user); 	
	}
}
