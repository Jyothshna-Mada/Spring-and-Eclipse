package miniProject_2;

import java.util.ArrayList;
import java.util.List;

public class Inventory {

	private List<Medicine> medicines=new ArrayList<>();
	public Inventory() {
		medicines.add(new Medicine("Paracetamol","For fever and pain relief", 5.00, 100));
		medicines.add(new Medicine("Amoxicillin", "Antibiotic for infections", 10.00, 50));
		medicines.add(new Medicine("Loratadine","Antihistamine", 7.50, 75));
		
	}
	
	public List<Medicine> getAllMedicines(){
		return medicines;
	}
	
	public Medicine getMedicineByName(String name) {
		for(Medicine medicine : medicines) {
			if(medicine.getName().equalsIgnoreCase(name)) {
				return medicine;
			}
		}
		return null;
	}
}
