package miniProject_2;

import java.util.List;
import java.util.Scanner;

public class OnlineMedicineShopping {
	
	private static UserManager userManager= new UserManager();
	private static Inventory inventory=new Inventory();
	private static ShoppingCart cart= new ShoppingCart();

	public static void main(String[] args) {
		Scanner scn = new Scanner(System.in); 
		boolean exit=false;
		 while (!exit) { 
		 System.out.println("==== Online Medicine Shopping System ====="); 
		 System.out.println("1. Login"); 
		 System.out.println("2. Register"); 
		 System.out.println("3. Browse Medicines"); 
		 System.out.println("4. View Cart"); 
		 System.out.println("5. Checkout"); 
		 System.out.println("6. Exit"); 
		 System.out.print("Enter your choice: "); 

		 int choice = scn.nextInt(); 
		 scn.nextLine();  
		  switch (choice) { 
		  case 1: 
		  login(scn); 
		  
		  break; 
		  case 2: 
		  register(scn); 
		  break; 
		  case 3: 
		  browseMedicines(scn); 
		  break; 
		  case 4: 
		  viewCart(); 
		  break; 
		  case 5: 
		  checkout(); 
		  break; 
		  case 6: 
		  System.out.println("Exiting..."); 
		  exit=true;
		  break;
		  default: 
		  System.out.println("Invalid choice! Please try again."); 
		   
		  }

		 }

	}
	
	private static void login(Scanner scn) { 
		 System.out.print("Enter username: "); 
		 
		 String username = scn.nextLine(); 
		 System.out.print("Enter password: "); 
		 String password = scn.nextLine(); 
		 if (userManager.login(username, password)) { 
		 System.out.println("Login successful!"); 
		 } else { 
		 System.out.println("Invalid credentials. Please try again."); 
		 	} 
		 } 
	
	private static void register(Scanner scanner) { 
		System.out.print("Enter username: "); 
		String username = scanner.nextLine(); 
		System.out.print("Enter password: "); 
		String password = scanner.nextLine(); 
		System.out.print("Enter email: "); 
		String email = scanner.nextLine(); 
		if (userManager.register(username, password, email)) { 
		System.out.println("Registration successful! You can now login."); 
		} else { 
		System.out.println("Username already exists. Please try a different username."); 
			} 
		} 

	private static Medicine browseMedicines(Scanner scn) { 
		 
		 List<Medicine> medicines = inventory.getAllMedicines(); 
		 Medicine med =null;
		 if (medicines.isEmpty()) { 
		 System.out.println("No medicines available."); 
		 } else { 
		 System.out.println("Available Medicines:"); 
		 for (Medicine medicine : medicines) { 
		 System.out.println(medicine); 
		 		}
			 System.out.print("Enter the Name of the medicine to add to cart(write 'Exit' to exit): ");
			 String name=scn.nextLine();

				 if(!name.equalsIgnoreCase("exit")) {
					 med= inventory.getMedicineByName(name);
					 if(med!=null) {
						 cart.addItem(med);
						 System.out.println(name+" added to cart");
					 }else {
						 System.out.println("Medicine not found");
					 }
					
			 	}
				 if(name.equalsIgnoreCase("yes")) {
					 return null;
				 }
			} 
		 
		 return med;
	}

	private static void viewCart() { 
		List<Medicine> cartItems = cart.getItems(); 
		if (cartItems.isEmpty()) { 
		System.out.println("Your cart is empty."); 
		} else { 
		System.out.println("Your Cart:"); 
		for (Medicine medicine : cartItems) { 
		System.out.println(medicine); 
			} 
			} 
		} 

	private static void checkout() { 
		double totalAmount = cart.calculateTotal(); 
		 
		System.out.println("Total amount: $" + totalAmount); 
		cart.clear(); 
		System.out.println("Checkout successful! Your cart is now empty."); 
		} 
		

}
