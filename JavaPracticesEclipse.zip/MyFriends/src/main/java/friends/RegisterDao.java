package friends;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class RegisterDao {
		
		private Connection createConnection() throws SQLException {
			try {
				Class.forName("com.mysql.cj.jdbc.Driver");
				return DriverManager.getConnection("jdbc:mysql://localhost:3306/friends", "root", "Admin@123");
			} catch (Exception e) {
				throw new SQLException("Error creating connection", e);
			}
		}

		public boolean insertUser(User user) throws BusinessException {
			boolean flag = false;
			try {
				Connection con = createConnection();
				String qryString = "INSERT INTO loginfriend(firstname, lastname, country, languageknown,gender) "
						+ "VALUES (?, ?, ?, ?, ?)";
				PreparedStatement prepStatement = con.prepareStatement(qryString);
				
				prepStatement.setString(1, user.getFirstName());
				prepStatement.setString(2, user.getLastName());
				prepStatement.setString(3, user.getCountry());
				prepStatement.setString(4, String.join(",",user.getLanguage()));
				prepStatement.setString(5, user.getGender());
				
				if (prepStatement.executeUpdate() > 0) {
					flag = true;
				}
			} catch (SQLException e) {
				throw new BusinessException("Error inserting user"+ e);
			}
			return flag;
		}
	}

