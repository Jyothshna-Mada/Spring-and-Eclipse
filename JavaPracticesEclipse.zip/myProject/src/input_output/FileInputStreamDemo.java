package input_output;

import java.io.FileInputStream;
import java.io.IOException;

public class FileInputStreamDemo {

	public static void main(String[] args)  {
		try(FileInputStream fis = new FileInputStream("c://mp//output.txt")){
			int content;
			while((content=fis.read())!=-1) {
				System.out.print((char)content);
			}
		}catch (IOException e) {
			e.printStackTrace();
		}

	}

}
