package garbageCollect;

public class GCExample {

	public static void main(String[] args) {
		MyClass obj = new MyClass("Object 1");
		System.out.println("Created: "+obj);
		obj=null;
		
		Runtime.getRuntime().gc();
		
		try {
			Thread.sleep(2000);
		}catch(InterruptedException e) {
			e.printStackTrace();
		}
		
		MyClass obj2 = new MyClass("Object 2");
		System.out.println("Created: "+obj2);

	}

}
