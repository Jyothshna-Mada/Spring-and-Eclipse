package designPattern;

public class AccessObject {

	public static void main(String[] args) {
		SingletonClass s1= SingletonClass.getInstance();
		
		s1.show();

	}

}
