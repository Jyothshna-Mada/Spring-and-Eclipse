package jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;

public class ResultSetMetaDataEx {

	public static void main(String[] args) {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/jdbc","root","Admin@123");
			String query = "select * from employee";
			PreparedStatement ps = con.prepareStatement(query);
			ResultSet rs = ps.executeQuery();
			
			ResultSetMetaData rsmd = rs.getMetaData();
			int columnCount=rsmd.getColumnCount();
			
			System.out.println("ColumnCount: "+columnCount);
			
			for(int i=1;i<=columnCount;i++) {
				System.out.println("column "+i+": "+ rsmd.getColumnName(i));
				System.out.println("Type: " + rsmd.getColumnTypeName(i));
				System.out.println("Size: " + rsmd.getColumnDisplaySize(i));
                System.out.println("==========================================");
			}
			rs.close();
			ps.close();
			con.close();
		}catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}

	}

}
