package jdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class DbExample {

	public static void main(String[] args) {
	try(Connection con=DbUtil.getConnection()){
		String query ="select * from employee";
		try(PreparedStatement ps =con.prepareStatement(query);
				ResultSet rs = ps.executeQuery()){
			while(rs.next()) {
				System.out.println("Id: "+rs.getInt(1));
				System.out.println("First name: "+rs.getString(2));
				System.out.println("Last name: "+rs.getString(3));
				System.out.println("============================");
			}
		}
	}catch (Exception e) {
		e.printStackTrace();
	}

	}

}
