package collections;

import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.SortedSet;
import java.util.TreeSet;

public class HashMain {

	public static void main(String[] args) {
	SortedSet<String> items = new TreeSet<String>();
	items.add("Apple");
	items.add("Banana");
	items.add("Carrot");
	items.add("Brocoli");
	items.add("Cherry");
	items.add("Spinach");
	
	System.out.println(items);
	
	boolean hasApple = items.contains("Apple");
	System.out.println("Contains Apple: "+hasApple);

	int size = items.size();
	System.out.println("Size of the set is: "+size);
	
	System.out.println("Is the Set Empty: "+items.isEmpty());
	
	System.out.println("Iterating for each loop");
	
	for(String item:items) {
		System.out.print(item+" ");
	}
	
	System.out.println("Iterating iterator");
	
	Iterator<String> i = items.iterator();
	while(i.hasNext()) {
		System.out.println(i.next());
	}
	
	System.out.println("***********************");
	System.out.println(items.first());
	System.out.println(items.last());
	
	System.out.println(items.headSet("Cherry"));
	System.out.println(items.tailSet("Brocoli"));
	
	
	}

}
