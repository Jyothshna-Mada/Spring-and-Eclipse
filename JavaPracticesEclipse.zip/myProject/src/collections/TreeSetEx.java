package collections;

import java.util.Iterator;
import java.util.SortedSet;
import java.util.TreeSet;

public class TreeSetEx {

	public static void main(String[] args) {
		SortedSet<String> s1 = new TreeSet();
		s1.add("Orange");
		s1.add("Apple");
		s1.add("Banana");
		s1.add("null");
		s1.add("null");
		s1.add("Orange");
		
		Iterator<String> iterator = s1.iterator();
		while(iterator.hasNext()) {
			System.out.print(iterator.next()+" ");
		}

	}

}
