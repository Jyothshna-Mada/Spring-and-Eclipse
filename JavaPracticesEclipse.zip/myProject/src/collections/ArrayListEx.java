package collections;

import java.util.ArrayList;
import java.util.List;

public class ArrayListEx {
	
	public List getCountryList(String s1,String s2,String s3,String s4,String s5) {
		List<String> mylist = new ArrayList<String>();
		
		mylist.add(s1);
		mylist.add(s2);
		mylist.add(s3);
		mylist.add(s4);
		mylist.add(s5);
		return mylist;
	}
	
	public List getNumbers() {
		List<Integer> num = new ArrayList<Integer>();
		for(int i=1;i<=10;i++) {
			num.add(i);
		}
		return num;
	}
	
	public List getNum(List num) {
		List<Integer> list = new ArrayList<Integer>();
		list.addAll(num);
		for(int i=11;i<=15;i++) {
			list.add(i);
		}
		return list;
	}

	public static void main(String[] args) {
		
		ArrayListEx a = new ArrayListEx();
		System.out.println(a.getCountryList("India", "Australia", "England", "New Zealand", "India"));
		List numbersList=a.getNumbers();
		System.out.println(numbersList);
		System.out.println(a.getNum(numbersList));

	}

}
