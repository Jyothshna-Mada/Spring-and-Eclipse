package collections;

public class Student {
	String name;
	int age;
	int score;
	
	public Student(String name, int age, int score) {
		this.name = name;
		this.age = age;
		this.score = score;
	}
	
	

}
