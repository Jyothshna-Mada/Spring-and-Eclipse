package collections;

import java.util.Enumeration;
import java.util.Vector;

public class VectorEx {

	public static void main(String[] args) {
		int n = 5;
		Vector<Integer> v = new Vector<Integer>(n);
		
		for(int i=1;i<=n;i++) {
			v.add(i);
		}
		
		System.out.println("vector elements are: "+v);
		
		v.remove(3);
		System.out.println("After Removal: "+v);
		
		for(int i=0;i<v.size();i++) {
			System.out.print(v.get(i)+" ");
		}
		System.out.println();
		
		
		Enumeration<Integer> e = v.elements();
		System.out.println("vector elements using enumeration");
		while(e.hasMoreElements()) {
			System.out.print(e.nextElement()+" ");
		}
		System.out.println();
	System.out.println(	v.capacity());
		
		n=10;
		Vector<Integer> v1 = new Vector<Integer>(n);
		for(int i=1;i<=n;i++) {
			v1.add(i);
		}
		v1.add(22);
		System.out.println("Vector 1 elements are: "+v1);
		v1.removeAllElements();
		//System.out.println(v1.firstElement()); ---> NoSuchElementException
		
		Vector v2 = new Vector();
		System.out.println(	v2.capacity());

	}

}
