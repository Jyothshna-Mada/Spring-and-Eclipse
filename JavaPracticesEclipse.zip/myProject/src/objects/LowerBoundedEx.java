package objects;

import java.util.ArrayList;
import java.util.List;

public class LowerBoundedEx {

	public static void addNumbers(List<? super Integer>list) {
		list.add(1);
		list.add(2);
	}
	
	public static void main(String[] args) {
		List<Number> numlist = new ArrayList<>();
		addNumbers(numlist);
		
		List<Object> objList =new ArrayList<>();
		addNumbers(objList);
		
		System.out.println(numlist);
		System.out.println(objList);

	}

}
