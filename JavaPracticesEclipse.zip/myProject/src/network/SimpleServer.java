package network;

import java.io.*;
import java.net.*;


public class SimpleServer {

	public static void main(String[] args) throws IOException {
		ServerSocket serversocket = new ServerSocket(123);
		System.out.println("server is listening on port 123");
		
		while(true) {
			Socket socket = serversocket.accept();
			PrintWriter out = new PrintWriter(socket.getOutputStream(),true);
			out.println("Hello from the server!");
			socket.close();
		}

	}

}
