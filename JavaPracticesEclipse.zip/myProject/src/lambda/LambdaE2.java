package lambda;

interface Addable{
	int add(int a,int b);
}
public class LambdaE2 {

	public static void main(String[] args) {
		Addable a1 =(a,b)->a+b;
		
		System.out.println(a1.add(12, 15));
		
		System.out.println(a1.add(20, 30));

	}

}
