package lambda;

public class MyClass implements Readable{

	public static void main(String[] args) {
		Readable r1 = new MyClass();
		r1.getName();

	}

	@Override
	public void getName() {
		System.out.println("Aakash");
		
	}

}
