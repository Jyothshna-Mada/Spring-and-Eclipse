package lambda;

public interface Readable {
	
	public void getName();

}
