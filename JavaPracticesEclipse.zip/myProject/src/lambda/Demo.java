package lambda;

@FunctionalInterface
interface MyFunctionalInterface{
	void execute();
}
public class Demo {

	public static void main(String[] args) {
	MyFunctionalInterface Myfunc = ()->
	System.out.println("Executing");

	Myfunc.execute();
	}

}
