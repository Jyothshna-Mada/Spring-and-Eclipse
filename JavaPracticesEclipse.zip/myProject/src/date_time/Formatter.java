package date_time;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class Formatter {

	public static void main(String[] args) {
	LocalDate date = LocalDate.of(2024, 7, 23);
	
	DateTimeFormatter f1 = DateTimeFormatter.ofPattern("dd/MM/yyyy");
	
	String fDate1 = date.format(f1);
	System.out.println(fDate1);
	
	
	

	}

}
