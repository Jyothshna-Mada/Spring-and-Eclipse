package com.mphasis.Oops;

public class B {
	public static void main(String[] args) {
		A a1 = new A();
		a1.setAge(20);
		a1.setName("Radha");
		System.out.println("Age is :"+a1.getAge());
		System.out.println("Name is :"+a1.getName());
	}

}
