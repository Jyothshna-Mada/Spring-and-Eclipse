package com.mphasis.Oops;

public class A {
	
	private int age;
	private String name;
	
	//Java beans reusable components
	//accessor
	public int getAge() {
		return age;
	}
	//mutator
	public void setAge(int age) {
		this.age=age;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
}
