package com.mphasis.Oops;

public interface Ab {
	abstract void display();
}
	interface Bc extends Ab{
		default void display() {
			System.out.println("Display from Interface B");
		}
	}

	interface Cd extends Ab{
		default void display() {
			System.out.println("Display from Interface C");
		}
	}