package com.mphasis.Oops;

import java.util.Scanner;

public class Fibonacci {

	public static void main(String[] args) {
		
		 Scanner scanner = new Scanner(System.in); 
		 System.out.print("Enter the number: "); 

		 int num = scanner.nextInt(); 
		 int sum = 0; 
		 int a = 0, b = 1; 

		 for (int i = 0; i <= 2 * num; i++) { 
			 if (i % 2 == 0) {  
				 sum=sum+ a; 
			 } 
			 int c = a+b; 
			 a = b; 
			 b = c; 
		 } 

		 System.out.println("Sum of Fibonacci numbers at even indexes up to " +num+ " terms: " + sum); 
		 } 

	} 

