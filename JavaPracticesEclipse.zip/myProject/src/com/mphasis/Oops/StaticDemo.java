package com.mphasis.Oops;

public class StaticDemo {
	
	public static void sum() {
		int x=10;
		int y=20;
		int z = x+y;
		System.out.println(z);
	}

	public static void main(String[] args) {
		sum();
		System.out.println("**********");
		StaticDemo.sum();

	}

}
