package com.mphasis.Oops;

public class C {

	public static void main(String[] args) {
		A a1 = new A();
		a1.setAge(22);
		System.out.println("Age is: "+a1.getAge());
	}

}
