package com.mphasis.Oops;

public class StaticDemo2 {
	static int x=0;
	int y=3;
	StaticDemo2(){
		x++;
		y=y+5;
		System.out.println("static "+x+" "+" Non-static "+y);
	}

	public static void main(String[] args) {
		StaticDemo2 s1 = new StaticDemo2();
		StaticDemo2 s2 = new StaticDemo2();
		StaticDemo2 s3 = new StaticDemo2();

	}

}
