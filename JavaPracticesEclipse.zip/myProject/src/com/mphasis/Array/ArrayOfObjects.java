package com.mphasis.Array;

 class Person {
	String name;
	int age;
	
	
	public Person(String name, int age) {
		this.name = name;
		this.age = age;
	}
	
	void display() {
		System.out.println("Name : "+name+" age : "+age);
	}
 }
public class ArrayOfObjects{
	public static void main(String[] args) {
		Person [] people= {
				new Person("Raj",34),
				new Person("Harsha",26),
				new Person("Aghna",25)
		};
		for(int i=0;i<people.length;i++) {
			people[i].display();
		}
	}

}
