package com.mphasis.Array;

public class ArrayTest {

	public static void main(String[] args) {
	int [] score= {90,85,96,78,67};
	
	for(int n:score) {
		System.out.println("Element: "+n);
	}

	}

}
