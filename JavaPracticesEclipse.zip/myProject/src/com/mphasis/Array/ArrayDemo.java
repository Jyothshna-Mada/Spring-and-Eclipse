package com.mphasis.Array;

public class ArrayDemo {
	int nums[];
	
	public void storeNumbers() {
		nums=new int[101];
		for(int i=0;i<nums.length;i++) {
			nums[i]=i;
		}
	}
	
	public void printEvenNumbers() {
		for(int i =0;i<nums.length;i++) {
			if(nums[i]%2==0) {
				System.out.println(i);
			}
		}
	}
	
	public static void main(String[] args) {
		ArrayDemo a = new ArrayDemo();
		a.storeNumbers();
		a.printEvenNumbers();

	}

}
