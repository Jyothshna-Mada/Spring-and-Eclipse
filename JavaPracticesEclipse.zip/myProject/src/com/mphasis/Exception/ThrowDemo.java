package com.mphasis.Exception;

public class ThrowDemo {
	public void div() {
		int x=10/0;
		System.out.println(x);
		throw new ArithmeticException();
	}

	public static void main(String[] args) {
		
	ThrowDemo d1= new ThrowDemo();
	
	try {
		d1.div();
	}catch(ArithmeticException e) {
		
	}
	}

}
