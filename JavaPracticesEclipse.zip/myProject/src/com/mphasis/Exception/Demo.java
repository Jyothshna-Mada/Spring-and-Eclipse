package com.mphasis.Exception;

public class Demo {
	
	int divisor;
	int dividend;
	
}
