package com.mphasis.String;

public class Immutable {

	public static void main(String[] args) {
		String s="sachin";
		s.concat("Tendulkar");
		
		System.out.println(s);
		
		String s1 = s.concat("Tensdulkar");
		
		System.out.println(s1);
		
		String m1="Mango";
		String m2="Apple";
		
		String m3=m1+m2;
		System.out.println(m3);
		
		String a="sachin";
		String b="sachin";
		String c= new String("sachin");
		String d = "Saurav";
		System.out.println(a.equals(b));//true
		System.out.println(a.equals(c));//true
		System.out.println(a.equals(d));//false
		
		String e="SACHIN";
		System.out.println(a.equalsIgnoreCase(e));//true
		
		String x="Apple";
		String y="Apple";
		String z = new String("Apple");
		
		System.out.println(x==y);//true
		System.out.println(x==z);//false
		
		System.out.println(a.compareTo(b));//0
		System.out.println(a.compareTo(d));//32
		System.out.println(d.compareTo(a));//-32
		
		String name = "Sachin"+" Tendulkar";
		System.out.println(name);
		
		String c1 = 50+40+"Sachin"+40+40;
		System.out.println(c1);
		
		String c2 = 50+40+"Sachin"+(40+40);
		System.out.println(c2);
		
		String nam ="Arjun";
		String nam1="Krishna";
		String name1 =nam.concat(nam1);
		System.out.println(name1);
		
		String sub ="hello";
		String sub2="Sachin Tendulkar";
		System.out.println(sub.substring(0, 2));//he
		System.out.println(sub2.substring(7));//Tendulkar
		
		System.out.println(a.toUpperCase());
		
		String v1="    Sachin   ";
		System.out.println(v1.trim());
		
		String v2 = new String("Sachin");
		String v3=v2.intern();
		System.out.println(v3);
		
		String g= "sachin Tendulkar";
		
	}

}
