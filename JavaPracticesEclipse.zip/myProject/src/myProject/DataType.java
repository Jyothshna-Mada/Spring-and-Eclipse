package myProject;

public class DataType {

	byte b1;
	short s1;
	int i1;
	long l1;
	
	float f1;
	double d1;
	
	char c1;
	boolean bo;
	
	public static void main(String[] args) {
		DataType data = new DataType();
		System.out.println("Byte value is "+data.b1);
		System.out.println("Short value is "+data.s1);
		System.out.println("Integer value is "+data.i1);
		System.out.println("Long value is "+data.l1);
		
		System.out.println("Float value is "+data.f1);
		System.out.println("Double value is "+data.d1);
		
		System.out.println("Char value is "+data.c1);
		System.out.println("Boolean value is "+data.bo);
		
	}
	
}
