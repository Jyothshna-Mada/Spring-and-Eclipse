package myProject;

public class Test {

	public static void main(String[] args) {
		Integer i=1000;
		Integer j=1000;
		System.out.println(i);
		System.out.println(j);
		System.out.println(i==j);

	}

}
