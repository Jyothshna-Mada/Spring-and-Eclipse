package myProject;

public class MethodOverloading {
	
	public int sum(int x,int y) {
		return x+y;
	}
	
	private int sum(int x,int y,int z) {
		return x+y+z;
	}
	
	protected float sum(float f1,float f2) {
		return f1+f2;
	}
	
	double sum (double d1,double d2) {
		return d1+d2;
	}

	public static void main(String[] args) {
		MethodOverloading m1 = new MethodOverloading();
		int add=m1.sum(10,20);
		System.out.println(add);
		
		System.out.println(m1.sum(10, 20, 30));
		System.out.println(m1.sum(21.0, 21.0));
		System.out.println(m1.sum(21.09f, 20.23f));

	}

}
