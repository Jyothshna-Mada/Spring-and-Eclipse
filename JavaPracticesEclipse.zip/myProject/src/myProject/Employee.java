package myProject;

public class Employee {

	long empSalary=0;
	int empId =2604209;
	
	public void calculateSalary() {
		empSalary=35000;
		System.out.println("My salary is : "+empSalary);
	}
	public static void main(String[] args) {
		
		Employee emp = new Employee();
		long l1=emp.empSalary=44000;
		System.out.println(l1);
		emp.calculateSalary();

	}

}
