package myProject;

class Car{
	public void Driver() {
		System.out.println("cool");
	}
}

class Hyundai extends Car {
	public void getMilage() {
		System.out.println("Good");
	}
}
class Venue extends Hyundai{
	
}
public class ShowRoom {

	public static void main(String[] args) {
//		Hyundai h1 = new Hyundai();
//		h1.Driver();
//		h1.getMilage();
		
		Venue v1 = new Venue();
		v1.getMilage();
		v1.Driver();
	}

}
