package myProject;

import java.util.Scanner;

public class Example {

	public static void main(String[] args) {
		Scanner scn = new Scanner(System.in);
		System.out.println("Enter a string");
		String userInput=scn.nextLine();
		System.out.println("Entered String: "+userInput );

	}

}
