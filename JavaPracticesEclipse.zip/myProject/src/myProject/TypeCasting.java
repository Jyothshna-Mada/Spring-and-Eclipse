package myProject;

public class TypeCasting {

	public static void main(String[] args) {
		int x=2000;
		long x1=x;
		System.out.println(x1);

		long l1=7458726;
		int a=(int) l1;
		System.out.println(a);
		
		float f1=28.6f;
		int b=(int) f1;
		System.out.println(b);
		
		double d1=78.06;
		int c=(int)d1;
		System.out.println(c);
	}

}
