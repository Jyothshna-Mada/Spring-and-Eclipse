package myProject;

public class ConstructorEx {
	int empid;
	String name;
	int score;
	
	
	public ConstructorEx(int empid, String name, int score) {
		super();
		this.empid = empid;
		this.name = name;
		this.score = score;
	}

	public void display() {
		System.out.println("ID: "+empid);
		System.out.println("Name: "+name);
		System.out.println("Score: "+score);
	}

	public static void main(String[] args) {
		ConstructorEx c1 = new ConstructorEx(121,"ramu",32);
		c1.display();
	}

}
