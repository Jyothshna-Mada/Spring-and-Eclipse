package myProject;

public class FirstProgram {

	public static void main(String[] args) {
		//System.out.println("*******This is my first java program ********");
		//System.out.println("******* This is a demo on print *********");
		
		String s1[]= {"Welcome","To","Java"};
		
		for(int i=0;i<s1.length;i++) {
			System.out.println(s1[i]);
		}
		
		}

	}

