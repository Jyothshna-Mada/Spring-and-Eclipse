package myProject;

public class MainProgram {

	public static void main(String[] args) {
		Employee1 emp1 = new Employee1();
		System.out.println("The id of the Employee is : "+emp1.empId);
		System.out.println("The salary of the Employee is : "+emp1.empSalary);
		System.out.println("The percentage of Tax The employee needs to pay is : "+emp1.empTax);
		System.out.println("The total number of working days is : "+emp1.empDaysOfWork);
		
		emp1.calculatePf();

	}

}
