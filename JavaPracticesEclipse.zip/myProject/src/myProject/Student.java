package myProject;

public class Student {
	 public int registrationId=0;
		
		public void displayRegistration() {
			System.out.println("The student registration id is : "+registrationId);
		}
		
}
