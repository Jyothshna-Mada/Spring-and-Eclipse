package myProject;

public class Employee1 {

	long empId =345;
	double empSalary=10000;
	float empTax=9.5f;
	int empDaysOfWork=24;
	
	public void calculatePf() {
		float pfRate=10.5f;
		System.out.println("The pf Rate Of The Employee is : "+pfRate);
	}
}
