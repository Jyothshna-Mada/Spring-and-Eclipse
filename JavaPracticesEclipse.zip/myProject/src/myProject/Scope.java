package myProject;

public class Scope {
	int age;
	
	public void getAge() {
		 age =21;//local variable
		System.out.println("Age is : "+age);
	}
	
	public void getAge2() {
		age=25;
		System.out.println("Age is : "+age);
	}

	public static void main(String[] args) {
		Scope s1 = new Scope();
		s1.getAge();
		s1.getAge2();

	}

}
