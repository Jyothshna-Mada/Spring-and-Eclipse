package myProject;

import java.util.Arrays;

public class Calculator {
	int op1=12;
	int op2=15;
	
	public void displayOperand() {
		int sum = op1+op2;
		System.out.println("The value of operand1 is :"+op1);
		System.out.println("The value of operand2 is :"+op2);
		System.out.println("The sum of two values is :"+sum);
		
	}

}
