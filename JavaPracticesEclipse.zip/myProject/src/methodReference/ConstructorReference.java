package methodReference;

import java.util.function.Function;
import java.util.function.Supplier;

public class ConstructorReference {

	public static void main(String[] args) {
		Function<String, StringBuilder> creator = StringBuilder::new;
		
		StringBuilder builder=creator.apply("hello");
		System.out.println(builder);
		
		Supplier<String> str=String::new;
		String s =str.get();
		System.out.println(s);

	}

}
