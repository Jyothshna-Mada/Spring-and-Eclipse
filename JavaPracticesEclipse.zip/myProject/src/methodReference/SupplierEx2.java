package methodReference;

import java.util.function.Supplier;

public class SupplierEx2 {

	public static void main(String[] args) {
		String str = "Hello world";
		Supplier<Integer> stringlength = str::length;
		Integer length = stringlength.get();
		System.out.println(length);
		
		Supplier<String> upper = str::toUpperCase;
		String u = upper.get();
		System.out.println(u);
		
		

	}

}
