package methodReference;

import java.util.function.Supplier;

public class SupplierEx {
	
	public String instanceMethod(){
		return "hello world";
	}

	public static void main(String[] args) {
		SupplierEx s = new SupplierEx();
		
		Supplier<String> stringSupplier=s::instanceMethod;
		
		String result = stringSupplier.get();
		System.out.println(result);

	}

}
