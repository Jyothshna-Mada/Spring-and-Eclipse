package methodReference;

import java.util.function.Predicate;
import java.util.function.Consumer;

public class PredicateEx {

	public static void main(String[] args) {
		Predicate<String> isEmpty=String::isEmpty;
		
		boolean result1 =isEmpty.test("");
		boolean result2 = isEmpty.test("Hello");
		System.out.println(result1);
		System.out.println(result2);

	}

}
