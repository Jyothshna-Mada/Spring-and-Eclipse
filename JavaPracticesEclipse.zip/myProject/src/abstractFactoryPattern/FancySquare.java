package abstractFactoryPattern;

public class FancySquare implements Square{

	@Override
	public void draw() {
		System.out.println("Drawing a fancy square");
		
	}

}
