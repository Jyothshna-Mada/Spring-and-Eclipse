package abstractFactoryPattern;

public class FancyShapeFactory implements Shapefactory{

	@Override
	public Circle createCircle() {
		return new FancyCircle();
	}

	@Override
	public Square createSquare() {
		return new FancySquare();
	}

}
