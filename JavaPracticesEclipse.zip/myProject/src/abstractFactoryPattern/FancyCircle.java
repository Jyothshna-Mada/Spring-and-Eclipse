package abstractFactoryPattern;

public class FancyCircle implements Circle{

	@Override
	public void draw() {
		System.out.println("Drawing a fancy circle");
	}

}
