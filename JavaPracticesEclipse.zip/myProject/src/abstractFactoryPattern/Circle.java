package abstractFactoryPattern;

public interface Circle {
	void draw();
}
