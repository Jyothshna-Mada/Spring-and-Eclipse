package abstractFactoryPattern;

public class SimpleSquare implements Square{

	@Override
	public void draw() {
		System.out.println("Drawing a simple square");
	}
	
}
