package abstractFactoryPattern;


public class DrawingApp {

	public static void main(String[] args) {
		Shapefactory factory = new SimpleShapeFactory();
		Circle circle = factory.createCircle();
		Square square =factory.createSquare();
		
		circle.draw();
		square.draw();
	}

}
