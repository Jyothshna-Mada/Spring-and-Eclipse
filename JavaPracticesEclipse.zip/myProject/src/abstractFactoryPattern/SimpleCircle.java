package abstractFactoryPattern;

public class SimpleCircle implements Circle{

	@Override
	public void draw() {
	System.out.println("Drawing a simple circle");
	}

}
