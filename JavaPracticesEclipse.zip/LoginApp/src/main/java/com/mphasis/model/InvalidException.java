package com.mphasis.model;

public class InvalidException extends Exception{
	public InvalidException() {
		super();
	}
	public InvalidException(String message) {
		super(message);
	}
}
