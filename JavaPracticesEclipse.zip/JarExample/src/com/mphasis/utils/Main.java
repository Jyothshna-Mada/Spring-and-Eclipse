package com.mphasis.utils;

public class Main {

	public static void main(String[] args) {
		Utils.printMessage();

	}

}
