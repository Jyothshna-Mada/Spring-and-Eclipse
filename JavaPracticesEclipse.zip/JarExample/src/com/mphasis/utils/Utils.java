package com.mphasis.utils;

public class Utils {
	public static void printMessage() {
		System.out.println("Hello from utils");
	}
}
