package com.orm;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class LifeCycle {
	public static void main(String[] args) {
		Configuration cfg = new Configuration().configure("hibernate.cfg.xml");
		SessionFactory factory=cfg.buildSessionFactory();
		
		Employee e1=new Employee();
		
		e1.setId(144);
		e1.setFirstname("Anikha");
		e1.setLastname("Raj");
		
		Session session = factory.openSession();
		Transaction transaction=session.beginTransaction();
		
		//session.save(e1);
		transaction.commit();
		//session.close();
		
		Session session2 = factory.openSession();
		Transaction newTrans=session2.beginTransaction();
		Employee e1updated=(Employee) session2.merge(e1);
		
		e1updated.setLastname("Singh");
		session2.remove(e1updated);
		newTrans.commit();
		session2.close();
		factory.close();
	}

}
