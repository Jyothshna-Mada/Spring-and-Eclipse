package com.mphasis.HQL;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;

public class NamedQuery {

	public static void main(String[] args) {
		SessionFactory factory=new Configuration().configure().addAnnotatedClass(Employeehql.class).buildSessionFactory();
		Session session = factory.openSession();
		session.beginTransaction();
		
	Query<Employeehql> query=session.createNamedQuery("Employee.findBySalary",Employeehql.class);
		query.setParameter("salary", 40000.0);
		
		List<Employeehql> employees =query.getResultList();
		
		employees.forEach(e-> System.out.println(e.getName()));
		
		//session.getTransaction().commit();
		
		session.close();
		factory.close();

	}

}
