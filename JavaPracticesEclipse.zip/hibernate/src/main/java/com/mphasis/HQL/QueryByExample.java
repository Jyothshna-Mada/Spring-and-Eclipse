package com.mphasis.HQL;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;

public class QueryByExample {
	
	public static void main(String[] args) {
		SessionFactory factory=new Configuration().configure().buildSessionFactory();
		Session session = factory.openSession();
		
		String hql ="fROM Employeehql WHERE salary>:salary";
		
		Query<Employeehql> query = session.createQuery(hql,Employeehql.class);
		query.setParameter("salary", 50000.0);
		
		List<Employeehql> employees =query.getResultList();
		
		employees.forEach(e->System.out.println(e.getName()));
		
		session.close();
		factory.close();
	}

}
