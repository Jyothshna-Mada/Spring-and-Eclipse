package com.mphasis.HQL;

import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;


public class Criteria {

	public static void main(String[] args) {
		SessionFactory factory = new Configuration().configure().buildSessionFactory();
		Session session =factory.openSession();
		
		CriteriaBuilder cb = session.getCriteriaBuilder();
		
		CriteriaQuery<Employeehql> cq=cb.createQuery(Employeehql.class);
		
		Root<Employeehql> root = cq.from(Employeehql.class);
		
		cq.select(root).where(cb.lessThanOrEqualTo(root.get("salary"), 40000.0));
		Query<Employeehql> query =session.createQuery(cq);
		
		List<Employeehql> employees=query.getResultList();
		employees.forEach(e->System.out.println(e.getName()));
		
		session.close();
		factory.close();

	}

}
