package com.mphasis.inheritence.single;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

@Entity
@DiscriminatorValue("PART_TIME")
public class PartTimeEmployee extends Employees{

	private double hourlyRate;

	public PartTimeEmployee(long id, String name, double hourlyRate) {
		super(id, name);
		this.hourlyRate = hourlyRate;
	}

	public PartTimeEmployee() {
		super();
	}

	public double getHourlyRate() {
		return hourlyRate;
	}

	public void setHourlyRate(double hourlyRate) {
		this.hourlyRate = hourlyRate;
	}

	
}
