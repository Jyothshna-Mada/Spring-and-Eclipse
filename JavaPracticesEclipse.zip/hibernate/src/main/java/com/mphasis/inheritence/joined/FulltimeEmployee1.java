package com.mphasis.inheritence.joined;

import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name="full_time_Employee")
public class FulltimeEmployee1 extends Employee3{
	
	private double salary;

	public FulltimeEmployee1() {
		super();
		
	}
	
	public FulltimeEmployee1(long id, String name, double salary) {
		super(id, name);
		this.salary = salary;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

}
