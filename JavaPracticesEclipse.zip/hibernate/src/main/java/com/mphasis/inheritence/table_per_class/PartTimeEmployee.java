package com.mphasis.inheritence.table_per_class;

import javax.persistence.Entity;

@Entity
public class PartTimeEmployee extends Employee1{

	private double hourlyRate;

	public PartTimeEmployee(long id, String name, double hourlyRate) {
		super(id, name);
		this.hourlyRate = hourlyRate;
	}

	public PartTimeEmployee() {
		super();
	}

	public double getHourlyRate() {
		return hourlyRate;
	}

	public void setHourlyRate(double hourlyRate) {
		this.hourlyRate = hourlyRate;
	}
}
