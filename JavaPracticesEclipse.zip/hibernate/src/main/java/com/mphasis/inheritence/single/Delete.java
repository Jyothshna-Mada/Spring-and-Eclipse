package com.mphasis.inheritence.single;

import org.hibernate.Session;
import org.hibernate.Transaction;

public class Delete {

	public static void main(String[] args) {
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction transaction=null;
		try {
			transaction=session.beginTransaction();
			
			PartTimeEmployee employee=session.get(PartTimeEmployee.class, 2L);
			if(employee!=null) {
				session.delete(employee);
			}
			transaction.commit();
			
		} catch (Exception e) {
			if(transaction!=null) {
				transaction.rollback();
			}
		}finally {
			session.close();
		}
	}
}
