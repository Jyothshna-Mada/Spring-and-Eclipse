package com.mphasis.inheritence.table_per_class;

import javax.persistence.Entity;

@Entity
public class FullTimeEmployee extends Employee1{
	
	private double salary;

	public FullTimeEmployee() {
		super();
		
	}
	
	public FullTimeEmployee(long id, String name, double salary) {
		super(id, name);
		this.salary = salary;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

}
