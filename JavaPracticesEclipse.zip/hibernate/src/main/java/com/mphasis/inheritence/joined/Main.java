package com.mphasis.inheritence.joined;

import org.hibernate.Session;
import org.hibernate.Transaction;

public class Main {

	public static void main(String[] args) {
		Session session =HibernateUtil.getSessionFactory().openSession();
		Transaction transaction=null;
		try {
			
			transaction=session.beginTransaction();
			
			FulltimeEmployee1 emp=new FulltimeEmployee1(1L,"Lakshmi",60000);
			session.save(emp);
			
			PartTimeEmployee1 employ=new PartTimeEmployee1(2L, "Venkat", 20.00);
			session.save(employ);
			
			transaction.commit();
			
		} catch (Exception e) {
			if(transaction!=null) {
				transaction.rollback();
			}
			e.printStackTrace();
		}finally {
			session.close();
		}
	}
}
