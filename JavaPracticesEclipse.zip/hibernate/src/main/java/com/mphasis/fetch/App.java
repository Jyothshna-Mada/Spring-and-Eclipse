package com.mphasis.fetch;

import java.util.Collection;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class App {

	public static void main(String[] args) {
		 SessionFactory sessionFactory = new Configuration()
	                .configure() 
	                .addAnnotatedClass(Laptop.class)
	                .addAnnotatedClass(Alien.class)
	                .buildSessionFactory();

	        Session session = sessionFactory.openSession();
	        
	        try {
	        	session.beginTransaction();
	        	
	        	Alien alien = new Alien();
	        	alien.setAname("Sapta");
	        	
	        	//session.save(alien);
	        	
	        	Laptop lap1 =new Laptop();
	        	lap1.setBrand("Hp");
	        	lap1.setPrice(120000);
	        	lap1.setAlien(alien);
	        	
	        	Laptop lap2 =new Laptop();
	        	lap1.setBrand("Dell");
	        	lap1.setPrice(150000);
	        	lap1.setAlien(alien);
	        	
//	        	session.save(lap1);
//	        	session.save(lap2);
	        	
	        	session.getTransaction().commit();
	        	
	        	session.beginTransaction();
	        	
	        	Alien fetchalien=session.get(Alien.class, 1);
	        	if(fetchalien!=null) {
	        		System.out.println("Alien Name: "+fetchalien.getAname());
	        	}
	        	
	        	 Collection<Laptop> laps =fetchalien.getLaps();
	              for (Laptop laptop : laps) {
				  System.out.println("Laptop ID: " + laptop.getLid());
				  System.out.println("Laptop Brand: " + laptop.getBrand());
				  System.out.println("Laptop Price: " + laptop.getPrice()); }
	        	
	        	session.getTransaction().commit();
	        	
	        }finally {
				session.close();
				sessionFactory.close();
			}


	}

}
