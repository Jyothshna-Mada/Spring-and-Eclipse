package com.mphasis.orm.bidirectional;

import java.util.Arrays;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class BidirectionalMain {

	public static void main(String[] args) {
		try {
			Configuration cfg = new Configuration().configure("hibernate.cfg.xml");
			SessionFactory factory = cfg.buildSessionFactory();
			Session session =factory.openSession();
			Transaction transaction=session.beginTransaction();
			
			Department department=new Department();
			department.setName("CSE");
			
			Student s1 = new Student();
			s1.setName("Mahika");
			s1.setDepartment(department);
			
			Student s2 = new Student();
			s2.setName("Mahan");
			s2.setDepartment(department);
			
			department.setStudents(Arrays.asList(s1,s2));
			
			session.save(department);
			transaction.commit();
			
			Department retrieve = session.get(Department.class, department.getId());
			System.out.println("Retrieved Department: "+retrieve);
			
			session.close();
			factory.close();
			
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
