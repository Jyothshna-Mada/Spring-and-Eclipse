package com.jobs.register;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class JobSeekerRegistration {
	
	private static final String url = "jdbc:mysql://localhost:3306/jobseekers"; 
	private static final String user = "root";  
	private static final String password = "Admin@123"; 

	public static void main(String[] args) throws ClassNotFoundException {
		Scanner scn = new Scanner(System.in);
		System.out.println("Enter name");
		String name=scn.nextLine();
		
		System.out.println("Enter age");
		int age = scn.nextInt();
		scn.nextLine();
		
		System.out.println("Enter Qualification");
		String qualification=scn.nextLine();
		
		System.out.println("Enter Experience in years");
		int exp = scn.nextInt();
		scn.nextLine();
		
		System.out.println("Enter Domain of Expertiseee");
		String doe = scn.nextLine();
		
		System.out.println("Enter salary expected");
		double salary=scn.nextDouble();
		
		try {
			saveJobSeeker(name, age, qualification, exp, doe, salary);
		}catch (SQLException e) {
			System.out.println("Error saving details");
			e.printStackTrace();
		}
		System.out.println("Details Saved Successfully");
		
		scn.close();
	}
	public static void saveJobSeeker(String name,int age,String qualification,int exp,String domainOfExp,double salary) throws SQLException, ClassNotFoundException {
		Connection con =null;
		PreparedStatement ps = null;
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con=DriverManager.getConnection(url,user,password);
			String sql="insert into user values(?,?,?,?,?,?)";
			ps=con.prepareStatement(sql);
			ps.setString(1, name);
			ps.setInt(2, age); 
			ps.setString(3, qualification); 
			ps.setInt(4, exp); 
			ps.setString(5, domainOfExp); 
			ps.setDouble(6, salary); 
			 
			ps.executeUpdate(); 

			
		}
		finally {
			if(ps!=null) {
				ps.close();
			}
			if(con!=null)
			{
				con.close();
			}
		}
	}

}
