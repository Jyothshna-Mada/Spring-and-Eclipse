package com.mphasis.mvc;

public class RegistrationException extends Exception {
	private static final long serialVersionUID = 1L;

	public RegistrationException() {
		super();
	}
	
	public RegistrationException(String message) {
		super(message);
	}

}
