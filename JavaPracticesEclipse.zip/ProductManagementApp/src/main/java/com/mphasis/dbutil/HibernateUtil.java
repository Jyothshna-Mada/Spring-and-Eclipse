package com.mphasis.dbutil;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;

import com.mphasis.domain.Product;

public class HibernateUtil {
	 SessionFactory factory;
	 Session session;
	
		public Session getConfiguration() {
			try {
				 Configuration cfg = new Configuration();
		            cfg.setProperty("hibernate.connection.driver_class", "com.mysql.cj.jdbc.Driver");
		            cfg.setProperty("hibernate.connection.url", "jdbc:mysql://localhost:3306/productdb");
		            cfg.setProperty("hibernate.connection.username", "root");
		            cfg.setProperty("hibernate.connection.password", "Admin@123");
		            cfg.setProperty("hibernate.dialect", "org.hibernate.dialect.MySQL8Dialect");
		            cfg.setProperty("hibernate.show_sql", "true");
		            cfg.setProperty("hibernate.hbm2ddl.auto", "update");
		            cfg.setProperty("hibernate.format_sql", "true");

		            cfg.addAnnotatedClass(Product.class); 
		            
		            ServiceRegistry serviceRegistry = new StandardServiceRegistryBuilder()
		            		.applySettings(cfg.getProperties()).build();
		             factory = cfg.buildSessionFactory(serviceRegistry);

		            session = factory.openSession();

		            return session;
			}catch (Exception e) {
				e.printStackTrace();
			}
			return null;
		}
		
		public void closeconnection() {
			session.close();
			factory.close();
		}
	}
