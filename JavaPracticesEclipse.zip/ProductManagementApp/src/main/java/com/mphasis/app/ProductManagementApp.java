package com.mphasis.app;

import java.util.Scanner;

import com.mphasis.dao.ProductManagementDAO;
import com.mphasis.domain.Product;

public class ProductManagementApp {
	static	ProductManagementDAO dao=new ProductManagementDAO();
	
	public static void main(String[] args) {
		boolean exit=false;
		
		while(!exit) {
			System.out.println(" A. View Products \n B. Add Product"
					+ "\n C. Update Product \n D. Delete Product \n E.Search Prodyct"
					+ "\n F.Exit");
			System.out.println("================================");
			System.out.println("Enter an Option");
			System.out.println("================================");
			Scanner scn = new Scanner(System.in);
			String option=scn.next().toUpperCase();
			
			switch(option) {
				case "A":{
					dao.viewProduct();
					break;
				}
				case "B":{
					dao.addProduct(scn);
					break;
				}
				case "C":{
					dao.updateProduct(scn);
					break;
				}
				case "D":{
					dao.DeleteProduct(scn);
					break;
				}
				case "E":{
					Product pro= dao.SearchProduct(scn);
					System.out.println(pro);
					break;
				}
				case "F":{
					System.out.println("Exiting...");
					exit=true;
					break;
				}
				default:{
					System.out.println("Invalid Option");
				}
			}
		}
	}
}
