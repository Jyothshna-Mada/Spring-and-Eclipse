package day_6;

import java.util.Random;

public class Register <T extends User>{
	
	public void display(T user) {
		user.display();
	}
	
	public static String generateRegisterId(int n) {
		String ch="ABCDEFGHIJKLMNOPQRSTUWXYZ0123456789";
		Random random = new Random();
		
		StringBuilder s = new StringBuilder(n);
		
		for(int i=0;i<n;i++) {
			s.append(ch.charAt(random.nextInt(ch.length())));
		}
		return s.toString();
		
		
	}
}
