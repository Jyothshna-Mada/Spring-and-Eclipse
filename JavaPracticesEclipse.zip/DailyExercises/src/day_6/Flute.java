package day_6;

public class Flute {
	
	public static void main(String[] args) {
		Instrument i2 =()->
		System.out.println("Flute is playing toot toot toot");
		
		i2.play();
	}
}
