package day_6;

public class Guitar {

	public static void main(String[] args) {
		Instrument i3 =()-> 
		System.out.println("Guitar is playing tring tring tring");
		
		i3.play();
	}
}
