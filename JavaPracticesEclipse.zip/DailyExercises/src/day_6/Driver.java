package day_6;

import java.util.Scanner;

public class Driver {

	public static void main(String[] args) {
		Scanner scn = new Scanner(System.in);
		long[] phnum= {76387423L,376473265L};
		Employee e1 = new Employee("Sandeep", phnum, "HT5624TP36", 857237);
		e1.display();
		
		long[] phnum1 = {6352765L,7362786L};
		Employee e2 = new Employee("priya", phnum1, 38624836, 434428, 3468);
		e2.display();
		
		long[] phnum2 = {64573283L,736487136L};
		Student s1 = new Student("hinduja", phnum2, 3764716, "HY736478G");
		s1.display();

	}

}
