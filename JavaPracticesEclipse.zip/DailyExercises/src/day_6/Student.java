package day_6;

public class Student extends User{
	

	public Student(String name, long[] phoneNo, Integer licenceNo, Integer voterId) {
		super(name, phoneNo, licenceNo, voterId);
	}
 
	public Student(String name, long[] phoneNo, Integer licenceNo, String panCardNo) {
		super(name, phoneNo, licenceNo, panCardNo);
	}
 
	public Student(String name, long[] phoneNo, String passportNo) {
		super(name, phoneNo, passportNo);
	}
 
 
	@Override
	public void display() {
		System.out.println("==========Details of the Student==========");
		System.out.println("Hurray!! you availed a discount of 22%");
		System.out.println("Registered Id  : "+Register.generateRegisterId(10));
		System.out.println("Name : "+name);
		System.out.println("Phone No's : [ "+phoneNo[0]+" , "+phoneNo[1]+" ]");
		
		if (passportNo!=null) {
			System.out.println("Passport No : "+passportNo);
		}else {
			if(licenceNo!=null) {
			System.out.println("licence No : "+licenceNo);
			}
			if (voterId!=null) {
				System.out.println("Voter Id : "+voterId);
			}
			
			if (panCardNo!=null) {
				System.out.println("Pan No : "+panCardNo);
			}
		}
		
	}
	
	
 
}
 
