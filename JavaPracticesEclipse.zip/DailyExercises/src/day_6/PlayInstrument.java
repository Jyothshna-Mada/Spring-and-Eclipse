package day_6;

public class PlayInstrument {

	public static void main(String[] args) {
		
		Instrument [] instrument= new Instrument[10];
		instrument[0]=()->System.out.println("Piano is playing tan tan tan");
		instrument[1]=()->System.out.println("Guitar is playing tring tring tring");
		instrument[2]=()->System.out.println("Flute is playing toot toot toot");
		instrument[3]=()->System.out.println("Piano is playing tan tan tan");
		instrument[4]=()->System.out.println("Guitar is playing tring tring tring");
		instrument[5]=()->System.out.println("Flute is playing toot toot toot");
		instrument[6]=()->System.out.println("Piano is playing tan tan tan");
		instrument[7]=()->System.out.println("Guitar is playing tring tring tring");
		instrument[8]=()->System.out.println("Flute is playing toot toot toot");
		instrument[9]=()->System.out.println("Piano is playing tan tan tan");
		
		for(Instrument in:instrument) {
			in.play();
		}
		
		for(int i=0;i<instrument.length;i++) {
			if(instrument[i] instanceof Instrument) {
				System.out.println("The index"+i +" is an instance of Instrument");
            } else {
                System.out.println("Not instance of Instrument");
            }
			
		}
		
	}

}

