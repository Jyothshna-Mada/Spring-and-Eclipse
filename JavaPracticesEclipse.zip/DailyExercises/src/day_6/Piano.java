package day_6;

public class Piano{
	
	public static void main(String[] args) {
		Instrument i1=()->
		System.out.println("Piano is playing tan tan tan");
		
		i1.play();
	}
}
