package day_6;

@FunctionalInterface
public interface Instrument {
	void play();

}
