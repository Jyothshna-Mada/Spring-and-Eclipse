package day_11;

public class Driver extends Thread{
	Print print;
	String s;
	
	public Driver(Print print, String s) {
		this.print=print;
		this.s=s;
	}
	public void run() {
		print.p(s);
		
	}

}
