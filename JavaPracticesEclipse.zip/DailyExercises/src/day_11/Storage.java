package day_11;

public class Storage {
	private int num;
	 
	public synchronized int getNum() {
		return num;
	}
 
	public synchronized void setNum(int num) {
		this.num = num;
	}
}
