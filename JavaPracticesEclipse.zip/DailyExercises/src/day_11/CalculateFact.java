package day_11;

public class CalculateFact extends Thread{

	private TransferData transferData;

	public CalculateFact(TransferData transferData) {
		this.transferData = transferData;
	}
	@Override
	public void run() {
		try {
			while(true) {
				int number=transferData.getNumber();
				if(transferData.isEndOfFile() && number == -2) break;
				if(number!=-2) {
					long factorial=calculateFactorial(number);
					System.out.println("Factorial of "+number + " is "+ factorial);
					Thread.sleep((int)(Math.random()*1000));
				}
			}
		}catch(InterruptedException e) {
			e.printStackTrace();
		}
	}
	
	private long calculateFactorial(int number) {
		long result=1;
		for(int i=1;i<=number;i++) {
			result*=i;
		}
		return result;
	}
	
}
