package day_11;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class ReadFile extends Thread{

	private String filename;
	private TransferData transferData;
	
	public ReadFile(String filename, TransferData transferData) {
		this.filename = filename;
		this.transferData = transferData;
	}
	@Override
	public void run() {
		try(BufferedReader br = new BufferedReader(new FileReader(filename))){
			String line;
			while((line=br.readLine())!=null) {
				int number=Integer.parseInt(line);
				System.out.println("reading from "+filename +": "+number);
				transferData.setNumber(number);
				Thread.sleep((int)(Math.random()*1000));
			}
				transferData.setEndOfFile();
			}catch(IOException |InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
	
	

