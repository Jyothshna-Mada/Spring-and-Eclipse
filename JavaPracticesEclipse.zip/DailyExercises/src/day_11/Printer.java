package day_11;

public class Printer extends Thread{
public Storage s;
	
	public Printer(Storage s) {
		this.s=s;
	}
	
	public void run() {
		for (int i=1;i<=20;i++) {
			int num1 = s.getNum();
			System.out.println("values: "+num1);
		
			try {
				Thread.sleep(100);
			} catch (InterruptedException e) {
				
			}
		}
	}

}
