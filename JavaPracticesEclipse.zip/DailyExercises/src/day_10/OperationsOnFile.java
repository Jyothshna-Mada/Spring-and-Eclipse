package day_10;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;

public class OperationsOnFile {
	
	public static void insertStringintoFile(String path,String msg) {
		try(FileOutputStream fos = new FileOutputStream(path,true)){
			fos.write(msg.getBytes());
			System.out.println("Success");
		}catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public static String ExtractFileContent(String path) {
		String s2="";
		try(FileReader fis =new FileReader(path)){
			BufferedReader b = new BufferedReader(fis);
			String s =b.readLine();
			while(s!=null) {
				s2+=s;
				s=b.readLine();
			}
		}catch(IOException e) {
			e.printStackTrace();
		}
		return s2;
	}
	
	public static int showSize(String path) {
		int size=0;
		
		try(FileInputStream fis = new FileInputStream(path)){
			size=fis.available();
		}catch (IOException e) {
			e.printStackTrace();
		}
		return size;
	}
	
	public static void deleteContent(String path) {
		File file = new File(path);
		if(file.delete()) 
			System.out.println("File deleted Successfully");
		else 
			System.out.println("Failed to delete");
	}

}
