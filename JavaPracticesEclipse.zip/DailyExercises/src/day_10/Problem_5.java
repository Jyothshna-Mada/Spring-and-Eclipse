package day_10;

import java.io.IOException;
import java.util.Scanner;

public class Problem_5 {

	public static void main(String[] args) throws IOException {
		Scanner scn = new Scanner(System.in);
	
		String path="c://mp//io.txt";
		int n=4;
		
		while(n<=4) {
			
			System.out.println("1.Insert String \n2.Show Size \n3.Extract content \n4.Delete content \n5.Exit");
			
			System.out.println("Enter Your choice");
			int choice=scn.nextInt();
			switch(choice) {
			case 1:
				System.out.println("Enter String to insert");
				scn.nextLine();
				String msg= scn.nextLine();
				OperationsOnFile.insertStringintoFile(path,msg);
				break;
			case 2:
				int size=OperationsOnFile.showSize(path);
				System.out.println("Size of the file is: "+size);
				break;
			case 3:
				String msgs=OperationsOnFile.ExtractFileContent(path);
				System.out.println(msgs);
				break;
			case 4:
				OperationsOnFile.deleteContent(path);
				break;
			case 5:
				n=5;
				break;
			default:
				System.out.println("Invalid choice");
			}
		}
		
		
	}

}
