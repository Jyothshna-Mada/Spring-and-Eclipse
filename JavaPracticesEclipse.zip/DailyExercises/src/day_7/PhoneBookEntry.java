package day_7;

import java.util.HashMap;
import java.util.Scanner;

public class PhoneBookEntry {
	static HashMap<String, Long> p = new HashMap<String, Long>();
 
	public static void main(String[] args) {
		Scanner scn = new Scanner(System.in);
		while (true) {
			System.out.println("Phone Book Menu");
			System.out.println("1. Add new phone entry");
			System.out.println("2. Search for an entry");
			System.out.println("3. Exit");
			int ch= scn.nextInt();
			switch (ch) {
			case 1: {
				addNewEntry(scn);
				break;
			}
			case 2:{
				searchEntry(scn);
				break;
			}
			case 3:{
				System.out.println("Thank you for using phone book... "
						+ "closing");
				return;
			}
			default:
				System.out.println("Invalid choice");
			}
		}
 
	}
 
	
	public static void addNewEntry(Scanner scn) {
		System.out.println("Enter Name: ");
		String name= scn.nextLine();
		scn.nextLine();
		System.out.println("Enter Phone Number: ");
		long num = scn.nextLong();
		p.put(name, num);
		System.out.println("Added Successfully");
	}
	public static void searchEntry(Scanner scn) {
		System.out.println("Enter name to search ");
		String name = scn.nextLine();
		scn.nextLine();
		if (p.containsKey(name)) {
			System.out.println("Phone Number of "+name+ " is "+p.get(name));
		}else {
			System.out.println("No Entry with name "+name);
		}
	}
}


