package day_7;

import java.util.Objects;

public class Person implements Comparable<Person> {
	
	private int id;
	private String name;
	private int age;
	private double salary;
	
	public int getId() {
		return id;
	}
	
	public String getName() {
		return name;
	}
	
	public int getAge() {
		return age;
	}
	
	public double getSalary() {
		return salary;
	}
	
	public Person(int id, String name, int age, double salary) {
		
		this.id = id;
		this.name = name;
		this.age = age;
		this.salary = salary;
	}

	@Override
	public String toString() {
		return "Person [id=" + id + ", name=" + name + ", age=" + age + ", salary=" + salary + "]";
	}
	
	
	public int compareTo(Person other) {
		return Integer.compare(this.id,other.id);
	}
	
	public int hashCode() {
		return Objects.hash(id,name,age,salary);
	}

	

}
