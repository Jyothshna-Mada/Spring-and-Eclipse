package day_7;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class ListOfStudents {

	public static void main(String[] args) {
		List<String> students = new ArrayList<String>();
		students.add("Varma");
		students.add("Sushma");
		students.add("Pavan");
		students.add("Anikha");
		students.add("Chan");
		students.add("Ragini");
		students.add("Sharma");
		students.add("Pratap");
		
		
		Scanner scn = new Scanner(System.in);
		System.out.println("Enter name");
		String name=scn.next();
		
		boolean s = students.contains(name);
		
		if(s) {
			System.out.println(name+" is a Student");
		}else System.out.println(name+" is not a student");

	}

}
