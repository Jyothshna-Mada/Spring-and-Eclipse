package day_7;

import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;
import java.util.Scanner;

public class EmployeeMain {

	public static void main(String[] args) {
		List<Employee> l = new LinkedList<>();
		addInput(l);
		displayForward(l);
		displayReverse(l);

	}
	
	public static void addInput(List<Employee> e) {
		Scanner scn=new Scanner(System.in);
		System.out.println("Enter your Employee number :");
		int id = scn.nextInt();
		scn.nextLine();
		System.out.println("Enter your Name: ");
		String name =scn.nextLine();
		
		System.out.println("Enter your Address: ");
		String address = scn.nextLine();
		e.add(new Employee(id,name,address));
	}
	
	public static void displayReverse(List<Employee> e) {
		ListIterator<Employee> iterator = e.listIterator(e.size());
		while(iterator.hasPrevious()) {
			System.out.println(iterator.previous());
		}
		
	}
	
	public static void displayForward(List<Employee> s) {
		ListIterator<Employee> m = s.listIterator();
		while(m.hasNext())
			System.out.println(m.next());
	}
}
