package day_7;

import java.util.Arrays;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.OptionalDouble;
import java.util.Set;
import java.util.stream.Collectors;


public class PersonMain {

	public static void main(String[] args) {
		Set<Person> s = new HashSet<>(
				Arrays.asList(new Person(1, "Jerry", 12, 999.0),
				new Person(2, "Smith", 22, 2999.0),
				new Person(3, "Popeye", 21, 5999.0),
				new Person(4, "Jones", 22, 6999.0),
				new Person(5, "John", 32, 1999.0),
				new Person(6, "Tom", 42, 3999.0)));
		boolean result=s.stream().noneMatch(person->person.getAge()>50);
		System.out.println(result);
		
	}

}


