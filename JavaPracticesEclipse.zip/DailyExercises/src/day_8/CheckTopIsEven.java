package day_8;

import java.util.Stack;

public class CheckTopIsEven {

	public static void main(String[] args) {
		Stack<Integer> s = new Stack<Integer>();

		s.push(15);
		s.push(25);
		s.push(30);
		s.push(40);
		
		if(s.peek()%2==0) {
			System.out.println("true");
		}else System.out.println("false");

	}

}
