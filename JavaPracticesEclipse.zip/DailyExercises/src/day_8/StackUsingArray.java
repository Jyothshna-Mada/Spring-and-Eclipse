package day_8;

public class StackUsingArray {
	private String[] stack;
	private int capacity;
	private int top;
	
	public StackUsingArray(int size) {
		stack = new String[size];
		capacity = size;
		top=-1;
	}
	
	public boolean isEmpty()
	{
		return top==-1;
	}
	
	public boolean isFull()
	{
		return top==capacity-1;
	}
	
	public String pop() {
		if(isEmpty()) {
			System.out.println("Stack Under Flow");
			return null;
		}
		return stack[top--];
	}
	
	public void push(String element) {
		if(isFull()) {
			System.out.println("Stack Over Flow");
			return;
		}
		stack[++top]=element;
	}
	
	public int size() {
		return top+1;
	}
	
	public void printStack() {
		if(isEmpty()) {
			System.out.println("Stack is Empty");
			return;
		}
		for(int i=0;i<=top;i++) {
			System.out.print(stack[i]+" ");
		}
		System.out.println();
	}

}
