package day_8;

import java.util.Stack;

public class ReverseStack {

	public static void main(String[] args) {
		Stack<String> s = new Stack<String>();
		String s2 = s.push("JavaQuiz");
		System.out.println(s2);
		//String s3=reverse(s2);
		System.out.println(reverse(s2));
	}
	
	public static String reverse(String s) {
	Stack<Character> s1 = new Stack<>();
		for(char c:s.toCharArray()) {
			s1.push(c);
		}
			String s2="";
			while(!s1.isEmpty()) 
				s2+=s1.pop();
			
		return s2;

	}
}
