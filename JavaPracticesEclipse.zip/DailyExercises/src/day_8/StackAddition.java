package day_8;

import java.util.Stack;

public class StackAddition {

	public static void main(String[] args) {
		String exp="10+2*6";
		System.out.println(operate(exp));

	}
	public static int operate(String exp) {
		Stack<Integer> operands=new Stack<>();
		Stack<Character> operators =new Stack<>();
		for (int i = 0; i < exp.length(); i++) {
			char ch=exp.charAt(i);
			if(Character.isWhitespace(ch)) {
				continue;
			}
			if(Character.isDigit(ch)) {
				int num=0;
				while(i<exp.length() && Character.isDigit(exp.charAt(i))) {
					num=num*10+(exp.charAt(i)-'0');
					i++;
				}
				i--;
				operands.push(num);	
			}else if(ch=='(') {
				operators.push(ch);
			}else if(ch==')') {
				while(operators.peek()!='(') {
					operands.push(apply(operators.pop(), operands.pop(), operands.pop()));
				}
				operators.pop();
			}else if(isOperator(ch)) {
				while(!operators.isEmpty() && precedence(ch)<=precedence(operators.peek())) {
					operands.push(apply(operators.pop(), operands.pop(), operands.pop()));
				}
				operators.push(ch);
			}
		}
		while(!operators.isEmpty()) {
			operands.push(apply(operators.pop(), operands.pop(), operands.pop()));
		}
		return operands.pop();
		
	}
	
	public static boolean isOperator(char ch) {
		return ch=='+'||ch=='-'||ch=='*'||ch=='/';
	}
	
	public static int precedence(char ch) {
		switch(ch) {
		case '+':
		case '-':
			return 1;
		case '*':
		case '/':
			return 2;
		}
		return -1;
	}
	
	public static int apply(char op,int b,int a) {
		switch(op) {
		case '+':
			return a+b;
		case '-':
			return a-b;
		case '*':
			return a*b;
		case '/':
			if(b==0) {
				throw new IllegalArgumentException("Can not divide with zero");
			}
			return a/b;
		}
		return 0;
	}

}
