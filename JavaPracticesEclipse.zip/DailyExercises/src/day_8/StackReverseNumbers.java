package day_8;

import java.util.Stack;

public class StackReverseNumbers {

	public static void main(String[] args) {
		Stack<Integer> i = new Stack<Integer>();
		i.push(1);
		i.push(2);
		i.push(3);
		i.push(4);
		reverse(i,i.size(),0);
		
	}
	public static void reverse(Stack<Integer> s,int size,int num) {
		if(num>=size)
			return;
		System.out.println(s.pop());
		num++;
		reverse(s,size,num);
	}

}
