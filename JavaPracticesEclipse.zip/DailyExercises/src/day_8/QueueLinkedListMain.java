package day_8;

public class QueueLinkedListMain {

	public static void main(String[] args) {
		QueueLinkedList q = new QueueLinkedList();
		q.enqueue(88);
		q.enqueue(99);
		q.enqueue(109);
		q.enqueue(209);
		q.enqueue(309);
		
		q.dequeue();
		q.dequeue();
		
		while(q.size()>0) {
			System.out.println(q.dequeue());
		}

	}

}
