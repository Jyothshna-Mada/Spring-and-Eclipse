package day_8;

public class QueueLinkedList {
	private Node front;
	private Node rear;
	static int count;
	
	public QueueLinkedList() {
		this.front=null;
		this.rear=null;
	}
	
	public void enqueue(int element) {
		Node node = new Node(element);
		if(rear==null) {
			front =node;
		rear=node;
		}
		else {
			rear.next=node;
			rear=node;
		}
		count++;
	}
	
	public int dequeue() {
		if(isEmpty()) {
			System.out.println("Queue is empty");
			return -1;
		}
		int ele = (int) front.element;
		front=front.next;
		if(front==null) {
			rear=null;
		}
		count--;
		return ele;
	}
	
	public boolean isEmpty() {
		return front==null;
	}
	
	public int size() {
		return count;
	}

}
