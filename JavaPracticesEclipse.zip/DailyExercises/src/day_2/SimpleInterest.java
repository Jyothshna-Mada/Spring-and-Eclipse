package day_2;

import java.util.Scanner;

public class SimpleInterest {

	public static void main(String[] args) {
		Scanner scn = new Scanner(System.in);
		System.out.println("Enter principle ");
		double p=scn.nextDouble();
		System.out.println("Enter Time ");
		int t = scn.nextInt();
		System.out.println("Enter RateOfIntrest");
		double r = scn.nextDouble();
		
		double simpleIntrest=(p*t*r)/100;
		System.out.println("Simple Intrest "+simpleIntrest);
	}

}
