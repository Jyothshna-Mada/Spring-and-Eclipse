package day_2;

import java.util.Scanner;

public class AddNumWthSwitch {

	public static void main(String[] args) {
		Scanner scn = new Scanner(System.in);
		System.out.println("Enter two numbers: ");
		int n1 = scn.nextInt();
		int n2 = scn.nextInt();
		System.out.println("Enter an operator like +,-,*,/,%");
		char ch = scn.next().charAt(0);
		
		switch(ch) {
		case '+':
			System.out.println(n1+" + "+n2+" = "+(n1+n2));
			break;
		case '-':
			System.out.println(n1+" - "+n2+" = "+(n1-n2));
			break;
		case '*':
			System.out.println(n1+" * "+n2+" = "+(n1*n2));
			break;
		case '/':
			System.out.println(n1+" / "+n2+" = "+(n1/n2));
			break;
		case '%':
			System.out.println(n1+" % "+n2+" = "+(n1%n2));
			break;
		}

	}

}
