package day_2;

import java.util.Scanner;

public class CompoundInterest {

	public static void main(String[] args) {
		Scanner scn = new Scanner(System.in);
		System.out.println("Enter principle ");
		double p=scn.nextDouble();
		System.out.println("Enter Time ");
		int t = scn.nextInt();
		System.out.println("Enter RateOfIntrest");
		double r = scn.nextDouble();
		
		double compoundIntrest = p*(Math.pow((1+r/100), t));
		
		System.out.println("Compound Intreset is: "+compoundIntrest);
	}

}
