package day_2;

import java.util.Scanner;

public class UpperStar {

	public static void main(String[] args) {
		Scanner scn = new Scanner(System.in);
		System.out.println("Enter a number");
		int num = scn.nextInt();
		
		for(int i=1;i<=num;i++) {
			for(int j=num;j>=1;j--) {
				if(i>=j) {
				System.out.print("*");
				}
				else {
					System.out.print(" ");
				}
			}
			System.out.println(" ");
		}
	}

}
