package day_2;

import java.util.Scanner;

public class EvenOrOdd {

	public static void main(String[] args) {
		Scanner scn = new Scanner(System.in);
		System.out.println("Enter n value");
		int n = scn.nextInt();
		
		if(n%2==0)
		{
			System.out.println("The number "+n+" is Even");
		}
		else
			System.out.println("The number "+n+" is Odd");	
	}

}
