package day_3;

public class Syrup implements MedicalInfo{

	@Override
	public void displayLabel() {
		System.out.println("Company Name:Anuj-B");
		System.out.println("Company Address:Bhaje Building sector 3,Ahmedabad,gujarat");
		System.out.println("Use as prescribed by the doctor");
		
	}

}
