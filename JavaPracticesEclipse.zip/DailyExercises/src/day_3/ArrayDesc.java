package day_3;

public class ArrayDesc {

	public static void main(String[] args) {
		int []nums= {2,6,23,98,24,35,78};
		Sort(nums);
		for(int i=nums.length-1;i>=0;i--) {
			System.out.println(nums[i]);
		}
	}
		public static void Sort(int[]nums) {
		for(int i=0;i<nums.length-1;i++) {
			for(int j=1;j<nums.length-1-i;j++) {
				if(nums[j]>nums[j+1]) {
					int temp=nums[j];
					nums[j]=nums[j+1];
					nums[j+1]=temp;
				}
			}
		}
		}

}
