package day_3;

public class Panagram {

	public static void main(String[] args) {
		String s="a quick brown fox jumps over the lazy dog";
		String v =s.toLowerCase();
		char[] a=v.toCharArray();
		String temp="abcdefghijklmnopqrstuvwxyz";
		char[]b=v.toCharArray();
		
		for(int i=0;i<a.length;i++) {
			for(int j=0;j<b.length;j++) {
				char c1=b[j];
				if(a[i]==b[j]) {
					temp=temp.replace(c1+"", "");
				}
			}
		}
		if(temp=="")
		{
			System.out.println("Yes");
		}
		else
			System.out.println("No");
		
	}

}
