package day_3;

import java.util.Scanner;

public class BillBankValidation {

	public static void main(String[] args) {
		Scanner scn = new Scanner(System.in);
		System.out.println("Enter card number");
		String number=scn.next();
		System.out.println("Enter expiry date");
		String expiry = scn.next();
		System.out.println("Enter cvv code");
		String cvv = scn.next();
		System.out.println("enter your name");
		String name=scn.next();
		displayDetails(number,expiry,cvv,name);
	
	}

	public static void displayDetails(String number,String expiry,String cvv,String name) {
//		if(number.length()!=19) {
//			System.out.println("Card number should be of 16 characters length");
//			return ;
//		}
		
		String card_number=" ";
		
		for(int i=0;i<number.length();i++) {
			if(i==4||i==9||i==14)
				card_number+="-";
			else
				card_number+=number.charAt(i);
		}
		if(cvv.length()!=3) {
			System.out.println("Your cvv number should be 3 characters length");
			return;
		}
		String expiryDate=expiry.charAt(0)+expiry.charAt(1)+"/"+expiry.charAt(2)+expiry.charAt(3);
		System.out.println("Name : "+name);
		System.out.println("CardNumber: "+card_number);
		System.out.println("EpiryDate : "+expiryDate);
	}
	
	
}
