package day_3;

public class Sort2DArray {

	public static void main(String[] args) {
		int [][] values= {
				{39,27,11,42},
				{10,93,91,90},
				{54,78,56,65},
				{24,64,20,65}
		};
		int len = values.length;
		int [][] result=new int[len][len];

		for(int i=0;i<values.length;i++) {
			for(int j=0;j<values.length;j++) {
				if(i==0||i==2) {
					result[i][j]=values[i][j];
				}
				else if(i==1)
					result[i][j]=values[i+2][j];
				else
					result[i][j]=values[i-2][j];
			}
		}
		
		for(int []row:result) {
			for(int num:row) {
				System.out.print(num+" \t");
			}
			System.out.println(" ");
		}
		
	}

}
