package day_3;

public class UniqueNumFromArray {

	public static void main(String[] args) {
		int a[] = {2,2,2,2,2,2};
		int n=a.length;
		int newlen=removeDuplicates(a, n);
		
		for(int i=0;i<newlen;i++) {
			System.out.println(a[i]+" ");
		}

	}
	
	public static int removeDuplicates(int[] arr,int n) {
		if(n==0||n==1)
			return n;
		int j=0;
		
		for(int i=0;i<n-1;i++) {
			if(arr[i]!=arr[i+1]) {
				arr[j++]=arr[i];
			}
		}
		arr[j++]=arr[n-1];
		return j;
	}

}
