package day_3;

public class Transpose {

	public static void main(String[] args) {
		int[][] num= {{1,2,3},{4,5,6},{7,8,9}};
		int len = num.length;
		int[][] num1=new int[len][len];
		for(int i=0;i<len;i++) {
			for(int j=0;j<len;j++) {
				num1[j][i]=num[i][j];
			}
		}
		for(int[] row:num1) {
			for(int n:row) {
				System.out.print(n+"\t");
			}
			System.out.println();
		}
	}

}
