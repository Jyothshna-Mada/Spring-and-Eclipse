package day_3;

public class DiagonalSumOfArray {

	public static void main(String[] args) {
		int[][] num= {{6,7,3,4},{8,9,2,1},{1,2,9,6},{6,5,7,2}};
		int principleDiagonal=0;
		int SecondaryDiagonal=0;
		
		for(int i=0;i<num.length;i++) {
			for(int j=0;j<num.length;j++) {
				if(i==j) {
					principleDiagonal+=num[i][j];
				}
				if((i+j)==3) {
					SecondaryDiagonal+=num[i][j];
				}
			}
		}
		
		System.out.println("The principle Diagonal of a given 2D array is: "+principleDiagonal);
		System.out.println("The Secondary Diagonal of a given 2D array is: "+SecondaryDiagonal);

	}

}
