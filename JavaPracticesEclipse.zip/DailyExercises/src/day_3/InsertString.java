package day_3;

public class InsertString {

	public static void main(String[] args) {
		StringBuffer s1 = new StringBuffer("Computer Portal");
		int index=8;
		String stringToBeInserted=" Science";
		s1.insert(index, stringToBeInserted);
		
		System.out.println(s1);

	}

}
