package day_3;

public class HallowArray {

	public static void main(String[] args) {
		String [][] values= {{"1","2","3","4"},
				{"4","5","6","5"},
				{"7","8","9","1"},
				{"6","5","3","9"}
		};
		int len = values.length;
		String [][]result=new String [len][len];

		for(int i=0;i<len;i++) {
			for(int j=0;j<len;j++) {
				if(i==0||i==len-1||j==0||j==len-1) {
					result[i][j]=values[i][j];
				}else
					result[i][j]=" ";
			}
		}
		
		for(String[] row:result) {
			for(String num:row) {
				System.out.print(num+"\t");
			}
			System.out.println(" ");
		}
	}

}
