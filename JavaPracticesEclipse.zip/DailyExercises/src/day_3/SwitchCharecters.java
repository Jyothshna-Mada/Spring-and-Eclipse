package day_3;

public class SwitchCharecters {

	public static void main(String[] args) {
		String s1 = "Testing";
			System.out.println(swap(s1));
		

	}
	
	public static String swap(String s) {
		if(s==null||s.isEmpty())
			return s;
		
		char []c = s.toCharArray();
		for(int i=0;i<c.length-1;i+=2) {
			char temp=c[i];
			c[i]=c[i+1];
			c[i+1]=temp;
		}
		return new String(c);
	}

}
