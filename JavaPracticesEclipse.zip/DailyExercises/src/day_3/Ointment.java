package day_3;

public  class Ointment implements MedicalInfo{

	@Override
	public void displayLabel() {
		System.out.println("Company Name:Avion");
		System.out.println("Company Address: Nefro building sector 1,floor4,chandigarh");
		System.out.println("For external use only");
		
	}

}
