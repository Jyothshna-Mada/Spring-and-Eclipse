package day_3;

public class RemoveDuplicate {

	public static void main(String[] args) {
		int [] num = {1,2,2,3,4,4,4,5,5};
		int [] result=unique(num);
		for(int value:result) {
			System.out.println(value);
		}

	}

	public static int[] unique(int[] nums) {
		for(int i=0;i<nums.length-1;i++) {
			int [] uniValues= {};
			int n=nums[i];
			for(int j=1,k=0;j<nums.length-1-i;j++) {
				if(nums[j]==0)
					continue;
				if(n==nums[j]) {
					nums[j]=0;
				}
				if(n!=0) {
				uniValues[k++]=n;
				}else continue;
			}
			
		}
		return null;
	}
//	public static int[] remove(int [] nums,int index) {
//		if(nums==null || index<0 ||index>=nums.length) {
//			return nums;
//		}
//		int [] a =new int [nums.length-1]; 
//		for(int i=0,k=0;i<nums.length;i++) {
//			if(i==index)
//				continue;
//			a[k++]=nums[i];
//		}
//		return a;
//	}
}
