package day_3;

public class Palindrome {

	public static void main(String[] args) {
		String s1[]={"Malayalam"};
		if(s1.length<1) {
			System.out.println("provide more than one character");
			return;
		}
		String word=s1[0];
		
		System.out.println("The length of the word is : "+word.length());
		
		System.out.println("The Upper case of the given word is: "+word.toUpperCase());
		
		if(palindrome(word)) {
			System.out.println("The given word "+word+" is palindrome");
		}else {
			System.out.println("The given word "+word+" is not palindrome");
		}
		

	}
	
	public static boolean palindrome(String str) {
		
		int i=0;
		int j=str.length()-1;
		while(i<j) {
			if(str.charAt(i)!=str.charAt(j)) {
				return false;
			}
			i++;
			j--;
		}
		return true;
	}
	

}
