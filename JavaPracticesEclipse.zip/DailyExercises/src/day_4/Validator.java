package day_4;

public class Validator {
	
	public void validate(Applicant applicant) throws InvalidNameException, InvalidPostException, InvalidAgeException {
		if(!isValidApplicantName(applicant.applicantName)) {
			throw new InvalidNameException("Invalid Applicant Name");
		}
		
		if(!isValidPost(applicant.postApplied)) {
			throw new InvalidPostException("Invalid Post");
		}
		
		if(!isValidAge(applicant.applicantAge)) {
			throw new InvalidAgeException("Invalid Age");
		}
		System.out.println("All inputs are valid");
	}
	
	public static boolean isValidApplicantName(String name) {
		if(name!=null && name.length()>=1) {
			return true;
		}
		else {
			return false;
		}
	}
	
	public static boolean isValidPost(String post) {
		if(post.equalsIgnoreCase("Probationary Officer")||post.equalsIgnoreCase("Assistant")||post.equalsIgnoreCase("Special Cadre Officer")) {
			return true;
		}
		else {
			return false;
		}
	}
	
	public static boolean isValidAge(Integer age) {
		if(age>=18 && age<=30) {
			return true;
		}
		else {
			return false;
		}
	}
}
