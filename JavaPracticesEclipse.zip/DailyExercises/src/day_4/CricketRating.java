package day_4;

public class CricketRating {
	String playerName; 
	  float critic1; 
	  float critic2; 
	  float critic3; 
	  float avgRating; 
	  String Coins;
	public CricketRating(String playerName, float critic1, float critic2, float critic3) {
		super();
		this.playerName = playerName;
		this.critic1 = critic1;
		this.critic2 = critic2;
		this.critic3 = critic3;
	} 
	  
	  public void calculateAverageRating(float critic1,float critic2) {
		  avgRating=(critic1+critic2)/2;
	  }

	  public void calculateAverageRating(float critic1,float critic2,float critic3) {
		  avgRating=(critic1+critic2+critic3)/3;
	  }
	  
	  public String calculateCoins() throws NotEligibleException {
		  if (avgRating>=7) { 
			  return "Gold"; 
		  }
		  else if (avgRating>=5 && avgRating<=7) { 
			  return "Silver"; 
		  }
		  else if (avgRating>=2 && avgRating<=5) { 
			  return "Copper"; 
		  }
		  else {
			NotEligibleException e = new NotEligibleException();
			throw e;
		}

	  }
	  
	  public void display() {
		System.out.println("Name: "+playerName);
		System.out.println("Average Rating: "+avgRating);
	}

}
