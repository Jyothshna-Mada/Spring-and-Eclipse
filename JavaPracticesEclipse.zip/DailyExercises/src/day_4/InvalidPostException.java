package day_4;

public class InvalidPostException extends Exception {
	public InvalidPostException(String message) {
		super(message);
	}

}
