package day_4;

import java.util.Scanner;

public class Test {

	public static void main(String[] args) {
		Scanner scn= new Scanner(System.in);
		System.out.println("Enter Applicant name");
		String name=scn.next();
		System.out.println("Enter the post you are applying");
		String post = scn.next();
		System.out.println("Enter applicants's Age");
		int age = scn.nextInt();
		
		Applicant a1 = new Applicant(name, post, age) ;
		 
		Validator c = new Validator();
		
		try { 
			c.validate(a1); 
			} catch (Exception e) {
				System.out.println(e.getMessage());
			}
	}

}
