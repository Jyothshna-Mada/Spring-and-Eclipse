package day_4;

public class Applicant {
		String applicantName; 
		String postApplied;
		int applicantAge;
		public Applicant(String applicantName, String postApplied, int applicantAge) {
			super();
			this.applicantName = applicantName;
			this.postApplied = postApplied;
			this.applicantAge = applicantAge;
		}
		
}
