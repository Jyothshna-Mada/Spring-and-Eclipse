package day_5;

public class FactoryProducer {
	public static Abstractfactory getInstance() {
		return new ShapeFactory();
	}

}
