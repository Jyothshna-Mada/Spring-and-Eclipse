package day_5;

public interface Vehicle {
	void start();
	void accelerate();
	void brake();
}
