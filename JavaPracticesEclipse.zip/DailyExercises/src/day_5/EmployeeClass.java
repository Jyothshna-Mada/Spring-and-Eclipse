package day_5;

public final class EmployeeClass {
	
	private final String firstName;
	private final String lastName;
	private final String dateOfBirth;
	private final int employeeId;
	private final String joiningDate;
	private final double salary;
	
	
	public EmployeeClass(String firstName, String lastName, String dateOfBirth, 
			int employeeId, String joiningDate,double salary) {
		this.firstName = firstName;
		this.lastName = lastName;
		this.dateOfBirth = dateOfBirth;
		this.employeeId = employeeId;
		this.joiningDate = joiningDate;
		this.salary = salary;
	}
	
	public String getFirstName() {
		return firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public String getDateOfBirth() {
		return dateOfBirth;
	}
	public int getEmployeeId() {
		return employeeId;
	}
	public String getJoiningDate() {
		return joiningDate;
	}
	public double getSalary() {
		return salary;
	}
	
	public String toString() {
		return "Employee Deatils: "+"\n"+firstName+" "+lastName+"\n"+dateOfBirth+"\n"+
	employeeId+"\n"+joiningDate+"\n"+salary;
	}
	
	

}
