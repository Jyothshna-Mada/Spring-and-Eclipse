package day_5;

public class AbstractFactoryPatternDemo {

	public static void main(String[] args) {
		Abstractfactory a = FactoryProducer.getInstance();
		
		Shape shape1=a.getShape("circle");
		shape1.draw();
		
		Shape shape2 = a.getShape("Rectangle");
		shape2.draw();
		
		Shape shape3=a.getShape("Square");
		shape3.draw();
			
		}
	}
