package day_5;

public class FactoryDemo {

	public static void main(String[] args) {
		VehicleFactory v = new VehicleFactory();
		
		Vehicle vehicle1 = v.createVehicle("Car");
		vehicle1.start();
		vehicle1.accelerate();
		vehicle1.brake();
		
		System.out.println("**********************************");
		
		Vehicle vehicle2 = v.createVehicle("Motorcycle");
		vehicle2.start();
		vehicle2.accelerate();
		vehicle2.brake();
		
		System.out.println("**********************************");
		
		Vehicle vehicle3 = v.createVehicle("truck");
		vehicle3.start();
		vehicle3.accelerate();
		vehicle3.brake();
		
		System.out.println("***********************************");

	}

}
