package day_5;

public class Circle implements Shape{

	@Override
	public void draw() {
		System.out.println("I am drawing a circle");
		
	}

}
