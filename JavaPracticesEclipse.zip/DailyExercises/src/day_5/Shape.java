package day_5;

public interface Shape {
	void draw();

}
