package day_5;


public class BillingService {
	
	private static volatile BillingService instance;

	private BillingService() {
		
	}
	
	public static BillingService getInstance() {
		if(instance==null) {
			synchronized (BillingService.class) {
				if(instance==null) {
					instance=new BillingService();
				}
			}
		}
		
		
		return instance;
	}
	
	public void processPayment(String account,double amount) {
		System.out.println("Payment Done for the account "+account+" with rupees "+amount);
	}
	
	public void generateInvoice(String account,double amount) {
		System.out.println("Ordered Successfully for the account "+account+"with rupees "+amount);
	}

}
