package day_1;

public class Date {
	int day=14;
	int month=7;
	int year=2001;
	
	public Date(int day, int month, int year) {
		if(date_validate(day,month,year)) {
		this.day = day;
		this.month = month;
		this.year = year;
		}
	}
	
	public String toString() {
		return day+"-"+month+"-"+year;
		
	}
	
	public boolean date_validate(int day, int month, int year) { 

		if((day>=1 && day<=31) && (month>=1 && month<=12) && 
				(year>=1940 && year<=2024)) { 
		return true; 
		} 
		return false;  
		} 
}
