package day_1;

public class Vehicle {
	private String manufacturer;
	private String model;
	private int year;
	
	public String getManufacturer() {
		return manufacturer;
	}
	public String getModel() {
		return model;
	}
	public int getYear() {
		return year;
	}
	public void setManufacturer(String manufacturer) {
		this.manufacturer = manufacturer;
	}
	public void setModel(String model) {
		this.model = model;
	}
	public void setYear(int year) {
		this.year = year;
	}
	
public Vehicle() {
		
	}
	
	public Vehicle(String manufacturer,String model,int year){
		this.manufacturer=manufacturer;
		this.model=model;
		this.year=year;
	}
	
	
	public void displayDetails() {
		System.out.println("Manufacturer: "+getManufacturer());
		System.out.println("Model: "+getModel());
		System.out.println("Year: "+getYear());
	}
	
}
