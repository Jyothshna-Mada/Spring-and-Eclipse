package day_1;

public class Book {

	public static void main(String[] args) {
		
		BookStore book = new BookStore();
	
		BookStore book1=new BookStore();
		book1.setBook_Title("Java Programming");
		book1.setPrice(350.50);
		
		BookStore book2 = new BookStore();
		book2.setBook_Title("c  Programming  ");
		book2.setPrice(200.0);
		
		BookStore[] books= {book1,book2};
		
		BookStore.createBooks(books, books.length);
		books=BookStore.showBooks();
		
		System.out.println("  Book Title                Price       ");
		
		for(BookStore eachBook:books) {
			System.out.println(eachBook.getBook_Title() +"            "+eachBook.getPrice());
		}
	}

}
