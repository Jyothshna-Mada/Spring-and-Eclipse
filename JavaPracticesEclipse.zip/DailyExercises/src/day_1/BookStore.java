package day_1;

public class BookStore {
	static BookStore[] books;
	private String Book_Title;
	private double price;
	
	public String getBook_Title() {
		return Book_Title;
	}
	public void setBook_Title(String book_Title) {
		Book_Title = book_Title;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	
	public static void createBooks(BookStore[] books1,int count) {
		books=books1;
	}
	
	
	public static BookStore[] showBooks() {
		return books;
		
	}

}
