package day_1;

public class ChildClass extends ParentChild{

}
