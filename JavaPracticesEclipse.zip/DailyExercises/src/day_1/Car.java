package day_1;

public class Car extends Vehicle{
	private int seatingCapacity;

	public int getSeatingCapacity() {
		return seatingCapacity;
	}

	public void setSeatingCapacity(int seatingCapacity) {
		this.seatingCapacity = seatingCapacity;
	}
	
	

	public Car(String manufacturer, String model, int year, int seatingCapacity) {
		super(manufacturer, model, year);
		this.seatingCapacity = seatingCapacity;
	}

	

	public Car() {
		
	}

	@Override
	public void displayDetails() {
		System.out.println("Car Manufacturer: "+getManufacturer());
		System.out.println("Car Model: "+getModel());
		System.out.println("Car Year: "+getYear());
		System.out.println("Car Seating Capacity: "+getSeatingCapacity());
	}
	
	public void accelerate() {
		System.out.println("Accelerated successfully");
	}
	
	public void brake() {
		System.out.println("Car stopped using brake");
	}

}
