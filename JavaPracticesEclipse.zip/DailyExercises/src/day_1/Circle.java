package day_1;

public class Circle extends Shape{

	double radius;
	double area;
	
	
	public Circle(double radius) {
		super();
		this.radius = radius;
	}


	@Override
	public void calculateArea() {
		area= 3.14 *(radius*radius);
		System.out.println("The area of Circle is: "+area);
	}

}
