package day_1;

public class TestRectangle {

	public static void main(String[] args) {
		System.out.println("   Default values of rectangle:    ");
		Rectangle r1 = new Rectangle();
		r1.calcArea();
		r1.display();
		
		System.out.println("    External values of rectangle:     ");
		Rectangle r2 = new Rectangle(1.0f,15.56f);
		r2.calcArea();
		r2.calcPerimeter();
		r2.display();

	}

}
