package day_1;

public class ParentChild extends Exception{

}
