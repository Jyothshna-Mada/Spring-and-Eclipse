package day_1;

public class ShapeMain {

	public static void main(String[] args) {

			Shape s1 = new Rectangle1(12, 15);
			Shape s2 = new Circle(15);
			Shape s3 = new Triangle(33, 12);
			
			s1.calculateArea();
			s2.calculateArea();
			s3.calculateArea();
			
			
		}

	}


