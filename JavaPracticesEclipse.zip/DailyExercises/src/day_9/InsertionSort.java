package day_9;

public class InsertionSort {

	public static void main(String[] args) {
	double d[]= {12.5,11.0,13.2,5.7,6.1};
	
	sort(d);
	for(double n:d) 
		System.out.print(n+" ");
	
	}
	
	public static void sort(double[] a) {
		
		for(int i=1;i<a.length;i++) {
			double key=a[i];
			int j=i-1;
			while(j>=0 && a[j]>key) {
				a[j+1]=a[j];
				j--;
			}
			a[j+1]=key;
		}
		
	}

}
