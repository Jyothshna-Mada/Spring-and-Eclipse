package model;

import java.io.IOException;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;


@WebServlet("/loginvalidate")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			User user = new User();
			String username=request.getParameter("username");
			String password=request.getParameter("password");
			user.setUsername(username);
			user.setPassword(password);
			
			try {
				if(username==null||username.trim().isEmpty()) {
					throw new BusinessException("UserName should not be null");
				}
				
				if(password==null||password.length()<4 && password.length()>8) {
					throw new BusinessException("Password should be 4-8 character length");
				}
			} catch (Exception e) {
				throw new BusinessException(e.getMessage());
			}

			LoginBO loginBO= new LoginBO();
			
			if(loginBO.isValidUser(user))
			{
				RequestDispatcher dispatcher = request.getRequestDispatcher("welcome.html");
				dispatcher.forward(request, response);
			}
			
		}catch (Exception e) {
			request.setAttribute("message", "Invalid Username/Password");
			RequestDispatcher dispatcher = request.getRequestDispatcher("Login.html");
			dispatcher.forward(request, response);
		}
		
		}
	}


