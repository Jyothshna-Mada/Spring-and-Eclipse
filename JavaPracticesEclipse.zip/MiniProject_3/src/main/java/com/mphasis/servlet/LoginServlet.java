package com.mphasis.servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mphasis.BO.UserLoginBO;

import model.BusinessException;

public class LoginServlet {
	private static final long serialVersionUID = 1L; 
	 
	private UserLoginBO userLogBO; 
	 
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException { 
	 
	String email = request.getParameter("email"); 
	String password = request.getParameter("password"); 
	 
	if(request.getParameter("log") != null) {  
	try { 
	userLogBO = new UserLoginBO(); 
	boolean userExists = userLogBO.findUser(email, password);    
	if(userExists) { 
	RequestDispatcher dispatcher = request.getRequestDispatcher("userHome.jsp"); 
	dispatcher.forward(request, response);   
	} 
	} catch (BusinessException e) { 
	request.setAttribute("errorMessage", e.getMessage()); 
	RequestDispatcher dispatcher = request.getRequestDispatcher("login.jsp");  
	dispatcher.forward(request, response);  
	} 
	} 
	} 

}
