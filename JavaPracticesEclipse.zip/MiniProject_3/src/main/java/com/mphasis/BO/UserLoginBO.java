package com.mphasis.BO;

import model.BusinessException;

public class UserLoginBO {
	public boolean findUser(String email, String password) throws BusinessException { 
		UserLogin userLogin = new UserLogin(); 
		userLogin.setEmail(email); 
		userLogin.setPassword(password); 
		boolean userExists = UserLoginDao.isUserExist(userLogin);  
		if(userExists)  
		return true; 
		throw new BusinessException("Not Registered or Invalid Credentails");  
		} 

}
