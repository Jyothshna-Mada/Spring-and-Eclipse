package com.mphasis.Example;

import java.io.IOException;
import java.io.PrintWriter;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/Dispatch")
public class UserHome extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		out.println("<html><head>");
		out.println("<title><h1>User Home</h1></title><body>");
		RequestDispatcher dispatch =request.getRequestDispatcher("Welcome");
		request.setAttribute("name", "Arun");
		dispatch.include(request, response);
		out.println("<h1> This is User Home</h1>");
		RequestDispatcher dispatch1=request.getRequestDispatcher("Footer");
		dispatch1.include(request, response);
		out.println("</body></html>");
	
	}

}
