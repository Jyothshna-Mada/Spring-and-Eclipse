package com.mphasis.ContextEx;

import java.io.IOException;

import jakarta.servlet.ServletConfig;
import jakarta.servlet.ServletContext;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;



public class HomeServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private String initcount;
	
	private ServletContext context;
 
	@Override
	public void init(ServletConfig config) throws ServletException {
		context=config.getServletContext();
		initcount = context.getInitParameter("initialCount");
	}
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String countValue=null;
		if(context.getAttribute("count")!=null) {
			countValue=context.getAttribute("count").toString();
		}else {
			countValue=initcount;
		}
		int count =Integer.parseInt(countValue);
		count++;
		context.setAttribute("count", count);
	}

	

}
