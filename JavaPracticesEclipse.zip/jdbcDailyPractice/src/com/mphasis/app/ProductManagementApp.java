package com.mphasis.app;

import java.util.List;
import java.util.Scanner;

import com.mphasis.dao.ProductManagementDAO;
import com.mphasis.domain.Product;

public class ProductManagementApp {

	public static void main(String[] args) {
		
		ProductManagementDAO dao=new ProductManagementDAO();
		
		Scanner scn = new Scanner(System.in);
		String choice;
		boolean exit=false;
		
		while(!exit){
			System.out.println("A. View Products");
			System.out.println("B. Add Product");
			System.out.println("C. Update Product");
			System.out.println("D. Delete Product");
			System.out.println("E. Search Product");
			System.out.println("F. Exit");
			System.out.println("===========================");
			System.out.println("Enter an Option");
			System.out.println("===========================");
			choice =scn.nextLine().trim().toUpperCase();
			switch(choice) {
			case "A":{
				List<Product> p= dao.viewProduct();
				if(p.isEmpty()) {
					System.out.println("No Products Found");
				}else {
					for(Product pro:p) {
						System.out.println(pro);
					}
				}
				break;
			}
			case "B":{
				System.out.println("Enter Product id: ");
				int id = scn.nextInt();
				scn.nextLine();
				System.out.println("Enter Product name");
				String name = scn.nextLine();
				System.out.println("Enter Product price");
				String price = scn.nextLine();
				Product p = new Product(id, name, price);
				dao.addProduct(p);

				break;
			}
			case "C": {
				System.out.println("Enter Product id to update");
				int id= scn.nextInt();
				scn.nextLine();
				System.out.println("Enter New Product name");
				String name = scn.nextLine();
				System.out.println("Enter new Product Price");
				String price = scn.nextLine();
				Product p = new Product(id, name, price);
				dao.updateProduct(p);
				break;
			}
			case "D":{
				System.out.println("Enter Product id to delete");
				int id = scn.nextInt();
				scn.nextLine();
				dao.deleteProduct(id);
				break;
			}
			case "E":{
				System.out.println("Enter Product id to search");
				int id = scn.nextInt();
				scn.nextLine();
				Product p= dao.searchProduct(id);
				if(p!=null) System.out.println(p);
				else System.out.println("Product not found");
				break;
			}
			case "F":{
				System.out.println("**********Thank You**********");
				exit=true;
				break;
			}
			default:
				System.out.println("Invalid Choice");
		}
		}
		scn.close();
	}
}
