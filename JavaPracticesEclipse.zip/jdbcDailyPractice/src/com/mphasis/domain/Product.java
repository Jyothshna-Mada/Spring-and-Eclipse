package com.mphasis.domain;

public class Product {
	private int Product_id;
	private String Product_name;
	private String Product_price;
	
	public Product(int product_id, String product_name, String product_price) {
		
		Product_id = product_id;
		Product_name = product_name;
		Product_price = product_price;
	}
	
	public int getProduct_id() {
		return Product_id;
	}
	public void setProduct_id(int product_id) {
		Product_id = product_id;
	}
	public String getProduct_name() {
		return Product_name;
	}
	public void setProduct_name(String product_name) {
		Product_name = product_name;
	}
	public String getProduct_price() {
		return Product_price;
	}
	public void setProduct_price(String product_price) {
		Product_price = product_price;
	}
	@Override
	public String toString() {
		return "Product [Product_id=" + Product_id + ", Product_name=" + Product_name + ", Product_price="
				+ Product_price + "]";
	}
	
	
	
	
}
